import fetch from 'node-fetch';
import chalk from 'chalk';

/**
 * 🛰️ MONITOR DE APIS - NEL-AVISO SUPREME
 * Verifica a saúde das APIs e avisa o dono se algo falhar.
 */

const APIS_TO_CHECK = [
  { name: 'Vreden API', url: 'https://api.vreden.web.id/api/health' },
  { name: 'Google TTS', url: 'https://translate.google.com' },
  { name: 'IA Brain', url: 'https://api.vreden.web.id/api/ai/chatgpt?text=hi' }
];

export async function checkApisHealth() {
  console.log(chalk.blue('[ 🛰️ ] A iniciar monitorização de APIs...'));
  
  for (const api of APIS_TO_CHECK) {
    try {
      const res = await fetch(api.url, { timeout: 5000 });
      if (res.ok) {
        console.log(chalk.green(`[ ✅ ] ${api.name}: Online`));
      } else {
        console.log(chalk.yellow(`[ ⚠️ ] ${api.name}: Instável (Status ${res.status})`));
      }
    } catch (e) {
      console.log(chalk.red(`[ ❌ ] ${api.name}: Offline (${e.message})`));
    }
  }
}

// Verificar a cada 12 horas
setInterval(checkApisHealth, 12 * 60 * 60 * 1000);
