// ╔══════════════════════════════════════════════════════════════╗
//   NEL-AVISO-BOT-MOZ · core/system/commands.js
//   V13.1 OMNI-NEXUS EDITION - REPLIT OPTIMIZED
// ╚═══════════════════════════════════════════════════════════════╝

export const bodyMenu = `
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃   🧠 *OMNI-NEXUS* · V13.1   ┃
┃   _Replit Optimized Edition_   ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

👋 Olá *@$sender*! O núcleo *Omni* está estável.
O seu assistente de elite foi otimizado para 24/7.

┌─ ░ *OMNI-CORE STATS* ░
│ 👑 *Dono:* Nel Custódio
│ 👥 *Cidadãos:* $users
│ 💎 *VIPs:* Ativo
│ 🔋 *Uptime:* $uptime
└───────────────────

┏━━━━━━ 📋 *CATEGORIAS* ━━━━━━┓
┃
┃ 💎 ░ .menu elite (VIP Only)
┃ 🚀 ░ .menu nexus (Novidades)
┃ 🛠️ ░ .menu utilidades
┃ 🧠 ░ .menu ia (Elite)
┃ 💰 ░ .menu economia
┃ 💳 ░ .menu pagamentos
┃ 🛡️ ░ .menu moderacao
┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

📢 *Dashboard:* $link/dashboard
💡 *Dica:* Use *.nexus-ai* para criar arte incrível!
> 🏆 _Omni-Nexus - O Futuro é Agora_`;

export const menuObject = {
  elite: `
╔══════════════════════════════════════╗
║  💎 *NEXUS ELITE* · V13.1 Exclusive  ║
╚══════════════════════════════════════╝
┌─ ░ COMANDOS ELITE ░──────────────┐
│ .nexus-ai » .img  Gerar Arte 🎨    │
│ .spy-web » .spy   Analisar Link 🔍 │
│ .voice-nexus » .tts Voz Neural 🎙️   │
│ .vip » .premium  Info Subscrição 💎 │
│ .resumir » .resumo IA Ilimitada 📝 │
│ .brain » .nel    Nexus-Brain V13 🧠 │
└──────────────────────────────────┘`,

  nexus: `
╔══════════════════════════════════════╗
║  🚀 *NEXUS CORE* · V13.1 Features    ║
╚══════════════════════════════════════╝
┌─ ░ NOVIDADES OMNI ░──────────────┐
│ .nexusstats » .imperio Dashboard 📊 │
│ .agenda » .notas Notas Cloud 📝    │
│ .traduzir-doc    Traduzir Doc 📄  │
│ .excel-tool » .excel Gerar Tabela 📊│
│ .imc » .peso    Calculadora IMC ⚖️ │
│ .agua » .beber   Lembrete Água 💧  │
│ .converter » .unid Conversor 📏    │
└──────────────────────────────────┘`,

  ia: `
╔══════════════════════════════════════╗
║  🤖 *IA CORE* · Nexus Intelligence  ║
╚══════════════════════════════════════╝
┌─ ░ NÚCLEO IA (VIP) ░─────────────┐
│ .brain » .nel    Nexus-Brain 🧠    │
│ .nexus-ai » .img  DALL-E 3 🎨      │
│ .voice-nexus » .tts Voz Neural 🎙️   │
│ .vision » .ver   Nexus Vision 📸   │
│ .deepsearch      Deep Search 🔍    │
│ .chatgpt » .ia    ChatGPT 4 🤖     │
└──────────────────────────────────┘`
};

export default { bodyMenu, menuObject };
