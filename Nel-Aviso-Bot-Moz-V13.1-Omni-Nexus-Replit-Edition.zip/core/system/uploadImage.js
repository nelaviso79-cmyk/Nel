import axios from 'axios';
import FormData from 'form-data';

const generateUniqueFilename = (mime) => {
  const ext = (mime || 'image/jpeg').split('/')[1]?.split(';')[0] || 'jpg';
  return `${Date.now()}_${Math.random().toString(36).slice(2)}.${ext}`;
}

const uploadAdoFiles = async (buffer, mime) => {
  const filename = generateUniqueFilename(mime)
  const res = await axios.post("https://cdn.adoolab.xyz/api/upload", {
    filename,
    data: buffer.toString('base64'),
    expiration: "never"
  }, {
    headers: {
      "Content-Type": "application/json"
    },
    maxContentLength: Infinity,
    maxBodyLength: Infinity
  })
  return res.data?.url
}

const uploadUguu = async (buffer, mime) => {
  const form = new FormData()
  form.append("files[]", buffer, generateUniqueFilename(mime))
  const res = await axios.post("https://uguu.se/upload.php", form, { headers: form.getHeaders(), maxContentLength: Infinity, maxBodyLength: Infinity })
  return res.data?.files?.[0]?.url
}

export default async function uploadImage(buffer, mime) {
  try {
    const url = await uploadAdoFiles(buffer, mime);
    if (url) return url;
  } catch (e) {}
  
  try {
    const url = await uploadUguu(buffer, mime);
    if (url) return url;
  } catch (e) {}
  
  throw new Error("Falha ao fazer upload da imagem em todos os servidores.");
}
