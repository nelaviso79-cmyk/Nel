import fs from 'fs';
import path from 'path';

/**
 * 🧹 CLEANER - Limpa ficheiros temporários e logs sensíveis.
 */
export function cleanTraces() {
  const tmpDir = './tmp';
  const logsDir = './logs';
  
  const dirs = [tmpDir, logsDir];
  
  dirs.forEach(dir => {
    if (fs.existsSync(dir)) {
      const files = fs.readdirSync(dir);
      files.forEach(file => {
        const filePath = path.join(dir, file);
        try {
          // Não apagar arquivos de sessão, apenas temporários e logs
          if (!file.includes('creds.json') && !file.includes('session')) {
            fs.unlinkSync(filePath);
          }
        } catch (e) {
          // Silencioso
        }
      });
    }
  });
  
  console.log('[ 🧹 ] Rastos e ficheiros temporários limpos com sucesso.');
}

// Agendar limpeza a cada 6 horas
setInterval(cleanTraces, 6 * 60 * 60 * 1000);
