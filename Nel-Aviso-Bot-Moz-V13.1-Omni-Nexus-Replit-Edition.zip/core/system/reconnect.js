import chalk from 'chalk';
import { DisconnectReason } from 'baileys';

/**
 * 🔄 SISTEMA DE RECONEXÃO ULTRA V10
 * Garante que o bot permaneça online 24/7 com inteligência de recuperação.
 */

export function handleDisconnect(sock, lastDisconnect, startBot, reconexion) {
  const reason = lastDisconnect?.error?.output?.statusCode || 0;
  
  console.log(chalk.yellow(`[ 🔄 ] Conexão fechada. Motivo: ${reason}`));

  // Motivos críticos que exigem limpeza de sessão
  if ([DisconnectReason.loggedOut, DisconnectReason.forbidden].includes(reason)) {
    console.log(chalk.red('🚨 Sessão invalidada ou banida. Ação manual necessária.'));
    return false; // Não reconectar automaticamente para evitar loops de ban
  }

  // Motivos temporários - Reconectar com atraso incremental
  const delay = Math.min(2000 * (reconexion + 1), 20000);
  console.log(chalk.cyan(`[ 🔄 ] Tentando reconectar em ${delay / 1000}s... (Tentativa ${reconexion + 1})`));
  
  setTimeout(() => {
    startBot();
  }, delay);

  return true;
}

export default { handleDisconnect };
