/**
 * 🛡️ NEXUS GUARDIAN - Sistema Anti-Spam e Anti-Trava V13
 */

const spamMap = new Map();

export async function checkGuardian(sock, msg, isAdmins, isBotAdmins) {
  if (!msg.isGroup || isAdmins || !msg.text) return false;

  const sender = msg.sender;
  const chat = msg.chat;

  // 1. Detecção de Trava-WhatsApp (Mensagens extremamente longas ou com caracteres estranhos)
  if (msg.text.length > 4000 || (msg.text.match(/[\u0000-\u001F\u007F-\u009F]/g) || []).length > 100) {
    console.log(`🛡️ [ Guardian ] Trava detectada de ${sender}`);
    if (isBotAdmins) {
      await sock.sendMessage(chat, { text: `🛡️ *NEXUS GUARDIAN:* Tentativa de ataque detectada.\nRemovendo atacante: @${sender.split('@')[0]}`, mentions: [sender] });
      await sock.groupParticipantsUpdate(chat, [sender], 'remove');
      return true;
    }
  }

  // 2. Anti-Spam (Muitas mensagens em pouco tempo)
  const now = Date.now();
  const userData = spamMap.get(sender) || { count: 0, last: now };
  
  if (now - userData.last < 2000) {
    userData.count++;
  } else {
    userData.count = 1;
  }
  userData.last = now;
  spamMap.set(sender, userData);

  if (userData.count > 5) {
    if (isBotAdmins) {
      await sock.sendMessage(chat, { text: `🛡️ *NEXUS GUARDIAN:* Spam detectado.\n@${sender.split('@')[0]} foi silenciado por excesso de mensagens.`, mentions: [sender] });
      await sock.groupParticipantsUpdate(chat, [sender], 'remove');
      return true;
    }
  }

  return false;
}

export default { checkGuardian };
