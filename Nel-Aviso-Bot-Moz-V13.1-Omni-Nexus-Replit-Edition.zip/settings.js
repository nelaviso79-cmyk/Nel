import { watchFile, unwatchFile, existsSync, readFileSync } from "fs";
import chalk from "chalk";
import { fileURLToPath } from "url";

// ═══════════════════════════════════════════════════════
// 🔐 CARREGADOR DE .env — Dados sensíveis ficam fora do código
// Cria um ficheiro .env na raiz (nunca vai pro GitHub, está no .gitignore)
// ═══════════════════════════════════════════════════════
try {
  if (existsSync('.env')) {
    for (const line of readFileSync('.env', 'utf-8').split('\n')) {
      const t = line.trim();
      if (!t || t.startsWith('#')) continue;
      const i = t.indexOf('=');
      if (i === -1) continue;
      const key = t.slice(0, i).trim();
      let val = t.slice(i + 1).trim();
      if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) val = val.slice(1, -1);
      if (!(key in process.env)) process.env[key] = val;
    }
  }
} catch {}

global.owner = [process.env.OWNER_NUMBER || '258878464656'];
global.noPrefix = true

global.dev = "Nel Aviso";
global.links = {
  api: process.env.API_LINK || 'https://github.com/nelioaviso-arch',
  channel: process.env.CHANNEL_LINK || "https://whatsapp.com/channel/0029Vb8SJi3BFLgQL1wCTr3N",
  github: process.env.GITHUB_LINK || "https://github.com/nelioaviso-arch/Nel-Aviso-Bot-Moz.git",
  gmail: process.env.OWNER_GMAIL || "seuemail@gmail.com",
  banner: 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663816274487/ISALFhwAnOmlwENj.png',
  icon: 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663816274487/cJuGzIUHJLMcgAUg.png'
}
global.my = {
  ch1: '120363401404146384@newsletter'
};

global.APIs = { 
  nelbotmoz: { url: "https://api.nel-bot-moz.my.id", key: "NelBot-WD" },
  yuki: { url: "https://api.yuki-wabot.my.id", key: "NelBot-WD" },
  vreden: { url: "https://api.vreden.web.id", key: null },
  ootaizumi: { url: "https://api.ootaizumi.web.id", key: null },
  delirius: { url: "https://api.delirius.store", key: null },
  zenzxz: { url: "https://api.zenzxz.my.id", key: null },
  siputzx: { url: "https://app.siputzx.my.id", key: null }
};

// ═══════════════════════════════════════════════════════
// 🧾 CONTAS DO DONO — Para verificação de comprovativos
// Estes são os números e nomes REAIS para onde os
// clientes enviam pagamentos M-Pesa / E-Mola
// Valores reais ficam no .env — aqui só há fallback genérico
// ═══════════════════════════════════════════════════════
global.contasDono = {
  mpesa: {
    numero: process.env.MPESA_NUMERO || '8XXXXXXXX',
    nome: process.env.MPESA_NOME || 'Seu Nome',
    operadora: 'Vodacom'
  },
  emola: {
    numero: process.env.EMOLA_NUMERO || '8XXXXXXXX',
    nome: process.env.EMOLA_NOME || 'Seu Nome',
    operadora: 'Movitel'
  }
};

global.mess = {
  socket: '⁧ Este comando só pode ser executado por um Socket.',
  admin: '⁧ Este comando só pode ser executado pelos Administradores do Grupo.',
  botAdmin: '⁧ Este comando só pode ser executado se o Socket for Administrador do Grupo.'
};

let file = fileURLToPath(import.meta.url);
watchFile(file, () => {
  unwatchFile(file);
  import(`${file}?update=${Date.now()}`);
});
