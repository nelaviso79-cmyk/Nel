let handler = async (m, { conn }) => {
  const contas = global.contasDono || {};
  const mpesa = contas.mpesa || {};
  const emola = contas.emola || {};
  await conn.sendMessage(m.chat, { text: `⬇️ *FORMAS DE PAGAMENTO* ⬇️\n\n1️⃣ *M-PESA ❤️*\n📱 ${mpesa.numero || '858457134'}\n👤 ${mpesa.nome || 'Nel Custódio'}\n\n2️⃣ *E-MOLA 🧡*\n📱 ${emola.numero || '878038315'}\n👤 ${emola.nome || 'Nel Custódio'}\n\n> Após a transferência, envie o comprovativo\n> O bot detecta AUTOMATICAMENTE! 🤖\n> + O número do qual pretende activar o pacote\n\n. Obrigado! 🙏` }, { quoted: m });
}
handler.customPrefix = /^(pagamentos|formas de pagamento|pagar)$/i
handler.command = new RegExp
export default handler
