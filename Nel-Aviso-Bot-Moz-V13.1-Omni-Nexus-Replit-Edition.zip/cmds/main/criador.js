export default {
  command: ['criador', 'owner', 'dono', 'dev'],
  category: 'main',
  description: 'Informações sobre o criador do bot.',
  run: async ({ msg, sock, usedPrefix, command }) => {
    return msg.reply(
      `❧ *Informações do Criador* 👑\n\n` +
      `▸ Nome: *Nel Custódio*\n` +
      `▸ Idade: *19 anos*\n` +
      `▸ Número: *258878464656*\n` +
      `▸ País: *Moçambique* 🇲🇿\n` +
      `▸ Projecto: *Nel-Aviso-Bot-Moz*\n` +
      `▸ Versão: *4.0*\n\n` +
      `▸ Contacto: wa.me/258878464656\n\n` +
      `🔥 Feito com amor por Nel 🇲🇿\n` +
      `▸ Este bot é único e feito em Moçambique!`
    );
  },
};
