export default {
  command: ['bugreport', 'bug', 'reportarbug'],
  category: 'main',
  description: 'Reportar um bug encontrado no bot.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    if (!args.length) {
      return msg.reply(`❧ *Reportar Bug* 🐛\n\n✎ Descreve o problema:\n> *${usedPrefix + command} O comando X não funciona quando...*`);
    }

    const bug = args.join(' ');
    const sender = msg.sender.split('@')[0];
    const ownerJid = global.owner[0] + '@s.whatsapp.net';

    try {
      await sock.sendMessage(ownerJid, {
        text: `🐛 *Novo Bug Reportado*\n\n▸ De: @${sender}\n▸ Grupo: ${msg.chat}\n▸ Bug: *${bug}*\n▸ Comando: *${command}*\n▸ Data: ${new Date().toLocaleString('pt-BR')}`,
        mentions: [msg.sender]
      });
      return msg.reply('❧ Bug reportado com sucesso! ✅\n▸ O criador vai analisar o problema.');
    } catch (e) {
      return msg.reply('❧ Não foi possível enviar o reporte. Tenta novamente mais tarde.');
    }
  },
};
