import fetch from 'node-fetch'
import os from 'os';
import { prepareWAMessageMedia } from 'baileys';
import db from '#db';

export default {
  command: ['infobot', 'botinfo'],
  category: 'main',
  description: 'Obter informação do bot.',
  run: async ({ msg, sock, usedPrefix, command, text }) => {
    const botId = sock.user.id.split(':')[0] + "@s.whatsapp.net";
    const botSettings = db.getSettings(botId) || {};
    const botname = botSettings.botname || 'Bot';
    const namebot = botSettings.namebot || 'Bot';
    const moedas = botSettings.currency || 'Yenes';
    const banner = botSettings.banner || '';
    const prefixo = botSettings.prefix;
    const owner = botSettings.owner || '';
    const canalId = botSettings.newsletter_id || '';
    const canalName = botSettings.nameid || '';
    const link = botSettings.link || '';
    let desar = 'Oculto';
    if (owner && !isNaN(owner.replace(/@s\.whatsapp\.net$/, ''))) {
      const userData = db.getUser(owner);
      desar = userData?.genre || 'Oculto';
    }
    const platform = os.type();
    const now = new Date();
    const maputoTime = new Date(now.toLocaleString('en-US', { timeZone: 'Africa/Maputo' }));
    const nodeVersion = process.version;
    const sistemaUptime = rTime(os.uptime());
    const uptime = process.uptime();
    const uptimeDate = new Date(maputoTime.getTime() - uptime * 1000);
    const formattedUptimeDate = uptimeDate.toLocaleString('es-ES', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' }).replace(/^./, m => m.toUpperCase());
    const isOficialBot = botId === ((global.sock?.user?.id?.split(':')[0] ?? null) && ((global.sock?.user?.id?.split(':')[0] ?? null) && (global.sock.user.id.split(':')[0] + '@s.whatsapp.net')));
    const botType = isOficialBot ? 'Principal/Dono' : 'Sub Bot';
    try {
      const message = `✐ Informação do bot *${botname}!*

✿ *Nome Curto ›* ${namebot}
✿ *Nome Completo ›* ${botname}
✦ *Moeda ›* ${moedas}
✦ *Prefixo${Array.isArray(prefixo) && prefixo.length > 1 ? 's' : ''} ›* ${prefixo === 1 ? '`sem prefixos`' : (Array.isArray(prefixo) ? prefixo : [prefixo || '/']).map(p => `\`${p}\``).join(', ')}

❒ *Tipo ›* ${botType}
❒ *Plataforma ›* ${platform}
❒ *NodeJS ›* ${nodeVersion}
❒ *Activo desde ›* ${formattedUptimeDate}
❒ *Sistema Activo ›* ${sistemaUptime}
❒ *${desar === 'Homem' ? 'Dono' : desar === 'Mulher' ? 'Dona' : 'Dono(a)'} ›* ${owner ? (!isNaN(owner.replace(/@s\.whatsapp\.net$/, '')) ? `@${owner.split('@')[0]}` : owner) : "Oculto por privacidade"}

> \`Link:\` ${link}`.trim();
   await sock.sendMessage(msg.chat, banner.includes('.mp4') || banner.includes('.webm') ? { video: { url: banner }, gifPlayback: true, caption: message.trim(), contextInfo: { mentionedJid: [owner, msg.sender], isForwarded: true, forwardedNewsletterMessageInfo: { newsletterJid: canalId, serverMessageId: '0', newsletterName: canalName } } } : { text: message.trim(), linkPreview: link && banner ? (await prepareWAMessageMedia({ image: { url: banner }}, { upload: sock.waUploadToServer, mediaTypeOverride: 'thumbnail-link' }).then(({ imageMessage }) => ({ 'canonical-url': link, 'matched-text': link, title: botname, description: `${namebot}, mᥲძᥱ ᥕі𝗍һ ᑲᥡ ⁱᵃᵐ|𝔇ĕ𝐬†𝓻⊙γ𒆜`, jpegThumbnail: imageMessage?.jpegThumbnail ? Buffer.from(imageMessage.jpegThumbnail) : undefined, highQualityThumbnail: imageMessage || undefined }))) : undefined, contextInfo: { mentionedJid: [owner, msg.sender], isForwarded: true, forwardedNewsletterMessageInfo: { newsletterJid: canalId, serverMessageId: '0', newsletterName: canalName }}}, { quoted: msg });
    } catch (e) {
      return msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  }
};

function rTime(seconds) {
  seconds = Number(seconds);
  const d = Math.floor(seconds / (3600 * 24));
  const h = Math.floor((seconds % (3600 * 24)) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  const dDisplay = d > 0 ? d + (d === 1 ? " dia, " : " dias, ") : "";
  const hDisplay = h > 0 ? h + (h === 1 ? " hora, " : " horas, ") : "";
  const mDisplay = m > 0 ? m + (m === 1 ? " minuto, " : " minutos, ") : "";
  const sDisplay = s > 0 ? s + (s === 1 ? " segundo" : " segundos") : "";
  return dDisplay + hDisplay + mDisplay + sDisplay;
}