import moment from 'moment-timezone';
import { getDevice } from 'baileys';
import db from '#db';
import { bodyMenu, menuObject } from '#system/commands';

function normalize(text = '') {
  text = text.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]/g, '');
  return text.endsWith('s') ? text.slice(0, -1) : text;
}

function formatarMs(ms) {
  const segundos = Math.floor(ms / 1000);
  const minutos = Math.floor(segundos / 60);
  const horas = Math.floor(minutos / 60);
  const dias = Math.floor(horas / 24);
  return [dias && `${dias}d`, `${horas % 24}h`, `${minutos % 60}m`, `${segundos % 60}s`].filter(Boolean).join(" ");
}

export default {
  command: ['allmenu', 'help', 'menu', 'ayuda'],
  category: 'main',
  description: 'Ver o menu de comandos Nexus Intelligence.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    try {
      const now = moment.tz('Africa/Maputo');
      const tiempo = now.format('DD/MM/YYYY');
      const tempo = now.format('HH:mm:ss');
      
      const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
      const botSettings = db.getSettings(botId) || {};
      const botname = botSettings.botname || 'Nexus Intelligence';
      const namebot = botSettings.namebot || 'Nexus-V12';
      
      const users = db.getUser();
      const usersCount = users?.length || 0;
      const device = getDevice(msg.key.id);
      const userGlobal = db.getUser(msg.sender);
      const senderName = userGlobal?.name || msg.pushName || 'Usuário';
      const uptime = sock.uptime ? formatarMs(Date.now() - sock.uptime) : "Ativo";

      // Banner V12 Nexus
      const bannerUrl = `https://api.vreden.web.id/api/canvas/welcome?name=${encodeURIComponent('NEL CUSTÓDIO')}&msg=${encodeURIComponent('OMNI-NEXUS V13')}&avatar=https://telegra.ph/file/241d9774659970966952e.jpg&groupname=${encodeURIComponent('NEXUS ELITE')}`;

      const alias = {
        elite: ['elite', 'premium', 'vip'],
        nexus: ['nexus', 'novidades', 'v13'],
        utilidades: ['utilidades', 'utils', 'ferramentas'],
        ia: ['ia', 'ai', 'inteligencia'],
        economia: ['economia', 'eco'],
        pagamentos: ['pagamentos', 'pagamento', 'vendas'],
        noticias: ['noticias', 'news'],
        downloads: ['downloads', 'download', 'baixar'],
        stickers: ['stickers', 'figurinhas'],
        grupos: ['grupos', 'grupo'],
        anime: ['anime', 'reacoes'],
        moderacao: ['moderacao', 'mod', 'seguranca'],
        diversao: ['diversao', 'jogos', 'brincar'],
        nsfw: ['nsfw', '+18']
      };

      const input = normalize(args[0] || '');
      const cat = Object.keys(alias).find(k => alias[k].map(normalize).includes(input));
      
      if (args[0] && !cat) {
        return msg.reply(`《✧》 A categoria *${args[0]}* não existe.\n> Categorias: *${Object.keys(alias).join(', ')}*`);
      }

      const content = cat ? (menuObject[cat] || '') : bodyMenu;
      let menu = content;

      // Substituir variáveis
      menu = menu.replace(/\$prefix/g, usedPrefix)
                 .replace(/\$sender/g, senderName)
                 .replace(/\$botname/g, botname)
                 .replace(/\$namebot/g, namebot)
                 .replace(/\$users/g, usersCount)
                 .replace(/\$uptime/g, uptime)
                 .replace(/\$link/g, botSettings.link || 'https://whatsapp.com/channel/0029Vb8SJi3BFLgQL1wCTr3N')
                 .replace(/\$botType/g, 'Nexus V12 Intelligence');

      await sock.sendMessage(msg.chat, {
        image: { url: bannerUrl },
        caption: menu.trim(),
        contextInfo: {
          mentionedJid: [msg.sender],
          isForwarded: true,
          forwardedNewsletterMessageInfo: {
            newsletterJid: '120363297626776842@newsletter',
            serverMessageId: '0',
            newsletterName: 'Nexus News'
          }
        }
      }, { quoted: msg });

    } catch (e) {
      console.error(e);
      await msg.reply(`❌ Erro ao gerar menu Nexus: ${e.message}`);
    }
  }
};
