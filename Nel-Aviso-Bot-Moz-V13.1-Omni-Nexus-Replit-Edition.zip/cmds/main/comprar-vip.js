import db from '#db';

export default {
  command: ['comprar-vip', 'assinar-vip'],
  category: 'main',
  description: 'Iniciar processo de compra VIP 💳',
  run: async ({ msg, args, usedPrefix, command }) => {
    if (!args[0]) return msg.reply(`❌ Escolha um plano: *${usedPrefix + command} mensal* ou *${usedPrefix + command} trimestral*`);
    
    const plano = args[0].toLowerCase();
    let valor = 0;
    let dias = 0;
    
    if (plano === 'mensal') { valor = 100; dias = 30; }
    else if (plano === 'trimestral') { valor = 250; dias = 90; }
    else return msg.reply(`❌ Plano inválido! Escolha mensal ou trimestral.`);
    
    const text = `💳 *PAGAMENTO NEXUS VIP* 💳\n\n` +
      `▸ Plano: *${plano.toUpperCase()}*\n` +
      `▸ Valor: *${valor} MT*\n` +
      `▸ Método: *M-Pesa*\n\n` +
      `🚀 *INSTRUÇÕES:* \n` +
      `1. Transfira o valor para *878464656* (Nel Custódio).\n` +
      `2. Envie o comprovativo aqui no chat.\n` +
      `3. O bot ativará o seu VIP automaticamente após detecção.`;
      
    return msg.reply(text);
  }
};
