import db from '#db';

export default {
  command: ['vip', 'premium', 'assinar'],
  category: 'main',
  description: 'Informações sobre o sistema Nexus VIP 💎',
  run: async ({ msg, sender }) => {
    const user = db.getUser(sender);
    const isVip = user.vip > 0;
    
    let text = `💎 *SISTEMA NEXUS VIP* 💎\n\n`;
    text += `Eleve a sua experiência para o nível Elite e desbloqueie o poder total da IA.\n\n`;
    
    text += `🌟 *VANTAGENS VIP:* \n`;
    text += `▸ Acesso ilimitado ao *Nexus-Brain* (GPT-4).\n`;
    text += `▸ Prioridade no processamento de comandos.\n`;
    text += `▸ Comandos exclusivos de produtividade.\n`;
    text += `▸ Selo de distinção no perfil.\n\n`;
    
    text += `💰 *PLANOS:* \n`;
    text += `▸ Mensal: *100 MT*\n`;
    text += `▸ Trimestral: *250 MT*\n\n`;
    
    if (isVip) {
      text += `✅ *O SEU ESTADO:* Você já é um membro VIP!\n`;
    } else {
      text += `🚀 *COMO ASSINAR:* \n`;
      text += `Envie o valor via M-Pesa para *878464656* e responda a esta mensagem com o comprovativo ou use o comando:\n`;
      text += `> *.comprar vip mensal*`;
    }
    
    return msg.reply(text);
  }
};
