import axios from 'axios';

export default {
  command: ['nexus-ai', 'gerar-imagem', 'dalle'],
  category: 'ia',
  description: 'Gerador de imagens ultra-realistas (VIP Elite) 🎨',
  run: async ({ msg, text, usedPrefix, command }) => {
    if (!text) return msg.reply(`🎨 *NEXUS-AI: IMAGEM ELITE*\n\nDescreva a imagem que deseja criar.\nExemplo: *${usedPrefix + command} um astronauta em Maputo, estilo cyberpunk*`);
    
    await msg.react('🎨');
    try {
      const url = `https://api.vreden.web.id/api/ai/dalle3?prompt=${encodeURIComponent(text)}`;
      await msg.sock.sendMessage(msg.chat, { 
        image: { url }, 
        caption: `🎨 *Nexus-AI:* "${text}"\n\n> 💎 _Qualidade Elite V13_` 
      }, { quoted: msg });
      await msg.react('✅');
    } catch (e) {
      console.error(e);
      await msg.reply('❌ Falha ao aceder ao motor gráfico Nexus.');
    }
  }
};
