export default {
  command: ['topmusica', 'topmusic', 'parada', 'charts'],
  category: 'downloads',
  description: 'Ver as músicas mais populares do momento 🎵',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    const { default: yts } = await import('yt-search');

    try {
      const queries = ['top hits 2024', 'mozambique music', 'african music hits', 'kizomba 2024', 'afrobeat hits'];
      const query = text || queries[Math.floor(Math.random() * queries.length)];

      const results = await yts(query);
      const videos = results.videos.slice(0, 10);

      if (!videos.length) return await sock.sendMessage(msg.key.remoteJid, { text: '❌ Nenhuma música encontrada!' }, { quoted: msg });

      let result = `🎵 *TOP MÚSICAS - ${query.toUpperCase()}*\n\n`;

      for (let i = 0; i < videos.length; i++) {
        const v = videos[i];
        const duration = v.timestamp || '??:??';
        const views = v.views ? (v.views > 1000000 ? (v.views / 1000000).toFixed(1) + 'M' : v.views > 1000 ? (v.views / 1000).toFixed(0) + 'K' : v.views) : '0';
        result += `${i + 1 === 1 ? '🥇' : i + 1 === 2 ? '🥈' : i + 1 === 3 ? '🥉' : '  '}${i + 1}. *${v.title}*\n`;
        result += `   ⏱️ ${duration} | 👀 ${views} views\n\n`;
      }

      result += `\n💡 Use *${usedPrefix}musica <nome>* para baixar qualquer uma!`;
      await sock.sendMessage(msg.key.remoteJid, { text: result }, { quoted: msg });
    } catch (e) {
      await sock.sendMessage(msg.key.remoteJid, { text: '❌ Erro ao buscar top músicas. Tente novamente.' }, { quoted: msg });
    }
  }
};
