import fetch from 'node-fetch'

export default {
  command: ['tiktok', 'tt'],
  category: 'downloads',
  description: 'Baixar um video de TikTok.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    if (!args.length) {
      return msg.reply(`《✧》 Por favor, insere um termo de busca ou link de TikTok.`)
    }
    const text = args.join(" ")
    const isUrl = /(?:https:?\/{2})?(?:w{3}|vm|vt|t)?\.?tiktok.com\/([^\s&]+)/gi.test(text)
    const endpoint = isUrl ? `${global.APIs.yuki.url}/dl/tiktok?url=${encodeURIComponent(text)}&key=${global.APIs.yuki.key}` : `${global.APIs.yuki.url}/search/tiktok?query=${encodeURIComponent(text)}&key=${global.APIs.yuki.key}`
    try {
      const res = await fetch(endpoint)
      if (!res.ok) throw new Error(`O servidor respondeu com ${res.status}`)
      const json = await res.json()
      if (!json.status) return msg.reply('《✧》 Não foi encontrado conteúdo válido en TikTok.')
      if (isUrl) {
        const { title, duration, dl, author, stats, created_at, type } = json.data
        if (!dl || (Array.isArray(dl) && dl.length === 0)) return msg.reply('《✧》 Link inválido o sin conteúdo descargable.')
        const caption = `ㅤ۟∩　ׅ　★ ໌　ׅ　🅣𝗂𝗄𝖳𝗈𝗄 🅓ownload　ׄᰙ

𖣣ֶㅤ֯⌗ ✎  ׄ ⬭ *Título:* ${title || 'Sin título'}
𖣣ֶㅤ֯⌗ ꕥ  ׄ ⬭ *Autor:* ${author?.nickname || author?.unique_id || 'Desconhecido'}
𖣣ֶㅤ֯⌗ ⴵ  ׄ ⬭ *Duração:* ${duration || 'N/A'}
𖣣ֶㅤ֯⌗ ❖  ׄ ⬭ *Likes:* ${(stats?.likes || 0).toLocaleString()}
𖣣ֶㅤ֯⌗ ❀  ׄ ⬭ *Comentários:* ${(stats?.comments || 0).toLocaleString()}
𖣣ֶㅤ֯⌗ ✿  ׄ ⬭ *Vistas:* ${(stats?.views || stats?.plays || 0).toLocaleString()}
𖣣ֶㅤ֯⌗ ☆  ׄ ⬭ *Compartidos:* ${(stats?.shares || 0).toLocaleString()}
𖣣ֶㅤ֯⌗ ☁︎  ׄ ⬭ *Data:* ${created_at || 'N/A'}`.trim()
        if (type === 'image') {
          const medias = dl.map(url => ({ type: 'image', data: { url }, caption }))
          await sock.sendAlbumMessage(msg.chat, medias, { quoted: msg })
          const audioRes = await fetch(`https://www.tikwm.com/api/?url=${encodeURIComponent(text)}&hd=1`)
          const audioJson = await audioRes.json()
          const audioUrl = audioJson?.data?.play
          if (audioUrl) {
            await sock.sendMessage(msg.chat, { audio: { url: audioUrl }, mimetype: 'audio/mp4', fileName: 'tiktok_audio.mp4' }, { quoted: msg })
          }
        } else {
          const videoUrl = Array.isArray(dl) ? dl[0] : dl
          await sock.sendMessage(msg.chat, { video: { url: videoUrl }, caption }, { quoted: msg })
        }
      } else {
        const validResults = json.data?.filter(v => v.dl)
        if (!validResults || validResults.length < 2) {
          return msg.reply('《✧》 Se requieren al menos 2 resultados válidos con conteúdo.')
        }
        const medias = validResults.filter(v => typeof v.dl === 'string' && v.dl.startsWith('http')).map(v => {
            const caption = `ㅤ۟∩　ׅ　★ ໌　ׅ　🅣𝗂𝗄𝖳𝗈𝗄 🅓ownload　ׄᰙ

𖣣ֶㅤ֯⌗ ✎  ׄ ⬭ *Título:* ${v.title || 'Sin título'}
𖣣ֶㅤ֯⌗ ꕥ  ׄ ⬭ *Autor:* ${v.author?.nickname || 'Desconhecido'} ${v.author?.unique_id ? `@${v.author.unique_id}` : ''}
𖣣ֶㅤ֯⌗ ⴵ  ׄ ⬭ *Duração:* ${v.duration || 'N/A'}
𖣣ֶㅤ֯⌗ ❖  ׄ ⬭ *Likes:* ${(v.stats?.likes || 0).toLocaleString()}
𖣣ֶㅤ֯⌗ ❀  ׄ ⬭ *Comentários:* ${(v.stats?.comments || 0).toLocaleString()}
𖣣ֶㅤ֯⌗ ✿  ׄ ⬭ *Vistas:* ${(v.stats?.views || 0).toLocaleString()}
𖣣ֶㅤ֯⌗ ☆  ׄ ⬭ *Compartidos:* ${(v.stats?.shares || 0).toLocaleString()}
𖣣ֶㅤ֯⌗ ❒  ׄ ⬭ *Audio:* ${v.music?.title || `[${v.author?.nickname || 'No disponible'}] original sound - ${v.author?.unique_id || 'unknown'}`}`.trim()
            return { type: 'video', data: { url: v.dl }, caption }
          }).slice(0, 10)
        await sock.sendAlbumMessage(msg.chat, medias, { quoted: msg })
      }
    } catch (e) {
      await msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`)
    }
  },
}