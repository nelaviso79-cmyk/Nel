import fetch from 'node-fetch'

export default {
  command: ['drive', 'gdrive'],
  category: 'downloads',
  description: 'Baixar um ficheiro de Google Drive.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    if (!args[0]) {
      return msg.reply('《✧》 Por favor, insere um link de Google Drive.')
    }    
    const url = args[0]
    if (!url.match(/drive\.google\.com\/(file\/d\/|open\?id=|uc\?id=)/)) {
      return msg.reply('《✧》 A URL não parece válida de Google Drive.')
    }    
    try {
      const result = await gdriveScraper(url)
      if (!result.status) {
        return msg.reply('《✧》 Não foi possível obter o ficheiro. Tente com outro link.')
      }      
      const { fileName, fileSize, mimetype, downloadUrl } = result.data
      const caption = `۟　ꕥ ᩧ　𓈒　ׄ　𝖦oogle 𝖣𝗋𝗂𝗏𝖾　ׅ　✿۟\n\n ׄ ﹙ׅ☆﹚ּ *Nome* › ${fileName}\n ׄ ﹙ׅ☆﹚ּ *Tamanho* › ${fileSize}\n ׄ ﹙ׅ☆﹚ּ *Tipo* › ${mimetype}\n\n𖣣ֶㅤ֯⌗ ☆  ⬭ *Link* › ${url}`      
      await sock.sendMessage(msg.chat, { document: { url: downloadUrl }, mimetype, fileName, caption }, { quoted: msg })      
    } catch (e) {
      return msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`)
    }
  }
}

async function gdriveScraper(url) {
  try {
    let id = (url.match(/\/?id=(.+)/i) || url.match(/\/d\/(.*?)\//))[1]
    if (!id) throw new Error('Não foi encontrado ID de descarga')   
    let res = await fetch(`https://drive.google.com/uc?id=${id}&authuser=0&export=download`, { method: 'post', headers: { 'accept-encoding': 'gzip, deflate, br', 'content-length': 0, 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', origin: 'https://drive.google.com', 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', 'x-sock-data': 'CKG1yQEIkbbJAQiitskBCMS2yQEIqZ3KAQioo8oBGLeYygE=', 'x-drive-first-party': 'DriveWebUi', 'x-json-requested': 'true' }})    
    let { fileName, sizeBytes, downloadUrl } = JSON.parse((await res.text()).slice(4))
    if (!downloadUrl) throw new Error('Se excedió o número de descargas do link')
    let data = await fetch(downloadUrl)
    if (data.status !== 200) throw new Error(data.statusText)
    return { status: true, data: { downloadUrl, fileName, fileSize: `${(sizeBytes / (1024 * 1024)).toFixed(2)} MB`, mimetype: data.headers.get('content-type') }}
  } catch (error) {
    return { status: false, message: error.message }
  }
}