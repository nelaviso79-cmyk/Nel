import fetch from 'node-fetch';
import axios from 'axios';
import { spawn } from 'child_process';
import { Readable } from 'stream';
import yts from 'yt-search';
import db from '#db';

const PLATFORMS = {
  youtube: { match: /(?:youtube\.com\/(?:watch|shorts|embed|live)|youtu\.be\/)/i, name: 'YouTube', icon: '🟥' },
  tiktok: { match: /(?:tiktok\.com|vt\.tiktok|vm\.tiktok)/i, name: 'TikTok', icon: '🎵' },
  facebook: { match: /(?:facebook\.com|fb\.watch|fb\.com|video\.fb\.com)/i, name: 'Facebook', icon: '🔵' },
  instagram: { match: /(?:instagram\.com\/(?:p|reel|tv|stories))/i, name: 'Instagram', icon: '🟣' },
  twitter: { match: /(?:twitter\.com|x\.com)\/\w+\/status\//i, name: 'Twitter/X', icon: '🐦' },
  pinterest: { match: /(?:pinterest\.com|pin\.it)/i, name: 'Pinterest', icon: '📌' },
  spotify: { match: /(?:spotify\.com|open\.spotify)/i, name: 'Spotify', icon: '🟢' },
  kwai: { match: /(?:kwai\.com|kuaishou)/i, name: 'Kwai', icon: '🟡' },
  gdrive: { match: /(?:drive\.google\.com)/i, name: 'Google Drive', icon: '📁' },
  mediafire: { match: /(?:mediafire\.com)/i, name: 'MediaFire', icon: '🔥' },
  telegram: { match: /(?:t\.me|telegram\.me|telegram\.org)/i, name: 'Telegram', icon: '✈️' },
  reddit: { match: /(?:reddit\.com|redd\.it)/i, name: 'Reddit', icon: '🟠' },
  twitch: { match: /(?:twitch\.tv)/i, name: 'Twitch', icon: '🟣' },
  soundcloud: { match: /(?:soundcloud\.com)/i, name: 'SoundCloud', icon: '🟠' },
  vimeo: { match: /(?:vimeo\.com)/i, name: 'Vimeo', icon: '🔵' },
  dailymotion: { match: /(?:dailymotion\.com)/i, name: 'Dailymotion', icon: '🔵' },
};

function detectPlatform(text) {
  for (const [key, config] of Object.entries(PLATFORMS)) {
    if (config.match.test(text)) return { key, ...config };
  }
  return null;
}

export default {
  command: ['dl', 'download', 'baixar', 'smartdl', 'pegar', 'save'],
  category: 'downloads',
  description: 'Baixar de QUALQUER plataforma! Facebook, TikTok, Instagram, YouTube, Twitter, etc. Com ou sem URL!',
  run: async ({ msg, sock, args, usedPrefix, command, text, sender }) => {
    if (!text) {
      return msg.reply(
        `⬇️ *DOWNLOAD UNIVERSAL* ⬇️\n\n` +
        `▸ Baixe de *QUALQUER* plataforma!\n▸ Com URL ou sem URL!\n\n` +
        `🔹 *Com URL:*\n` +
        `▸ *${usedPrefix + command} https://www.tiktok.com/...*\n` +
        `▸ *${usedPrefix + command} https://fb.watch/...*\n` +
        `▸ *${usedPrefix + command} https://instagram.com/reel/...*\n\n` +
        `🔹 *Sem URL (busca pelo nome):*\n` +
        `▸ *${usedPrefix + command} música Burna Boy Last Last*\n` +
        `▸ *${usedPrefix + command} vídeo de gatos engraçados*\n\n` +
        `📋 *Plataformas suportadas:*\n` +
        `▸ YouTube 🟥 | TikTok 🎵 | Facebook 🔵\n` +
        `▸ Instagram 🟣 | Twitter/X 🐦 | Pinterest 📌\n` +
        `▸ Spotify 🟢 | Kwai 🟡 | Reddit 🟠\n` +
        `▸ SoundCloud 🟠 | Vimeo 🔵 | Dailymotion 🔵\n` +
        `▸ Google Drive 📁 | MediaFire 🔥 | Telegram ✈️\n\n` +
        `💡 *Dica:* Se não colocar URL, ele busca no YouTube!`
      );
    }

    const isUrl = /^https?:\/\//i.test(text.trim());
    const platform = isUrl ? detectPlatform(text) : null;

    await msg.react('⬇️');

    try {
      if (platform) {
        // ===== DOWNLOAD COM URL =====
        await handleUrlDownload(msg, sock, text, platform, usedPrefix, command);
      } else {
        // ===== DOWNLOAD SEM URL - BUSCAR NO YOUTUBE =====
        await handleSearchDownload(msg, sock, text, usedPrefix, command);
      }
    } catch (e) {
      await msg.reply(`> Erro ao executar *${usedPrefix + command}*.\n> [Erro: *${e.message}*]`);
    }
  },
};

async function handleUrlDownload(msg, sock, url, platform, usedPrefix, command) {
  const { key } = await sock.sendMessage(msg.chat, {
    text: `${platform.icon} A baixar de *${platform.name}*...\n⏳ Aguarde...`
  }, { quoted: msg });

  let result = null;

  switch (platform.key) {
    case 'youtube':
      result = await downloadYouTube(url);
      break;
    case 'tiktok':
      result = await downloadTikTok(url);
      break;
    case 'facebook':
      result = await downloadFacebook(url);
      break;
    case 'instagram':
      result = await downloadInstagram(url);
      break;
    case 'twitter':
      result = await downloadTwitter(url);
      break;
    case 'pinterest':
      result = await downloadPinterest(url);
      break;
    case 'spotify':
      result = await downloadSpotify(url);
      break;
    case 'kwai':
      result = await downloadKwai(url);
      break;
    case 'gdrive':
      result = await downloadGDrive(url);
      break;
    case 'mediafire':
      result = await downloadMediaFire(url);
      break;
    case 'telegram':
      result = await downloadTelegram(url);
      break;
    case 'reddit':
      result = await downloadReddit(url);
      break;
    case 'soundcloud':
      result = await downloadSoundCloud(url);
      break;
    case 'vimeo':
    case 'dailymotion':
      result = await downloadGeneric(url);
      break;
    default:
      result = await downloadGeneric(url);
      break;
  }

  if (!result) {
    return sock.sendMessage(msg.chat, {
      text: `❧ Não foi possível baixar de *${platform.name}*.\n▸ Tente novamente ou use o comando específico da plataforma.`,
      edit: key
    }, { quoted: msg });
  }

  await sendResult(msg, sock, result, platform, key);
}

async function handleSearchDownload(msg, sock, query, usedPrefix, command) {
  const { key } = await sock.sendMessage(msg.chat, {
    text: `🔍 A procurar: *${query}*...\n⏳ Aguarde...`
  }, { quoted: msg });

  try {
    const search = await yts(query);
    const video = search.videos?.[0] || search.all?.find(v => v.type === 'video');
    if (!video) {
      return sock.sendMessage(msg.chat, {
        text: `❧ Nenhum resultado encontrado para: *${query}*`,
        edit: key
      }, { quoted: msg });
    }

    const url = video.url;
    const title = video.title;
    const channel = video.author?.name || 'Desconhecido';
    const duration = video.timestamp || 'Desconhecido';
    const views = Number(video.views || 0).toLocaleString('pt-MZ');

    await sock.sendMessage(msg.chat, {
      text: `🎵 Encontrado: *${title}*\n▸ Canal: ${channel}\n▸ Duração: ${duration}\n▸ Vistas: ${views}\n\n⬇️ A baixar áudio...`,
      edit: key
    }, { quoted: msg });

    const result = await downloadYouTube(url);
    if (result) {
      await sendResult(msg, sock, result, { name: 'YouTube', icon: '🟥' }, key);
    } else {
      await msg.reply('❧ Erro ao baixar. Tente com o comando *musica* ou *play*.');
    }
  } catch (e) {
    await msg.reply(`❧ Erro na busca: ${e.message}`);
  }
}

async function sendResult(msg, sock, result, platform, key) {
  const caption = result.caption || `${platform.icon} *${platform.name} Download*\n\n${result.title ? `▸ Título: *${result.title}*\n` : ''}`;

  if (result.type === 'audio') {
    if (result.buffer) {
      await sock.sendMessage(msg.chat, {
        document: result.buffer,
        fileName: result.filename || 'audio.mp3',
        mimetype: 'audio/mpeg',
        caption
      }, { quoted: msg });
      if (result.buffer.length < 15 * 1024 * 1024) {
        await sock.sendMessage(msg.chat, {
          audio: result.buffer,
          fileName: result.filename || 'audio.mp3',
          mimetype: 'audio/mpeg'
        }, { quoted: msg });
      }
    } else if (result.url) {
      await sock.sendMessage(msg.chat, {
        audio: { url: result.url },
        fileName: result.filename || 'audio.mp3',
        mimetype: 'audio/mp4'
      }, { quoted: msg });
    }
  } else if (result.type === 'video') {
    if (result.url) {
      try {
        await sock.sendMessage(msg.chat, {
          video: { url: result.url },
          fileName: result.filename || 'video.mp4',
          mimetype: 'video/mp4',
          caption
        }, { quoted: msg });
      } catch {
        await sock.sendMessage(msg.chat, {
          document: { url: result.url },
          fileName: result.filename || 'video.mp4',
          mimetype: 'video/mp4',
          caption
        }, { quoted: msg });
      }
    }
  } else if (result.type === 'image') {
    if (result.url) {
      await sock.sendMessage(msg.chat, {
        image: { url: result.url },
        caption
      }, { quoted: msg });
    }
  } else if (result.type === 'document') {
    if (result.url) {
      await sock.sendMessage(msg.chat, {
        document: { url: result.url },
        fileName: result.filename || 'file',
        mimetype: result.mimetype || 'application/octet-stream',
        caption
      }, { quoted: msg });
    }
  }
  await msg.react('✅');
}

// ===== DOWNLOAD FUNCTIONS =====

async function downloadYouTube(url) {
  const videoId = getVideoId(url);
  if (!videoId) return null;
  
  const youtubei = {
    endpoint: 'https://www.youtube.com/youtubei/v1/player?prettyPrint=false',
    visitor_id: 'Cgs4ZmxfcDk4Vnk0VSjLvdrQBjIKCgJJRBIEGgAgXmLfAgrcAjE4LllUPWNsWWh5eHVVeE04N1AzV0tnZzZJeFpkV3lGOEVRNnJaei1DQ3hRTkdHV1NFcjg1MmpVQmZ6UzMtOE5zTVVSZ3EzbHFXUHFRZERyV0M3a2g2TlFEdUZybmJRbjkyc1JGVGxVd3MyZG5RMmFmVG95TlJnTXJReTdMNlRTOEVqcTFhaW5OQnJhOU9uRnJRa01IOGpVTzdiR3UwQVpqdjI0UURqNkdmeE1VcWVZc184cGxfOUNNVExVRG9HQ09sa1NPOUVHZG5CcWdUVzVRZ080OGRyQWxDeVRHUF9MRnhBNjVYZVVRR1FBeGxmU0ZSckhhRHI0cDROLWV2cmp0VDdEc3pKU3Q1clhSYkNmWWQ0YjJqbFN5NVh0ejMyajk5NWdkSGhLU1htcTcydHNGeDNUOW5xZXQ3UlZvV2JNbmNGWDBKTldqbXZyQzg0VHhqY1hCVFlnQ2dLQQ==',
    client_name: 'ANDROID_VR',
    client_version: '1.65.10',
    itag: 18
  };

  try {
    const response = await fetch(youtubei.endpoint, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'X-Goog-Visitor-Id': youtubei.visitor_id },
      body: JSON.stringify({
        context: { client: { clientName: youtubei.client_name, clientVersion: youtubei.client_version } },
        videoId: videoId
      })
    });
    const json = await response.json();
    const formats = json?.streamingData?.formats || [];
    const stream = formats.find(item => Number(item?.itag) === youtubei.itag && item?.url);
    if (!stream?.url) return null;
    
    const title = json?.videoDetails?.title || 'YouTube Audio';
    const channel = json?.videoDetails?.author || 'Desconhecido';
    const duration = json?.videoDetails?.lengthSeconds ? formatDuration(Number(json.videoDetails.lengthSeconds)) : 'N/A';

    // Baixar e converter para mp3
    const audioResponse = await fetch(stream.url, {
      headers: { 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
    });
    if (!audioResponse.ok) return null;
    
    const input_stream = typeof audioResponse.body.pipe === 'function' ? audioResponse.body : Readable.fromWeb(audioResponse.body);
    const buffer = await convertToMp3(input_stream);
    
    return {
      type: 'audio',
      buffer,
      filename: `${sanitizeFileName(title)}.mp3`,
      title,
      caption: `🟥 *YouTube Download*\n\n▸ Título: *${title}*\n▸ Canal: ${channel}\n▸ Duração: ${duration}\n▸ Formato: MP3\n▸ Tamanho: ${formatBytes(buffer.length)}`
    };
  } catch { return null; }
}

async function downloadTikTok(url) {
  const apis = [
    `${global.APIs.yuki.url}/dl/tiktok?url=${encodeURIComponent(url)}&key=${global.APIs.yuki.key}`,
    `${global.APIs.delirius.url}/download/tiktok?url=${encodeURIComponent(url)}`,
    `https://www.tikwm.com/api/?url=${encodeURIComponent(url)}&hd=1`
  ];
  for (const endpoint of apis) {
    try {
      const res = await fetch(endpoint);
      const json = await res.json();
      if (json.status || json.code === 0) {
        const data = json.data || json.result;
        if (data) {
          const videoUrl = Array.isArray(data.dl) ? data.dl[0] : data.dl || data.play || data.video;
          if (videoUrl) {
            return {
              type: 'video',
              url: videoUrl,
              filename: 'tiktok.mp4',
              title: data.title || 'TikTok Video',
              caption: `🎵 *TikTok Download*\n\n▸ Título: *${data.title || 'Sem título'}*\n▸ Autor: ${data.author?.nickname || 'Desconhecido'}\n▸ Likes: ${(data.stats?.likes || 0).toLocaleString()}\n▸ Vistas: ${(data.stats?.views || data.stats?.plays || 0).toLocaleString()}`
            };
          }
        }
      }
    } catch { continue; }
  }
  return null;
}

async function downloadFacebook(url) {
  const apis = [
    `${global.APIs.yuki.url}/dl/facebook?url=${encodeURIComponent(url)}&key=${global.APIs.yuki.key}`,
    `${global.APIs.delirius.url}/download/facebook?url=${encodeURIComponent(url)}`,
  ];
  for (const endpoint of apis) {
    try {
      const res = await fetch(endpoint);
      const json = await res.json();
      if (json.status) {
        const data = json.data || json.result;
        if (data?.url || data?.dl) {
          const videoUrl = data.url || data.dl;
          return {
            type: 'video',
            url: videoUrl,
            filename: 'facebook.mp4',
            title: data.title || 'Facebook Video',
            caption: `🔵 *Facebook Download*\n\n${data.title ? `▸ Título: *${data.title}*\n` : ''}▸ Formato: MP4`
          };
        }
      }
    } catch { continue; }
  }
  return null;
}

async function downloadInstagram(url) {
  const apis = [
    `${global.APIs.yuki.url}/dl/instagram?url=${encodeURIComponent(url)}&key=${global.APIs.yuki.key}`,
    `${global.APIs.delirius.url}/download/instagram?url=${encodeURIComponent(url)}`,
    `${global.APIs.ootaizumi.url}/downloader/instagram/v1?url=${encodeURIComponent(url)}`
  ];
  for (const endpoint of apis) {
    try {
      const res = await fetch(endpoint);
      const json = await res.json();
      if (json.status) {
        const media = json.data?.[0] || json.result?.media?.[0];
        if (media?.url) {
          const isVideo = media.isVideo || media.type === 'video' || media.url.includes('.mp4');
          return {
            type: isVideo ? 'video' : 'image',
            url: media.url,
            filename: isVideo ? 'instagram.mp4' : 'instagram.jpg',
            title: json.result?.metadata?.author || 'Instagram',
            caption: `🟣 *Instagram Download*\n\n${json.result?.metadata?.author ? `▸ Autor: ${json.result.metadata.author}\n` : ''}▸ Tipo: ${isVideo ? 'Vídeo' : 'Imagem'}`
          };
        }
      }
    } catch { continue; }
  }
  return null;
}

async function downloadTwitter(url) {
  const apis = [
    `${global.APIs.delirius.url}/download/twitterdl?url=${encodeURIComponent(url)}`,
    `${global.APIs.yuki.url}/dl/twitter?url=${encodeURIComponent(url)}&key=${global.APIs.yuki.key}`,
  ];
  for (const endpoint of apis) {
    try {
      const res = await fetch(endpoint);
      const json = await res.json();
      const mediaUrl = json.media?.[0]?.url || json.data?.result?.[0]?.url || json.result?.[0]?.url;
      if (mediaUrl) {
        return {
          type: 'video',
          url: mediaUrl,
          filename: 'twitter.mp4',
          title: json.info?.text || json.data?.title || 'Twitter Video',
          caption: `🐦 *Twitter/X Download*\n\n▸ Autor: ${json.info?.user_name || 'Desconhecido'}`
        };
      }
    } catch { continue; }
  }
  return null;
}

async function downloadPinterest(url) {
  const apis = [
    `${global.APIs.yuki.url}/dl/pinterest?url=${encodeURIComponent(url)}&key=${global.APIs.yuki.key}`,
    `${global.APIs.delirius.url}/download/pinterestdl?url=${encodeURIComponent(url)}`
  ];
  for (const endpoint of apis) {
    try {
      const res = await fetch(endpoint);
      const json = await res.json();
      if (json.status) {
        const dlUrl = json.result?.best?.url || json.data?.download?.url || json.resultado?.url;
        if (dlUrl) {
          const isVideo = dlUrl.includes('.mp4');
          return {
            type: isVideo ? 'video' : 'image',
            url: dlUrl,
            filename: isVideo ? 'pinterest.mp4' : 'pinterest.jpg',
            title: json.data?.title || 'Pinterest',
            caption: `📌 *Pinterest Download*\n\n▸ Tipo: ${isVideo ? 'Vídeo' : 'Imagem'}`
          };
        }
      }
    } catch { continue; }
  }
  return null;
}

async function downloadSpotify(url) {
  const apis = [
    `${global.APIs.delirius.url}/download/spotify?url=${encodeURIComponent(url)}`,
    `${global.APIs.yuki.url}/dl/spotify?url=${encodeURIComponent(url)}&key=${global.APIs.yuki.key}`
  ];
  for (const endpoint of apis) {
    try {
      const res = await fetch(endpoint);
      const json = await res.json();
      if (json.status) {
        const data = json.data || json.result;
        const dlUrl = data?.download || data?.dl || data?.url;
        if (dlUrl) {
          return {
            type: 'audio',
            url: dlUrl,
            filename: `${sanitizeFileName(data?.title || 'spotify')}.mp3`,
            title: data?.title || data?.name || 'Spotify',
            caption: `🟢 *Spotify Download*\n\n▸ Título: *${data?.title || data?.name || 'N/A'}*\n▸ Artista: ${data?.artist || data?.artists || 'N/A'}\n▸ Álbum: ${data?.album || 'N/A'}`
          };
        }
      }
    } catch { continue; }
  }
  return null;
}

async function downloadKwai(url) {
  const apis = [
    `${global.APIs.delirius.url}/download/kwai?url=${encodeURIComponent(url)}`,
  ];
  for (const endpoint of apis) {
    try {
      const res = await fetch(endpoint);
      const json = await res.json();
      if (json.status) {
        const data = json.data || json.result;
        const dlUrl = data?.download || data?.dl || data?.url;
        if (dlUrl) {
          return {
            type: 'video',
            url: dlUrl,
            filename: 'kwai.mp4',
            title: data?.title || 'Kwai Video',
            caption: `🟡 *Kwai Download*\n\n▸ Título: *${data?.title || 'N/A'}*`
          };
        }
      }
    } catch { continue; }
  }
  return null;
}

async function downloadGDrive(url) {
  try {
    let id = (url.match(/\/?id=(.+)/i) || url.match(/\/d\/(.*?)\//))?.[1];
    if (!id) return null;
    const res = await fetch(`https://drive.google.com/uc?id=${id}&authuser=0&export=download`, {
      method: 'post',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' }
    });
    const text = await res.text();
    const { fileName, sizeBytes, downloadUrl } = JSON.parse(text.slice(4));
    if (!downloadUrl) return null;
    return {
      type: 'document',
      url: downloadUrl,
      filename: fileName || 'gdrive_file',
      title: fileName || 'Google Drive',
      caption: `📁 *Google Drive Download*\n\n▸ Nome: *${fileName}*\n▸ Tamanho: ${sizeBytes ? formatBytes(sizeBytes) : 'N/A'}`
    };
  } catch { return null; }
}

async function downloadMediaFire(url) {
  try {
    const res = await fetch(url);
    const html = await res.text();
    const dlMatch = html.match(/href="(https?:\/\/download[^"]+)"/i);
    if (!dlMatch) return null;
    return {
      type: 'document',
      url: dlMatch[1],
      filename: 'mediafire_file',
      title: 'MediaFire',
      caption: `🔥 *MediaFire Download*`
    };
  } catch { return null; }
}

async function downloadTelegram(url) {
  const apis = [
    `${global.APIs.delirius.url}/download/telegram?url=${encodeURIComponent(url)}`,
  ];
  for (const endpoint of apis) {
    try {
      const res = await fetch(endpoint);
      const json = await res.json();
      if (json.status) {
        const data = json.data || json.result;
        const dlUrl = data?.download || data?.dl || data?.url;
        if (dlUrl) {
          return {
            type: data.type === 'video' ? 'video' : 'document',
            url: dlUrl,
            filename: data.filename || 'telegram_file',
            title: 'Telegram',
            caption: `✈️ *Telegram Download*`
          };
        }
      }
    } catch { continue; }
  }
  return null;
}

async function downloadReddit(url) {
  const apis = [
    `${global.APIs.delirius.url}/download/reddit?url=${encodeURIComponent(url)}`,
  ];
  for (const endpoint of apis) {
    try {
      const res = await fetch(endpoint);
      const json = await res.json();
      if (json.status) {
        const data = json.data || json.result;
        const dlUrl = data?.download || data?.dl || data?.url;
        if (dlUrl) {
          return {
            type: data.type === 'video' ? 'video' : 'image',
            url: dlUrl,
            filename: data.type === 'video' ? 'reddit.mp4' : 'reddit.jpg',
            title: data.title || 'Reddit',
            caption: `🟠 *Reddit Download*\n\n${data.title ? `▸ Título: *${data.title}*\n` : ''}`
          };
        }
      }
    } catch { continue; }
  }
  return null;
}

async function downloadSoundCloud(url) {
  const apis = [
    `${global.APIs.delirius.url}/download/soundcloud?url=${encodeURIComponent(url)}`,
  ];
  for (const endpoint of apis) {
    try {
      const res = await fetch(endpoint);
      const json = await res.json();
      if (json.status) {
        const data = json.data || json.result;
        const dlUrl = data?.download || data?.dl || data?.url;
        if (dlUrl) {
          return {
            type: 'audio',
            url: dlUrl,
            filename: `${sanitizeFileName(data?.title || 'soundcloud')}.mp3`,
            title: data?.title || 'SoundCloud',
            caption: `🟠 *SoundCloud Download*\n\n▸ Título: *${data?.title || 'N/A'}*\n▸ Artista: ${data?.author || 'N/A'}`
          };
        }
      }
    } catch { continue; }
  }
  return null;
}

async function downloadGeneric(url) {
  const apis = [
    `${global.APIs.delirius.url}/download/all?url=${encodeURIComponent(url)}`,
    `${global.APIs.yuki.url}/dl/all?url=${encodeURIComponent(url)}&key=${global.APIs.yuki.key}`
  ];
  for (const endpoint of apis) {
    try {
      const res = await fetch(endpoint);
      const json = await res.json();
      if (json.status) {
        const data = json.data || json.result;
        const dlUrl = data?.download || data?.dl || data?.url;
        if (dlUrl) {
          return {
            type: data.type === 'video' ? 'video' : data.type === 'audio' ? 'audio' : 'document',
            url: dlUrl,
            filename: data.filename || 'download',
            title: data.title || 'Download',
            caption: `⬇️ *Download*\n\n▸ Título: *${data.title || 'N/A'}*`
          };
        }
      }
    } catch { continue; }
  }
  return null;
}

// ===== HELPER FUNCTIONS =====

function getVideoId(text = '') {
  const raw = String(text || '').trim();
  if (/^[a-zA-Z0-9_-]{11}$/.test(raw)) return raw;
  const patterns = [
    /youtu\.be\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/live\/([a-zA-Z0-9_-]{11})/
  ];
  for (const p of patterns) { const m = raw.match(p); if (m?.[1]) return m[1]; }
  return null;
}

function sanitizeFileName(name = 'file') {
  return String(name).replace(/[\\/:*?"<>|]/g, '').replace(/\s+/g, ' ').trim().slice(0, 120) || 'file';
}

function formatDuration(seconds = 0) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  return h > 0 ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` : `${m}:${String(s).padStart(2, '0')}`;
}

function formatBytes(bytes = 0) {
  if (!bytes) return 'N/A';
  const units = ['B', 'KB', 'MB', 'GB'];
  let size = Number(bytes), unit = 0;
  while (size >= 1024 && unit < units.length - 1) { size /= 1024; unit++; }
  return `${size.toFixed(unit === 0 ? 0 : 2)} ${units[unit]}`;
}

function convertToMp3(input_stream) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    const errors = [];
    let done = false;
    const ffmpeg = spawn('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-i', 'pipe:0', '-vn', '-map', 'a:0', '-acodec', 'libmp3lame', '-b:a', '128k', '-ar', '44100', '-f', 'mp3', 'pipe:1'], { stdio: ['pipe', 'pipe', 'pipe'] });
    const fail = error => { if (done) return; done = true; try { input_stream.destroy?.(); } catch {} try { ffmpeg.kill('SIGKILL'); } catch {} reject(error); };
    ffmpeg.stdout.on('data', chunk => chunks.push(chunk));
    ffmpeg.stderr.on('data', chunk => errors.push(chunk));
    ffmpeg.on('error', fail);
    ffmpeg.on('close', code => {
      if (done) return; done = true;
      if (code !== 0) { reject(new Error(Buffer.concat(errors).toString().trim() || `FFmpeg código ${code}`)); return; }
      const buffer = Buffer.concat(chunks);
      if (!buffer.length) { reject(new Error('Sem áudio')); return; }
      resolve(buffer);
    });
    input_stream.on('error', fail);
    ffmpeg.stdin.on('error', error => { if (error?.code !== 'EPIPE') fail(error); });
    input_stream.pipe(ffmpeg.stdin);
  });
}
