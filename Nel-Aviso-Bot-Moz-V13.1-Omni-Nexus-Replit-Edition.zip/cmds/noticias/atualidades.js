import fetch from 'node-fetch';

export default {
  command: ['noticias', 'news', 'atualidades', 'info'],
  category: 'noticias',
  description: 'Traz as notícias mais recentes de Moçambique e do Mundo.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const query = args[0]?.toLowerCase();
    
    await msg.react('📰');
    
    try {
      let url = '';
      let titulo = '';
      
      if (query === 'mz' || query === 'mocambique') {
        url = `https://api.vreden.web.id/api/search/google?query=noticias+mocambique+hoje`;
        titulo = '🇲🇿 *NOTÍCIAS DE MOÇAMBIQUE* 🇲🇿';
      } else {
        url = `https://api.vreden.web.id/api/search/google?query=noticias+mundo+hoje+atualidades`;
        titulo = '🌐 *NOTÍCIAS DO MUNDO* 🌐';
      }

      const res = await fetch(url);
      const json = await res.json();
      
      if (!json.status || !json.result || json.result.length === 0) {
        return msg.reply('❌ Não consegui encontrar notícias recentes. Tenta mais tarde.');
      }

      let resposta = `${titulo}\n\n`;
      json.result.slice(0, 5).forEach((item, i) => {
        resposta += `*${i + 1}. ${item.title}*\n📖 ${item.description.slice(0, 150)}...\n🔗 ${item.link}\n\n`;
      });

      resposta += `> 💡 _Dica: Usa *${usedPrefix + command} mz* para notícias locais._\n`;
      resposta += `> 👑 _Nel-Aviso-Bot: A informação em primeiro lugar._`;

      await msg.reply(resposta);
      await msg.react('✅');
    } catch (e) {
      console.error(e);
      await msg.react('❌');
      await msg.reply(`❌ Erro ao buscar notícias: ${e.message}`);
    }
  }
};
