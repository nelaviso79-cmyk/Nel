import db from '#db';
export default {
  command: ['w', 'work', 'chambear', 'trabalhar'],
  category: 'economy',
  description: 'Ganar coins trabajando.',
  run: async ({ msg, sock, usedPrefix, command, text }) => {
    const chat = db.getChat(msg.chat);
    if (chat.adminonly || !chat.economy) {
      return msg.reply(`ꕥ Los comandos de *Economia* están desactivados en este grupo.\n\nUn *administrador* puede activarlos con o comando:\n» *${usedPrefix}economy on*`);
    }
    const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    const settings = db.getSettings(botId);
    const moedas = settings.currency;
    db.setCreate('chat_users', [msg.chat, msg.sender], 'lastwork', 0);
    const user = db.getChatUser(msg.chat, msg.sender);
    const cooldown = 3 * 60 * 1000;
    if (Date.now() < user.lastwork) {
      const tiempoRestante = formatTime(user.lastwork - Date.now());
      return sock.reply(msg.chat, `ꕥ Deves esperar *${tiempoRestante}* para usar *${usedPrefix + command}* de nuevo.`, msg);
    }
    const rsl = Math.floor(Math.random() * (4000 - 2000 + 1)) + 2000;
    db.setChatUser(msg.chat, msg.sender, 'lastwork', Date.now() + cooldown);
    db.setChatUser(msg.chat, msg.sender, 'coins', (user.coins || 0) + rsl);    
    await sock.sendMessage(msg.chat, { text: `❀ ${pickRandom(trabalho)} *¥${rsl.toLocaleString()} ${moedas}*.` }, { quoted: msg });
  }
};

function formatTime(ms) {
  const totalSec = Math.ceil(ms / 1000);
  const minutes = Math.floor((totalSec % 3600) / 60);
  const seconds = totalSec % 60;
  const parts = [];
  if (minutes > 0) parts.push(`${minutes} minuto${minutes !== 1 ? 's' : ''}`);
  parts.push(`${seconds} segundo${seconds !== 1 ? 's' : ''}`);
  return parts.join(' ');
}

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}

const trabalho = [
  "Trabajas como recolector de fresas e ganhas",
  "Trabalhas como assistente numa oficina de cerâmica e obténs",
  "Diseñas páginas web e ganhas",
  "Eres fotógrafo de bodas e recebes",
  "Trabajas en uma loja de mascotas e ganhas",
  "Eres narrador de audiolibros e obténs",
  "Demonstras no departamento de arte e ganhas",
  "Trabalhas como jardineiro num parque e recebes",
  "Eres un DJ en fiestas e ganhas",
  "Fizeste um mural numa cafetaria e deram-te",
  "Trabajas como diseñador de interiores e ganhas",
  "Eres un conductor de autobús turístico e obténs",
  "Preparas sushi en um restaurante e ganhas",
  "Trabalhas como assistente de investigação e recebes",
  "Eres especialista en marketing de conteúdos e ganhas",
  "Trabalhas numa quinta orgânica e obténs",
  "Trabalhas como bailarino num espectáculo e ganhas",
  "Organizas ferias de arte e recebes",
  "És um escritor freelance e ganhas",
  "Fizeste um design gráfico para uma campanha e pagaram-te",
  "Trabajas como mecánico de automóviles e ganhas",
  "És um instrutor de surf e recebes",
  "Limpias casas como servicio de limpieza e ganhas",
  "Eres un técnico de sonido en conciertos e obténs",
  "Trabajas como desarrollador de aplicaciones e ganhas",
  "Trabalhas como croupier num casino e recebes",
  "Trabajas como estilista de cabello e ganhas",
  "És um restaurador de arte e obténs",
  "Trabalhas numa livraria e ganhas",
  "Eres un guía de montañismo e recebes",
  "Llevas un blog de viajes e ganhas",
  "Fizeste uma campanha de crowdfunding e obtiveste",
  "Trabajas como asistente social e ganhas",
  "Eres un conductor de camión de carga e recebes",
  "Trabalhas numa equipa de resgate e ganhas",
  "Eres un consultor de negocios e obténs",
  "Realizas catas de vino e ganhas",
  "Trabalhas como barista numa cafetaria e recebes",
  "Eres un entrenador de mascotas e ganhas",
  "Fizeste um documental para uma ONG e recebeste",
  "És um operador de drones e ganhas",
  "Trabalhas numa produtora de cinema e obténs",
  "Eres un investigador de mercados e ganhas",
  "Trabajas como repartidor de comida e recebes",
  "Eres un acupunturista e ganhas",
  "Fizeste um design de joias e obtiveste",
  "Trabajas como especialista em atendimento ao cliente e ganhas",
  "Eres un conservador de museos e recebes",
  "Trabajas en um centro de reabilitação e obténs",
  "Eres un piloto de helicóptero e ganhas",
  "Hiciste una campanha de conscientização e deram-te",
  "Trabalhas numa oficina de mecânica e ganhas",
  "Eres un organizador de eventos deportivos e recebes",
  "Desenvolves uma aplicação educativa e ganhas",
  "Eres un técnico en redes informáticas e obténs",
  "Trabajas como assistente de produção em teatro e ganhas",
  "Eres un ilustrador de libros para niños e recebes",
  "Trabajas en um centro de yoga e obténs",
  "És um chef pessoal e ganhas",
  "Realizas un calendario de fotos e recebeste",
  "És um promotor de saúde e bem-estar e ganhas",
  "Trabajas como decorador de interiores e recebes",
  "Eres un arreglista floral e ganhas",
  "Organizas un festival de música e obténs",
  "És um jornalista de investigação e ganhas",
  "Trabajas como assistente técnico num estúdio de gravação e recebes",
  "Eres un mecánico de bicicletas e ganhas",
  "Hiciste un video viral e obtiveste",
  "Trabajas como investigador de ciencias sociales e ganhas",
  "Eres un organizador de conferencias e recebes",
  "Dibujo de caricaturas en eventos e ganhas",
  "Eres un responsable de relaciones públicas e obténs",
  "Trabajas como coach de vida e ganhas",
  "Eres un educador en um centro cultural e recebes",
  "Eres un director de fotografía e ganhas",
  "Trabalhas num refúgio de animais e obténs",
  "Eres un guía en almuerzos y cenas temáticas e ganhas",
  "Hiciste un preicto de arte comunitario e recebeste",
  "Eres un traductor de documentos e obténs",
  "Trabalhas como assistente pessoal de um executivo e ganhas",
  "Eres un especialista en sostenibilidad e recebes",
  "Realizas un programa de radio e ganhas",
  "Trabajas como tasador de arte e obténs",
  "Eres un creador de conteúdo en redes sociales e ganhas",
  "Fizeste um workshop de manualidades e recebeste"
];