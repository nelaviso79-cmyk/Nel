import db from '#db';
export default {
  command: ['pescar', 'fish'],
  category: 'economy',
  description: 'Ganar coins pescando.',
  run: async ({ msg, sock, usedPrefix, text }) => {
    const chat = db.getChat(msg.chat);
    if (chat.adminonly || !chat.economy) {
      return msg.reply(`ꕥ Los comandos de *Economia* están desactivados en este grupo.\n\nUn *administrador* puede activarlos con o comando:\n» *${usedPrefix}economy on*`);
    }    
    const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    const settings = db.getSettings(botId);
    const currency = settings.currency;
    db.setCreate('chat_users', [msg.chat, msg.sender], 'tools', {});
    db.setCreate('chat_users', [msg.chat, msg.sender], 'lastfish', 0);    
    let user = db.getChatUser(msg.chat, msg.sender);
    if (user.tools && typeof user.tools === 'string') {
      try { user.tools = JSON.parse(user.tools); } catch { user.tools = {}; }
    }    
    const staminaConsumed = Math.floor(Math.random() * (5 - 1 + 1)) + 1;
    if (user.stamina < staminaConsumed) {
      return msg.reply(`ꕥ Não tens suficiente energía para salir de pescar.\n> Usa *${usedPrefix}heal* para curarte.`);
    }    
    if (!user.tools?.vara) {
      return msg.reply(`ꕥ Precisas uma Vara de pescar para pescar.\n> Compra uma na loja com: *${usedPrefix}comprar vara*`);
    }    
    if (user.tools.vara.durability <= 10) {
      delete user.tools.vara;
      db.setChatUser(msg.chat, msg.sender, 'tools', user.tools);
      return msg.reply(`ꕥ A tua Vara de pescar partiu-se por uso e foi removida do teu inventário.\n> Compra uma nova com: *${usedPrefix}comprar vara*`);
    }    
    const remainingTime = user.lastfish - Date.now();
    if (remainingTime > 0) {
      return msg.reply(`ꕥ Deves esperar *${msToTime(remainingTime)}* antes de volver a pescar.`);
    }    
    user.stamina -= staminaConsumed;
    db.setChatUser(msg.chat, msg.sender, 'stamina', user.stamina);    
    const rand = Math.random();
    const durabilityConsumed = Math.floor(Math.random() * (15 - 1 + 1)) + 1;
    let cantidad;
    let message;    
    if (rand < 0.4) {
      user.tools.vara.durability -= durabilityConsumed;
      if (user.tools.vara.durability <= 10) {
        delete user.tools.vara;
      }
      db.setChatUser(msg.chat, msg.sender, 'tools', user.tools);      
      cantidad = Math.floor(Math.random() * (8000 - 6000 + 1)) + 6000;
      user.coins += cantidad;
      db.setChatUser(msg.chat, msg.sender, 'coins', user.coins);      
      const successMessages = [
        `Pescaste um Salmão com a tua Vara! Ganhaste *¥${cantidad.toLocaleString()} ${currency}*!`,
        `Pescaste uma Truta com a tua Vara! Ganhaste *¥${cantidad.toLocaleString()} ${currency}*!`,
        `Capturaste um Tubarão com a tua Vara! Ganhaste *¥${cantidad.toLocaleString()} ${currency}*!`,
        `Has pescado una Ballena con tu Vara! Ganhaste *¥${cantidad.toLocaleString()} ${currency}*!`,
        `Has capturado un Pez Payaso con tu Vara! Ganhaste *¥${cantidad.toLocaleString()} ${currency}*!`,
        `Has atrapado una Anguila Dorada con tu Vara! Ganhaste *¥${cantidad.toLocaleString()} ${currency}*!`,
        `Has pescado un Mero Gigante con tu Vara! Ganhaste *¥${cantidad.toLocaleString()} ${currency}*!`,
        `Has capturado un Pulpo azul con tu Vara! Ganhaste *¥${cantidad.toLocaleString()} ${currency}*!`,
        `Sacaste una Carpa Real con tu Vara! Ganhaste *¥${cantidad.toLocaleString()} ${currency}*!`,
        `Has conseguido un Pez Dragón con tu Vara! Ganhaste *¥${cantidad.toLocaleString()} ${currency}*!`
      ];
      message = pickRandom(successMessages);
    } else if (rand < 0.7) {
      user.tools.vara.durability -= durabilityConsumed;
      if (user.tools.vara.durability <= 10) {
        delete user.tools.vara;
      }
      db.setChatUser(msg.chat, msg.sender, 'tools', user.tools);      
      cantidad = Math.floor(Math.random() * (6500 - 5000 + 1)) + 5000;
      const total = (user.coins || 0) + (user.bank || 0);
      if (total >= cantidad) {
        if (user.coins >= cantidad) {
          user.coins -= cantidad;
          db.setChatUser(msg.chat, msg.sender, 'coins', user.coins);
        } else {
          const restante = cantidad - user.coins;
          user.coins = 0;
          user.bank -= restante;
          db.setChatUser(msg.chat, msg.sender, 'coins', 0);
          db.setChatUser(msg.chat, msg.sender, 'bank', user.bank);
        }
      } else {
        cantidad = total;
        user.coins = 0;
        user.bank = 0;
        db.setChatUser(msg.chat, msg.sender, 'coins', 0);
        db.setChatUser(msg.chat, msg.sender, 'bank', 0);
      }      
      const failMessages = [
        `El anzuelo de tu Vara se enredó y perdeu parte de tu equipo, perdeu *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Una corriente fuerte arrastró tu Vara, perdeu *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Un pez grande rompió tu línea de la Vara y dañó tu aparejo, perdeu *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Tu bote se golpeó contra las rocas y tuviste que reparar tu Vara, perdeu *¥${cantidad.toLocaleString()} ${currency}*.`,
        `El pez escapó y arruinó tu red conectada a tu Vara, perdeu *¥${cantidad.toLocaleString()} ${currency}*.`,
        `El pez mordió el anzuelo pero se soltó y dañó tu carrete de la Vara, perdeu *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Tu cubeta se volcó y os peixes atrapados con tu Vara se perdieron, perdeu *¥${cantidad.toLocaleString()} ${currency}*.`
      ];
      message = pickRandom(failMessages);
    } else {
      const neutralMessages = [
        `Pasaste a tarde pescando con tu Vara y observando como os peixes nadaban cerca.`,
        `El agua estuvo tranquila y os peixes se acercaban sin morder el anzuelo de tu Vara.`,
        `Tu jornada de pesca fue serena con tu Vara, os peixes nadaban alrededor sin ser atrapados.`,
        `Los peces se mostraron esquivos a tu Vara, pero la experiencia de pesca fue agradable.`,
        `El río estuvo lleno de peces curiosos que se acercaban sin ser capturados por tu Vara.`
      ];
      message = pickRandom(neutralMessages);
    }    
    db.setChatUser(msg.chat, msg.sender, 'lastfish', Date.now() + 8 * 60 * 1000);
    await sock.sendMessage(msg.chat, { text: `「✿」 ${message}` }, { quoted: msg });
  }
};

function msToTime(duration) {
  const seconds = Math.floor((duration / 1000) % 60);
  const minutes = Math.floor((duration / (1000 * 60)) % 60);
  const min = minutes < 10 ? '0' + minutes : minutes;
  const sec = seconds < 10 ? '0' + seconds : seconds;
  return min === '00' ? `${sec} segundo${sec > 1 ? 's' : ''}` : `${min} minuto${min > 1 ? 's' : ''}, ${sec} segundo${sec > 1 ? 's' : ''}`;
}

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}