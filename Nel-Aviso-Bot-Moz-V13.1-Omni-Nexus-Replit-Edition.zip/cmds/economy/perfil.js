import os from 'os';

export default {
  command: ['perfil', 'meuinfo', 'level', 'xp'],
  category: 'economia',
  description: 'Mostra o teu perfil global, nível e estatísticas no bot.',
  run: async ({ msg, sock, usedPrefix, command }) => {
    const user = global.db.data.users[msg.sender];
    if (!user) return msg.reply('❌ Erro ao carregar os teus dados.');

    await msg.react('👤');
    
    const xp = user.exp || 0;
    const level = user.level || 0;
    const money = user.money || 0;
    const rank = level > 50 ? 'Elite Moz' : level > 20 ? 'Veterano' : 'Novato';

    let profilePic;
    try {
      profilePic = await sock.profilePictureUrl(msg.sender, 'image');
    } catch {
      profilePic = 'https://telegra.ph/file/241d9774659970966952e.jpg';
    }

    const texto = `👤 *PERFIL GLOBAL - NEL-AVISO* 👤\n\n` +
                  `🏆 *Rank:* ${rank}\n` +
                  `⭐ *Nível:* ${level}\n` +
                  `✨ *XP:* ${xp.toLocaleString()}\n` +
                  `💰 *Saldo:* ${money.toLocaleString()} MT\n\n` +
                  `📊 *Estatísticas:* \n` +
                  `▸ Mensagens: ${user.msgCount || 0}\n` +
                  `▸ Comandos: ${user.cmdCount || 0}\n\n` +
                  `> 🇲🇿 _Orgulho de Moçambique_`;

    await sock.sendMessage(msg.chat, {
      image: { url: profilePic },
      caption: texto
    }, { quoted: msg });
    
    await msg.react('✅');
  }
};
