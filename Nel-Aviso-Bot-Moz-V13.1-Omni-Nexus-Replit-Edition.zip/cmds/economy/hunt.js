import db from '#db';
export default {
  command: ['caçar', 'hunt'],
  category: 'economy',
  description: 'Cazar animales para ganar coins.',
  run: async ({ msg, sock, usedPrefix, text }) => {
    const chat = db.getChat(msg.chat);
    if (chat.adminonly || !chat.economy) {
      return msg.reply(`ꕥ Los comandos de *Economia* están desactivados en este grupo.\n\nUn *administrador* puede activarlos con o comando:\n» *${usedPrefix}economy on*`);
    }
    const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    const settings = db.getSettings(botId);
    const currency = settings.currency;
    db.setCreate('chat_users', [msg.chat, msg.sender], 'weapons', {});
    db.setCreate('chat_users', [msg.chat, msg.sender], 'lasthunt', 0);    
    let user = db.getChatUser(msg.chat, msg.sender);
    if (user.weapons && typeof user.weapons === 'string') {
      try { user.weapons = JSON.parse(user.weapons); } catch { user.weapons = {}; }
    }    
    const staminaConsumed = Math.floor(Math.random() * (5 - 1 + 1)) + 1;
    if (user.stamina < staminaConsumed) {
      return msg.reply(`ꕥ Não tens suficiente stamina para caçar.\n> Usa *${usedPrefix}heal* para curarte.`);
    }    
    if (!user.weapons?.arco) {
      return msg.reply(`ꕥ Precisas um Arco para caçar.\n> Compra um na loja com: *${usedPrefix}comprar arco*`);
    }    
    if (user.weapons.arco.durability <= 10) {
      delete user.weapons.arco;
      db.setChatUser(msg.chat, msg.sender, 'weapons', user.weapons);
      return msg.reply(`ꕥ O teu Arco partiu-se pelo uso e foi removido do teu inventário.\n>Compra um novo com: *${usedPrefix}comprar arco*`);
    }    
    if (Date.now() < user.lasthunt) {
      const restante = user.lasthunt - Date.now();
      return msg.reply(`ꕥ Deves esperar *${msToTime(restante)}* antes de volver a caçar.`);
    }    
    user.stamina -= staminaConsumed;
    db.setChatUser(msg.chat, msg.sender, 'stamina', user.stamina);    
    const rand = Math.random();
    const durabilityConsumed = Math.floor(Math.random() * (15 - 1 + 1)) + 1;
    let cantidad = 0;
    let message;    
    if (rand < 0.4) {
      user.weapons.arco.durability -= durabilityConsumed;
      if (user.weapons.arco.durability <= 10) {
        delete user.weapons.arco;
      }
      db.setChatUser(msg.chat, msg.sender, 'weapons', user.weapons);      
      cantidad = Math.floor(Math.random() * (13000 - 10000 + 1)) + 10000;
      user.coins += cantidad;
      db.setChatUser(msg.chat, msg.sender, 'coins', user.coins);      
      const successMessages = [
        `Con gran valentía, lograste caçar un Oso con tu Arco! Ganhaste *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Caçaste um Tigre feroz com o teu Arco! Após uma perseguição eletrizante, ganhou *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Lograste caçar un Elefante con astucia y persistencia usando tu Arco, ganhou *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Has cazado un Panda con tu Arco! La caza fue tranquila, ganhou *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Cazaste un Jabalí tras un rastreo emocionante con tu Arco, ganhou *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Con gran destreza, atrapaste un Cocodrilo con tu Arco, ganhou *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Has cazado un Ciervo robusto con tu Arco! Ganhaste *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Con paciencia lograste caçar un Zorro plateado con tu Arco, ganhou *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Localizaste um grupo de peces en el río y atrapaste varios con tu Arco, ganhou *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Adentraste na névoa da floresta e caçaste um javali selvagem com o teu Arco, ganhou *¥${cantidad.toLocaleString()} ${currency}*.`
      ];
      message = pickRandom(successMessages);
    } else if (rand < 0.7) {
      user.weapons.arco.durability -= durabilityConsumed;
      if (user.weapons.arco.durability <= 10) {
        delete user.weapons.arco;
      }
      db.setChatUser(msg.chat, msg.sender, 'weapons', user.weapons);      
      cantidad = Math.floor(Math.random() * (8000 - 6000 + 1)) + 6000;
      const total = (user.coins || 0) + (user.bank || 0);
      if (total >= cantidad) {
        if (user.coins >= cantidad) {
          user.coins -= cantidad;
          db.setChatUser(msg.chat, msg.sender, 'coins', user.coins);
        } else {
          const restante = cantidad - user.coins;
          user.coins = 0;
          user.bank -= restante;
          db.setChatUser(msg.chat, msg.sender, 'coins', 0);
          db.setChatUser(msg.chat, msg.sender, 'bank', user.bank);
        }
      } else {
        cantidad = total;
        user.coins = 0;
        user.bank = 0;
        db.setChatUser(msg.chat, msg.sender, 'coins', 0);
        db.setChatUser(msg.chat, msg.sender, 'bank', 0);
      }      
      const failMessages = [
        `Tu presa se escapó y no lograste caçar nada con tu Arco, perdeu *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Tropezaste mientras apuntabas con tu Arco y la presa huyó, perdeu *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Um rugido distraiu-te e não conseguiste acertar o alvo com o teu Arco, perdeu *¥${cantidad.toLocaleString()} ${currency}*.`,
        `O teu Arco partiu-se bem no momento crucial, perdeu *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Un aguacero repentino arruinó tu ruta de caza con tu Arco, perdeu *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Un jabalí te embistió y tuviste que huir perdiendo el control de tu Arco, perdeu *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Um tigre surpreendeu-te e escapaste com perdas danificando o teu Arco, perdeu *¥${cantidad.toLocaleString()} ${currency}*.`
      ];
      message = pickRandom(failMessages);
    } else {
      const neutralMessages = [
        `Pasaste a tarde a caçar com o teu Arco y observando como os animais se moviam en silencio.`,
        `El bosque estuvo tranquilo y os animais se mostraron esquivos a tu Arco.`,
        `Tu jornada de caza fue serena con tu Arco, os animais se acercaban sin ser atrapados.`,
        `Los animales se mostraron cautelosos ante tu Arco, pero la experiencia de caza fue agradable.`,
        `Exploraste nuevas rutas de caza con tu Arco y descubriste huellas frescas.`
      ];
      message = pickRandom(neutralMessages);
    }
    db.setChatUser(msg.chat, msg.sender, 'lasthunt', Date.now() + 15 * 60 * 1000);
    await sock.sendMessage(msg.chat, { text: `「✿」 ${message}` }, { quoted: msg });
  }
};

function msToTime(duration) {
  const seconds = Math.floor((duration / 1000) % 60);
  const minutes = Math.floor((duration / (1000 * 60)) % 60);
  const min = minutes < 10 ? '0' + minutes : minutes;
  const sec = seconds < 10 ? '0' + seconds : seconds;
  return min === '00' ? `${sec} segundo${sec > 1 ? 's' : ''}` : `${min} minuto${min > 1 ? 's' : ''}, ${sec} segundo${sec > 1 ? 's' : ''}`;
}

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}