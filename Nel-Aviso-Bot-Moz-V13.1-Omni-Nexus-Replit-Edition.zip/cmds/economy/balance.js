import db from '#db';
export default {
  command: ['saldo', 'bal', 'coins', 'bank'],
  category: 'economy',
  description: 'Ver cuantos coins tienes.',
  run: async ({ msg, sock, usedPrefix, text }) => {
    const chatId = msg.chat;
    const chatData = db.getChat(chatId);
    const botId = sock.user.id.split(':')[0] + "@s.whatsapp.net";
    const botSettings = db.getSettings(botId);
    const moedas = botSettings.currency;
    if (chatData.adminonly || !chatData.economy) {
      return msg.reply(`ꕥ Los comandos de *Economia* están desactivados en este grupo.\n\nUn *administrador* puede activarlos con o comando:\n» *${usedPrefix}economy on*`);
    }    
    const who = msg.mentionedJid?.[0] || msg.quoted?.sender || msg.sender;
    const user = db.getChatUser(chatId, who);
    if (!user) {
      return msg.reply(`「✎」 O usuário mencionado não está registado no bot.`);
    }
    const users = db.getUser(who);
    const total = (user.coins || 0) + (user.bank || 0);
    const bal = `✿ Usuário \`<${users?.name || who.split('@')[0]}>\`

⛀ Cartera › *¥${user.coins?.toLocaleString() || 0} ${moedas}*
⚿ Banco › *¥${user.bank?.toLocaleString() || 0} ${moedas}*
⛁ Total › *¥${total.toLocaleString()} ${moedas}*

> _Para proteger tu dinheiro, deposita em o banco usando ${usedPrefix}deposit!_`;
    await sock.sendMessage(chatId, { text: bal }, { quoted: msg });
  }
};