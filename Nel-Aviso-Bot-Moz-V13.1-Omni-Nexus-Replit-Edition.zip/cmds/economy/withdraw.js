import db from '#db';
export default {
  command: ['withdraw', 'with', 'levantar'],
  category: 'economy',
  description: 'Levantar as tuas moedas do banco.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const chatId = msg.chat;
    const senderId = msg.sender;
    const chatData = db.getChat(chatId);
    if (chatData.adminonly || !chatData.economy) {
      return msg.reply(`ꕥ Los comandos de *Economia* están desactivados en este grupo.\n\nUn *administrador* puede activarlos con o comando:\n» *${usedPrefix}economy on*`);
    }
    const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    const botSettings = db.getSettings(botId);
    const currency = botSettings.currency
    const user = db.getChatUser(chatId, senderId);    
    if (!args[0]) {
      return msg.reply(`《✧》 Insere la cantidad de *${currency}* que quieras levantar.`);
    }    
    if (args[0].toLowerCase() === 'all') {
      if ((user.bank || 0) <= 0) {
        return msg.reply(`Não tens suficientes *${currency}* en tu Banco para poder levantar.`);
      }
      const amount = user.bank;
      db.setChatUser(chatId, senderId, 'bank', 0);
      db.setChatUser(chatId, senderId, 'coins', (user.coins || 0) + amount);
      return msg.reply(`✎ Levantaste *¥${amount.toLocaleString()} ${currency}* do banco, ahora podras usarlo pero tambien podran roubartelo.`);
    }    
    const count = parseInt(args[0]);
    if (isNaN(count) || count < 1) {
      return msg.reply(`《✧》 Deves levantar uma quantidade válida.\n > Exemplo 1 » *${usedPrefix + command} ¥25000*\n> Exemplo 2 » *${usedPrefix + command} all*`);
    }    
    if ((user.bank || 0) < count) {
      return msg.reply(`《✧》 Não tens suficientes *${currency}* en tu banco para levantar esa cantidad.\n> Solo tienes *¥${user.bank.toLocaleString()} ${currency}* en a tua conta.`);
    }    
    db.setChatUser(chatId, senderId, 'bank', user.bank - count);
    db.setChatUser(chatId, senderId, 'coins', (user.coins || 0) + count);    
    await msg.reply(`✎ Levantaste *¥${count.toLocaleString()} ${currency}* do banco, ahora podras usarlo pero tambien podran roubartelo.`);
  }
};