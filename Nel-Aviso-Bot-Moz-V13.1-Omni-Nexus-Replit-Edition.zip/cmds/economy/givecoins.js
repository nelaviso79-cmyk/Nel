import db from '#db';
export default {
  command: ['givecoins', 'pay', 'coinsgive'],
  category: 'economy',
  description: 'Dar coins a um utilizador.',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    const chatId = msg.chat;
    const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    const botSettings = db.getSettings(botId);
    const moedas = botSettings.currency || 'coins';
    const chatData = db.getChat(chatId);
    if (chatData.adminonly || !chatData.economy) {
      return msg.reply(`ꕥ Los comandos de *Economia* están desactivados en este grupo.\n\nUn *administrador* puede activarlos con o comando:\n» *${usedPrefix}economy on*`);
    }
    const who = msg.quoted?.sender || msg.mentionedJid?.[0] || (args[1] ? (args[1].replace(/[@ .+-]/g, '') + '@s.whatsapp.net') : null);
    if (!who) {
      return msg.reply(`❀ Deves mencionar a quien quieras transferir *${moedas}*.\n> Exemplo » *${usedPrefix + command} 25000 @mencion*`);
    }
    const senderData = db.getChatUser(chatId, msg.sender);
    const targetData = db.getChatUser(chatId, who);   
    if (!targetData) {
      return msg.reply(`ꕥ O usuário mencionado não está registado no bot.`);
    }
    const cantidadInput = args[0]?.toLowerCase();
    let cantidad = cantidadInput === 'all' ? senderData.bank : parseInt(cantidadInput);
    if (!cantidadInput || isNaN(cantidad) || cantidad <= 0) {
      return msg.reply(`ꕥ Insere uma quantidade válida de *${moedas}* para transferir.`);
    }
    if (senderData.bank < cantidad) {
      return msg.reply(`ꕥ Não tens suficientes *${moedas}* no banco para transferir.\n> Tu saldo actual: *¥${senderData.bank.toLocaleString()} ${moedas}*`);
    }        
    db.setChatUser(chatId, msg.sender, 'bank', senderData.bank - cantidad);
    db.setChatUser(chatId, who, 'bank', (targetData.bank || 0) + cantidad);
    const userData = db.getUser(who);
    let name = userData?.name || who.split('@')[0];
    await sock.sendMessage(chatId, { text: `❀ Transferiste *¥${cantidad.toLocaleString()} ${moedas}* a *${name}*\n> Ahora tienes *¥${(senderData.bank - cantidad).toLocaleString()} ${moedas}* en tu banco.`, mentions: [who] }, { quoted: msg });
  }
};