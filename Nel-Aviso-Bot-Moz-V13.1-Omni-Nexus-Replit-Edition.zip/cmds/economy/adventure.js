import db from '#db';
export default {
  command: ['adventure', 'aventura'],
  category: 'economy',
  description: 'Ir de aventuras para ganar coins.',
  run: async ({ msg, sock, usedPrefix, command, text }) => {
    const chat = db.getChat(msg.chat);
    if (chat.adminonly || !chat.economy) {
      return sock.reply(msg.chat, `ꕥ Los comandos de *Economia* están desactivados en este grupo.\n\nUn *administrador* puede activarlos con o comando:\n» *${usedPrefix}economy on*`, msg);
    }    
    const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    const settings = db.getSettings(botId);
    const currency = settings.currency;
    db.setCreate('chat_users', [msg.chat, msg.sender], 'weapons', {});
    db.setCreate('chat_users', [msg.chat, msg.sender], 'lastadventure', 0);    
    let user = db.getChatUser(msg.chat, msg.sender);
    if (user.weapons && typeof user.weapons === 'string') {
      try { user.weapons = JSON.parse(user.weapons); } catch { user.weapons = {}; }
    }
    const staminaConsumed = Math.floor(Math.random() * (5 - 1 + 1)) + 1;
    if (user.stamina < staminaConsumed) {
      return msg.reply(`ꕥ Não tens suficiente stamina para salir de aventura.\n> Usa *${usedPrefix}heal* para curarte.`);
    }    
    let usingMagic = false;
    let usingWeapon = false;    
    if (user.weapons?.espada) {
      if (user.weapons.espada.durability <= 10) {
        delete user.weapons.espada;
        db.setChatUser(msg.chat, msg.sender, 'weapons', user.weapons);
        return msg.reply(`ꕥ Tu Espada partiu-se pelo uso y foi removida do teu inventário.\n> Compra uma nova com: *${usedPrefix}comprar espada*`);
      }
      usingWeapon = true;
    } else {
      const magicConsumed = Math.floor(Math.random() * (12 - 1 + 1)) + 1;
      if (user.magic < magicConsumed) {
        return msg.reply(`ꕥ Tu magia está esgotada e não tens uma arma.\n> Toma uma poção para reabastecer a tua magia ou compra uma arma com: *${usedPrefix}comprar espada*`);
      }
      usingMagic = true;
      user.magic -= magicConsumed;
      db.setChatUser(msg.chat, msg.sender, 'magic', user.magic);
    }    
    if (user.health < 5) {
      return msg.reply(`ꕥ Não tens suficiente salud para volver a *aventurarte*.\n> Usa *${usedPrefix}heal* para curarte.`);
    }    
    const remainingTime = user.lastadventure - Date.now();
    if (remainingTime > 0) {
      return sock.reply(msg.chat, `ꕥ Deves esperar *${msToTime(remainingTime)}* para usar *${usedPrefix + command}* de nuevo.`, msg);
    }    
    user.stamina -= staminaConsumed;
    db.setChatUser(msg.chat, msg.sender, 'stamina', user.stamina);    
    const rand = Math.random();
    let cantidad = 0;
    let salud = Math.floor(Math.random() * (20 - 1 + 1)) + 1;
    let durabilityConsumed = Math.floor(Math.random() * (15 - 1 + 1)) + 1;
    let message;    
    if (rand < 0.4) {
      if (usingWeapon) {
        user.weapons.espada.durability -= durabilityConsumed;
        if (user.weapons.espada.durability <= 10) {
          delete user.weapons.espada;
        }
        db.setChatUser(msg.chat, msg.sender, 'weapons', user.weapons);
      }
      cantidad = Math.floor(Math.random() * (18000 - 14000 + 1)) + 14000;
      user.coins += cantidad;
      user.health -= salud;
      db.setChatUser(msg.chat, msg.sender, 'coins', user.coins);
      db.setChatUser(msg.chat, msg.sender, 'health', user.health);      
      const successMessages = [
        `Derrotaste um ogro emboscado entre as árvores de Drakonia, ganhou *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Te conviertes en campeón del torneo de gladiadores de Valoria, ganhou *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Rescatas un libro mágico do altar de los Susurros, ganhou *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Libertas aldeões presos nas minas de Ulderan após vencer os trolls, ganhou *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Derrotas um dragão jovem nos penhascos de Flamear, ganhou *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Encontras uma relíquia sagrada nas ruínas de Iskaria e proteges-a de saqueadores, ganhou *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Triunfas no duelo contra o cavaleiro corrupto de Invalion, ganhou *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Conquistas la fortaleza maldita de las Sombras Rojas sin sufrir bajas, ganhou *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Infiltras-te no templo do Vazio e recuperas o cristal do equilíbrio, ganhou *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Resolves o enigma da cripta eterna e obténs um tesouro lendário, ganhou *¥${cantidad.toLocaleString()} ${currency}*.`
      ];
      message = pickRandom(successMessages);
    } else if (rand < 0.7) {
      if (usingWeapon) {
        user.weapons.espada.durability -= durabilityConsumed;
        if (user.weapons.espada.durability <= 10) {
          delete user.weapons.espada;
        }
        db.setChatUser(msg.chat, msg.sender, 'weapons', user.weapons);
      }
      cantidad = Math.floor(Math.random() * (11000 - 9000 + 1)) + 9000;
      const total = (user.coins || 0) + (user.bank || 0);
      if (total >= cantidad) {
        if (user.coins >= cantidad) {
          user.coins -= cantidad;
          db.setChatUser(msg.chat, msg.sender, 'coins', user.coins);
        } else {
          const restante = cantidad - user.coins;
          user.coins = 0;
          user.bank -= restante;
          db.setChatUser(msg.chat, msg.sender, 'coins', 0);
          db.setChatUser(msg.chat, msg.sender, 'bank', user.bank);
        }
      } else {
        cantidad = total;
        user.coins = 0;
        user.bank = 0;
        db.setChatUser(msg.chat, msg.sender, 'coins', 0);
        db.setChatUser(msg.chat, msg.sender, 'bank', 0);
      }
      user.health -= salud;
      if (user.health < 0) user.health = 0;
      db.setChatUser(msg.chat, msg.sender, 'health', user.health);      
      const failMessages = [
        `O feiticeiro negro lançou-te uma maldição e fogas perdendo *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Perdes-te na selva de Zarkelia e uns bandidos assaltam-te, pierdes *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Un basilisco te embiste y escapas herido sin botín, pierdes *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Falha a tua incursão na torre de gelo quando cais numa armadilha mágica, pierdes *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Perdes a orientação entre os portais da floresta espelho e acabas sem recompensa, pierdes *¥${cantidad.toLocaleString()} ${currency}*.`,
        `Un grupo de trolls te embosca y te quitan tus pertenencias, pierdes *¥${cantidad.toLocaleString()} ${currency}*.`,
        `El dragón anciano te derrota y te obliga a huir, pierdes *¥${cantidad.toLocaleString()} ${currency}*.`
      ];
      message = pickRandom(failMessages);
    } else {
      const neutralMessages = [
        `Exploras ruinas antiguas y aprendes secretos ocultos.`,
        `Segues a pista de um espectro mas desaparece entre a névoa.`,
        `Acompanhas uma princesa pelos desertos de Thaloria sem contratempos.`,
        `Recorres un bosque encantado y descubres nuevas rutas.`,
        `Visitas uma aldeia remota e ouves relatos de antigas batalhas.`
      ];
      message = pickRandom(neutralMessages);
    }    
    db.setChatUser(msg.chat, msg.sender, 'lastadventure', Date.now() + 20 * 60 * 1000);
    await sock.sendMessage(msg.chat, { text: `「✿」 ${message}` }, { quoted: msg });
  }
};

function msToTime(duration) {
  const seconds = Math.floor((duration / 1000) % 60);
  const minutes = Math.floor((duration / (1000 * 60)) % 60);
  const min = minutes < 10 ? '0' + minutes : minutes;
  const sec = seconds < 10 ? '0' + seconds : seconds;
  return min === '00' ? `${sec} segundo${sec > 1 ? 's' : ''}` : `${min} minuto${min > 1 ? 's' : ''}, ${sec} segundo${sec > 1 ? 's' : ''}`;
}

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}