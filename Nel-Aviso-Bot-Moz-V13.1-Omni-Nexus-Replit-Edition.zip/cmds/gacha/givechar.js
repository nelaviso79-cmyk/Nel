import { promises as fs } from 'fs';
import db from '#db';

const charactersFilePath = './core/characters.json';

async function loadCharacters() {
  const data = await fs.readFile(charactersFilePath, 'utf-8');
  return JSON.parse(data);
}

function flattenCharacters(structure) {
  return Object.values(structure).flatMap(s => Array.isArray(s.characters) ? s.characters : []);
}

export default {
  command: ['givechar', 'givewaifu', 'oferecer'],
  category: 'gacha',
  description: 'Regalar um personagem a otro usuário.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    try {
      const chat = db.getChat(msg.chat);
      if (chat.adminonly || !chat.gacha) {
        return msg.reply(`ꕥ Os comandos de *Gacha* estão desativados neste grupo.\n\nUn *administrador* pode ativá-los com o comando:\n» *${usedPrefix}gacha on*`);
      }      
      if (!args.length) {
        return msg.reply(`❀ Deve escrever o nome do personagem e citar ou mencionar o usuário que o receberá`);
      }      
      const targetId = msg.mentionedJid?.[0] || msg.quoted?.sender || null;
      if (!targetId) return msg.reply(`❀ Deve mencionar o citar a mensagem del destinatario.`);
      let sender = db.getChatUser(msg.chat, msg.sender);
      let target = db.getChatUser(msg.chat, targetId);
      if (!target) {
      return msg.reply(`「✎」 O usuário mencionado não está registado no bot.`);
      }
      const characterName = msg.quoted ? args.join(' ').toLowerCase().trim() : args.slice(0, -1).join(' ').toLowerCase().trim();      
      const structure = await loadCharacters();
      const allCharacters = flattenCharacters(structure);
      const character = allCharacters.find(c => c.name.toLowerCase() === characterName);      
      if (!character) {
        return msg.reply(`ꕥ Não foi encontrado o personagem *${characterName}*.`);
      }      
      if (!sender.characters.includes(character.id)) {
        return msg.reply(`ꕥ *${character.name}* não está reivindicado por si.`);
      }
      const charKey = msg.chat + '__' + character.id;
      db.setCreate('characters', charKey, 'name', character.name);
      let characterData = db.getCharacter(charKey);
      if (!characterData) characterData = { name: character.name, value: Number(character.value || 0), votes: 0 };
      characterData.user = targetId;
      characterData.claimedAt = Date.now();
      db.setCharacter(charKey, characterData);
      sender.characters = sender.characters.filter(id => id !== character.id);
      db.setChatUser(msg.chat, msg.sender, 'characters', sender.characters);
      if (!target.characters.includes(character.id)) {
        target.characters.push(character.id);
        db.setChatUser(msg.chat, targetId, 'characters', target.characters);
      }
      if (sender.favorite === character.id) {
        db.setChatUser(msg.chat, msg.sender, 'favorite', '');
        db.setUser(msg.sender, 'favorite', '');
      }
      const senderGlobal = db.getUser(msg.sender);
      const targetGlobal = db.getUser(targetId);
      let senderName = senderGlobal?.name?.trim() || msg.sender.split('@')[0];
      let receiverName = targetGlobal?.name?.trim() || targetId.split('@')[0];
      await sock.reply(msg.chat, `❀ *${character.name}* foi regalado a *${receiverName}* por *${senderName}*.`, msg, { mentions: [targetId] });
    } catch (e) {
      await msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  },
};