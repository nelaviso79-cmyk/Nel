import db from '#db';
export default {
  command: ['removesale', 'removerventa'],
  category: 'gacha',
  description: 'Eliminerar um personagem à venda.',
  run: async ({ msg, args, usedPrefix, command }) => {
    const chatId = msg.chat;
    const userId = msg.sender;
    db.setCreate('chats', chatId, 'sales', {});
    let chat = db.getChat(chatId);
    if (chat.adminonly || !chat.gacha) {
      return msg.reply(`ꕥ Os comandos de *Gacha* estão desativados neste grupo.\n\nUn *administrador* pode ativá-los com:\n» *${usedPrefix}gacha on*`);
    }
    if (chat.sales && typeof chat.sales === 'string') {
      try { chat.sales = JSON.parse(chat.sales); } catch { chat.sales = {}; }
    }    
    if (!args.length) {
      return msg.reply(`❀ Deve especificar um personagem para remover.\n> Exemplo » *${usedPrefix + command} Nel-Aviso Bot*`);
    }    
    try {
      const nameRemove = args.join(' ').toLowerCase();
      const idRemove = Object.keys(chat.sales).find(id => (chat.sales[id]?.name || '').toLowerCase() === nameRemove);      
      if (!idRemove || chat.sales[idRemove].user !== userId) {
        return msg.reply(`ꕥ O personagem *${args.join(' ')}* não está à venda por si.`);
      }      
      delete chat.sales[idRemove];
      db.setChat(chatId, 'sales', chat.sales);
      msg.reply(`❀ *${args.join(' ')}* foi eliminado de a lista de ventas.`);      
    } catch (e) {
      await msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  },
};