import db from '#db';
export default {
  command: ['setstickerpackdesc', 'setpackdesc', 'packdesc'],
  category: 'stickers',
  description: 'Definir a descrição de um pacote de stickers.',
  run: async ({ msg, args, usedPrefix, command }) => {
    try {
      if (!args.length) {
        return msg.reply(`《✧》Especifique o nome do pacote y a nova descrição.\n> Exemplo: *${usedPrefix + command} NomeDoPacote | Nova Descrição*`)
      }
      const fullText = args.join(' ').trim()
      const parts = fullText.split(/\||•|\//)
      if (parts.length < 2) {
        return msg.reply(`《✧》Especifique o nome do pacote y a nova descrição.\n> Exemplo: *${usedPrefix + command} NomeDoPacote | Nova Descrição*`)
      }
      const packName = parts[0].trim()
      const desc = parts[1].trim()
      if (!desc || desc.length === 0) {
        return msg.reply('《✧》A descrição não pode estar vazia.')
      }
      if (desc.length > 60) {
        return msg.reply('《✧》A descrição não pode ter mais de 50 caracteres.')
      }
      const stickerPackData = db.getStickersPack(msg.sender)
      const packs = stickerPackData.packs || []
      if (!packs || packs.length === 0) {
        return msg.reply('《✧》Não tem paquetes creados.')
      }
      const pack = packs.find(p => p.name.toLowerCase() === packName.toLowerCase())
      if (!pack) {
        return msg.reply(`《✧》Não foi encontrado o pacote de stickers \`${packName}\`.`)
      }
      pack.desc = desc
      pack.lastModified = Date.now().toString()
      db.setStickersPack(msg.sender, 'packs', packs);
      msg.reply(`❀ A descrição do pacote de stickers \`${pack.name}\` foi atualizada!`)
    } catch (e) {
      msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  }
}
