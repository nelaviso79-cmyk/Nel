import db from '#db';
export default {
  command: ['delpack'],
  category: 'stickers',
  description: 'Eliminerar um pacote de stickers.',
  run: async ({ msg, args, usedPrefix, command }) => {
    try {
      if (!args.length) {
        return msg.reply('《✧》Especifique o nome do pacote de stickers.')
      }
      const packName = args.join(' ').trim()
      const stickerPackData = db.getStickersPack(msg.sender)
      const packs = stickerPackData.packs || []
      if (!packs || packs.length === 0) {
        return msg.reply('《✧》Não tem paquetes creados.')
      }
      const packIndex = packs.findIndex(p => p.name.toLowerCase() === packName.toLowerCase())
      if (packIndex === -1) {
        return msg.reply(`《✧》Não foi encontrado o pacote de stickers \`${packName}\`.`)
      }
      const deletedPack = packs[packIndex]
      packs.splice(packIndex, 1)
      db.setStickersPack(msg.sender, 'packs', packs);
      msg.reply(`❀ O pacote de stickers \`${deletedPack.name}\` foi eliminado.`)
    } catch (e) {
      msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  }
}