import db from '#db';
export default {
  command: ['newpack', 'newstickerpack'],
  category: 'stickers',
  description: 'Criar um novo pacote de stickers.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    try {
      const settings = db.getSettings(sock.user.id.split(':')[0] + '@s.whatsapp.net') || {}
      const userId = db.getUser(msg.sender)
      const dev = userId.name || msg.pushName || 'Desconhecido'
      const name = args.join(' ').trim()
      if (!name || name.length < 4 || name.length > 64) {
        return msg.reply('《✧》O nome do pacote de stickers deve ter entre 4 e 64 caracteres.')
      }
      const stickerPackData = db.getStickersPack(msg.sender)
      const packs = stickerPackData.packs || []
      if (packs.find(p => p.name.toLowerCase() === name.toLowerCase())) {
        return msg.reply('《✧》Ya tienes um pacote com esse nome.')
      }
      const newPack = { id: Date.now().toString(), lastModified: Date.now().toString(), name, author: 'Nel-Aviso-Bot-Moz', desc: `Pacote de stickers creado por ${dev}`, stickers: [], spackpublic: 0 }
      packs.push(newPack)
      db.setStickersPack(msg.sender, 'packs', packs)
      msg.reply(`《✧》O pacote de stickers \`${name}\` foi criado com sucesso!
> Podes adicionar stickers respondendo a um usando *${usedPrefix}addsticker ${name}*!`)
    } catch (e) {
      msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  }
}
