import db from '#db';
export default {
  command: ['delmeta', 'delstickermeta'],
  category: 'stickers',
  description: 'Restabelecer o pack e autor por defeito para os seus stickers.',
  run: async ({ msg, sock, usedPrefix, command, text }) => {
    try {
      const userData = db.getUser(msg.sender);
      if ((!userData.metadatos || userData.metadatos === '') && (!userData.metadatos2 || userData.metadatos2 === '')) {
        return msg.reply('《✧》Não tem metadados atribuídos.');
      }
      db.setUser(msg.sender, 'metadatos', '');
      db.setUser(msg.sender, 'metadatos2', '');
      await sock.sendMessage(msg.chat, { text: `✎ Os metadados dos seus stickers foram eliminados corretamente.` }, { quoted: msg });
    } catch (e) {
      await msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  },
};