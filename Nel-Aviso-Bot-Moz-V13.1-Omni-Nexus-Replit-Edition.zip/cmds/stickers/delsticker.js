import db from '#db';
export default {
  command: ['stickerdel', 'delsticker'],
  category: 'stickers',
  description: 'Eliminerar um sticker de um pacote.',
  run: async ({ msg, args, usedPrefix, command }) => {
    try {
      if (!args.length) {
        return msg.reply('《✧》Especifique o nome do pacote.')
      }
      const packName = args.join(' ').trim()
      const stickerPackData = db.getStickersPack(msg.sender)
      const packs = stickerPackData.packs || []
      if (!packs || packs.length === 0) {
        return msg.reply('《✧》Não tem paquetes creados.')
      }
      const pack = packs.find(p => p.name.toLowerCase() === packName.toLowerCase())
      if (!pack) {
        return msg.reply('《✧》Não foi encontrado um pacote com esse nome.')
      }
      const quoted = msg.quoted
      if (!quoted) {
        return msg.reply('《✧》Responde a um sticker para removê-lo do pacote de stickers.')
      }
      const mime = quoted.mimetype || quoted.msg?.mimetype || ''
      if (!/webp/i.test(mime)) {
        return msg.reply('《✧》Solo podes remover stickers.')
      }
      if (!pack.stickers || pack.stickers.length === 0) {
        return msg.reply('《✧》O pacote não tem stickers.')
      }
      let buffer = await quoted.download()
      if (!buffer) {
        return msg.reply('《✧》Não foi possível obter o sticker.')
      }
      if (!Buffer.isBuffer(buffer)) {
        buffer = Buffer.from(buffer)
      }
      const base64Buffer = buffer.toString('base64')
      const index = pack.stickers.findIndex(stored => stored === base64Buffer)
      if (index === -1) {
        return msg.reply('《✧》Ese sticker não está em o pacote.')
      }
      pack.stickers.splice(index, 1)
      pack.lastModified = Date.now().toString()
      db.setStickersPack(msg.sender, 'packs', packs);
      msg.reply(`❀ O sticker foi eliminado do pacote de stickers ${pack.name}!`)
    } catch (e) {
      msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  }
}
