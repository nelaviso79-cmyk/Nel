import { calculateBanRisk } from '#core/human_protection';
import os from 'os';

export default {
  command: ['auditoria', 'risco', 'sentinel', 'seguranca'],
  category: 'moderacao',
  description: 'Realiza uma auditoria de segurança e risco de banimento do bot.',
  admin: true,
  run: async ({ msg, sock, usedPrefix, command }) => {
    await msg.react('🛡️');
    
    const risk = calculateBanRisk();
    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);

    let statusEmoji = risk.level === 'BAIXO' ? '✅' : risk.level === 'MÉDIO' ? '⚠️' : '🚨';

    const texto = `🛡️ *AUDITORIA DE SEGURANÇA SENTINEL* 🛡️\n\n` +
                  `📊 *Nível de Risco:* ${statusEmoji} *${risk.level}*\n` +
                  `📈 *Pontuação de Risco:* ${risk.score}/100\n\n` +
                  `🕵️ *Análise Situacional:* \n` +
                  `▸ Tempo Online: ${hours}h ${minutes}m\n` +
                  `▸ Proteção Humana: ✅ ATIVA (V8)\n` +
                  `▸ Criptografia de Sessão: ✅ REFORÇADA\n` +
                  `▸ IP do Servidor: ${os.hostname()}\n\n` +
                  `📢 *Recomendação:* \n` +
                  `_${risk.recommendation}_\n\n` +
                  `> 🛡️ _Sentinel Protector V8 - Nel-Aviso-Bot-Moz_`;

    await msg.reply(texto);
    await msg.react('✅');
  }
};
