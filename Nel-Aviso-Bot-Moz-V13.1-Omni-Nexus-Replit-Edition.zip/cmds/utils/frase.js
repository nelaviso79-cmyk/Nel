export default {
  command: ['frase', 'motivacao', 'motivacional', 'inspiracao'],
  category: 'diversao',
  description: 'Receber uma frase motivacional aleatória para inspirar o teu dia.',
  run: async ({ msg, sock, usedPrefix, command }) => {
    const frases = [
      '🌟 "O sucesso não é final, o fracasso não é fatal: é a coragem de continuar que conta." — Winston Churchill',
      '💪 "Acredita em ti mesmo e tudo é possível." — Desconhecido',
      '🔥 "A única forma de fazer um excelente trabalho é amar o que fazes." — Steve Jobs',
      '🌈 "Não esperes por oportunidades, cria-as." — George Bernard Shaw',
      '⭐ "O futuro pertence a quem acredita na beleza dos seus sonhos." — Eleanor Roosevelt',
      '🚀 "Cada dia é uma nova chance de mudar a tua vida." — Desconhecido',
      '💎 "Dificuldades preparam pessoas comuns para destinos extraordinários." — C.S. Lewis',
      '🎯 "Se queres algo que nunca tiveste, faz algo que nunca fizeste." — Thomas Jefferson',
      '🌱 "O maior obstáculo é o medo de tentar." — Desconhecido',
      '🏆 "Não é o mais forte que sobrevive, mas o que melhor se adapta." — Charles Darwin',
      '☀️ "A vida é 10% do que acontece contigo e 90% como reages." — Charles Swindoll',
      '💫 "Começa onde estás, usa o que tens, faz o que podes." — Arthur Ashe',
      '🦁 "A coragem não é a ausência de medo, mas o triunfo sobre ele." — Nelson Mandela',
      '🌍 "Sê a mudança que queres ver no mundo." — Mahatma Gandhi',
      '📚 "Educação é a arma mais poderosa para mudar o mundo." — Nelson Mandela',
      '🎨 "A criatividade é a inteligência a divertir-se." — Albert Einstein',
      '⚡ "O impossível é apenas algo que ainda não tentaste." — Desconhecido',
      '🌊 "A vida é como andar de bicicleta: para manter o equilíbrio, tens que continuar a mover-te." — Albert Einstein',
      '🏔️ "Cada montanha que subes te dá uma vista melhor das que vêm aí." — Desconhecido',
      '🌹 "Mesmo a noite mais escura acabará e o sol nascerá." — Victor Hugo',
      '🦅 "Quem voa com os grandes, aprende a voar alto." — Provérbio Moçambicano',
      '🌊 "A água que não corre, apodrece. Move-te sempre!" — Provérbio Africano',
      '🦁 "Se achas que podes ou que não podes, tens razão nos dois casos." — Henry Ford',
      '💫 "Não é a carga que te esmaga, é a forma como a carregas." — Lou Holtz',
      '🔥 "Tudo o que algum dia sonhamos pode ser realizado se temos coragem de perseguir." — Walt Disney',
    ];
    const frase = frases[Math.floor(Math.random() * frases.length)];
    return msg.reply(`❧ *Frase Motivacional*\n\n${frase}\n\n▸ Use *${usedPrefix + command}* para outra frase!`);
  },
};
