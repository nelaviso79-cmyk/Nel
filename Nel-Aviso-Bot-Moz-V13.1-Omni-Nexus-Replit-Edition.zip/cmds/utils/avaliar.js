export default {
  command: ['perfumar', 'avalizar', 'taxa', 'nota', 'classificar'],
  category: 'diversao',
  description: 'Avaliar alguém de 0 a 100! 💯',
  run: async ({ msg, sock, usedPrefix, command, participants }) => {
    const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    
    if (!mentioned.length) {
      return msg.reply(
        `💯 *AVALIAR PESSOA* 💯\n\n` +
        `◈ Mencione alguém para avaliar!\n\n` +
        `✎ Exemplo: *${usedPrefix + command} @pessoa*`
      );
    }

    const alvo = mentioned[0];
    const nome = alvo.split('@')[0];

    // Gerar avaliações únicas baseadas no número
    const seed = nome.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
    
    const beleza = ((seed * 7 + 31) % 50) + 50;
    const inteligencia = ((seed * 13 + 47) % 50) + 50;
    const humor = ((seed * 17 + 23) % 50) + 50;
    const simpatia = ((seed * 23 + 59) % 50) + 50;
    const carisma = ((seed * 29 + 71) % 50) + 50;
    const lealdade = ((seed * 37 + 83) % 50) + 50;
    const media = Math.round((beleza + inteligencia + humor + simpatia + carisma + lealdade) / 6);

    const barra = (v) => '█'.repeat(Math.floor(v / 10)) + '░'.repeat(10 - Math.floor(v / 10));

    let status = '';
    if (media >= 90) status = '🌟 LENDÁRIO! Pessoa incrível!';
    else if (media >= 80) status = '🔥 EXCEPCIONAL! Muito acima da média!';
    else if (media >= 70) status = '✨ ÓTIMO! Pessoa de qualidade!';
    else if (media >= 60) status = '👍 BOM! Acima da média!';
    else if (media >= 50) status = '😊 NORMAL! Está no caminho!';
    else status = '😅 Precisa melhorar... brincadeira!';

    return msg.reply(
      `💯 *AVALIAÇÃO DE @${nome}* 💯\n\n` +
      `▸ Beleza:       [${barra(beleza)}] ${beleza}%\n` +
      `▸ Inteligência: [${barra(inteligencia)}] ${inteligencia}%\n` +
      `▸ Humor:        [${barra(humor)}] ${humor}%\n` +
      `▸ Simpatia:     [${barra(simpatia)}] ${simpatia}%\n` +
      `▸ Carisma:      [${barra(carisma)}] ${carisma}%\n` +
      `▸ Lealdade:     [${barra(lealdade)}] ${lealdade}%\n\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `📊 *MÉDIA GERAL: ${media}%*\n` +
      `${status}\n\n` +
      `_💯 Nel-Aviso-Bot-Moz_`
    , { mentions: [alvo] });
  }
};
