// ╔══════════════════════════════════════════════════════════════╗
//   NEL-AVISO-BOT-MOZ · cmds/utils/nsfwcheck.js
//   NSFW Check — Verifica se imagem contém conteúdo +18
// ╚══════════════════════════════════════════════════════════════╝

export const command = {
  name: 'nsfwcheck',
  aliases: ['checknsfw', 'nsfwdetect', 'verificarimg', 'isnsfw', 'contentcheck'],
  description: 'Verifica se uma imagem contém conteúdo NSFW (+18)',
  category: 'utilidades',
  usage: '.nsfwcheck (citar uma imagem)',
  example: '.nsfwcheck [citar imagem]'
};

export default async function ({ sock, msg, args, from, sender, config }) {
  // Verificar se há imagem citada
  const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
  const imageMsg = quoted?.imageMessage;

  if (!imageMsg) {
    return sock.sendMessage(from, {
      text: '❌ Cita uma imagem para verificar!\n\n💡 *Uso:* .nsfwcheck [citar imagem]\n📌 Responde a uma imagem com o comando'
    }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });

  try {
    // Download da imagem citada
    const stream = await sock.downloadContentFromMessage(imageMsg, 'image');
    let buffer = Buffer.alloc(0);
    for await (const chunk of stream) {
      buffer = Buffer.concat([buffer, chunk]);
    }

    // Upload para catbox.moe
    const FormData = (await import('form-data')).default;
    const form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('fileToUpload', buffer, 'image.jpg');

    const uploadRes = await fetch('https://catbox.moe/user/api.php', {
      method: 'POST',
      body: form,
      headers: form.getHeaders()
    });

    const imageUrl = await uploadRes.text();
    if (!imageUrl || !imageUrl.startsWith('https://')) {
      throw new Error('Upload failed');
    }

    // Delirius Tools — /tools/checknsfw
    const res = await fetch(`https://api.delirius.store/tools/checknsfw?url=${encodeURIComponent(imageUrl)}`);
    const data = await res.json();

    if (data?.status === 200 && data?.result) {
      const r = data.result;
      const nsfwScore = r.nsfw || r.nsfwScore || r.score || 0;
      const sfwScore = r.sfw || (100 - nsfwScore);
      const isNsfw = nsfwScore > 50;

      // Barra visual
      const barLen = 20;
      const nsfwBars = Math.round((nsfwScore / 100) * barLen);
      const sfwBars = barLen - nsfwBars;
      const bar = `🟩${'█'.repeat(sfwBars)}${'░'.repeat(nsfwBars)}🟥`;

      const emoji = isNsfw ? '🔞' : '✅';
      const status = isNsfw ? '⚠️ CONTEÚDO NSFW DETETADO' : '✅ CONTEÚDO SEGURO';

      const result = `🔍 *ANÁLISE NSFW* ${emoji}

━━━━━━━━━━━━━━━━━━━━

${status}

📊 *Classificação:*
  • NSFW: ${typeof nsfwScore === 'number' ? nsfwScore.toFixed(1) : nsfwScore}%
  • SFW: ${typeof sfwScore === 'number' ? sfwScore.toFixed(1) : sfwScore}%

${bar}

📋 *Detalhes:*${r.details ? `\n${JSON.stringify(r.details, null, 2).replace(/[{}"]/g, '').replace(/,/g, '\n')}` : '\n  Análise concluída com sucesso'}`;

      await sock.sendMessage(from, { text: result }, { quoted: msg });
      return;
    }
  } catch (e) {
    console.log('NSFW check primary failed:', e.message);
  }

  // Fallback — usar IA visual
  try {
    const stream2 = await sock.downloadContentFromMessage(imageMsg, 'image');
    let buffer2 = Buffer.alloc(0);
    for await (const chunk of stream2) {
      buffer2 = Buffer.concat([buffer2, chunk]);
    }

    const FormData2 = (await import('form-data')).default;
    const form2 = new FormData2();
    form2.append('reqtype', 'fileupload');
    form2.append('fileToUpload', buffer2, 'image.jpg');

    const uploadRes2 = await fetch('https://catbox.moe/user/api.php', {
      method: 'POST',
      body: form2,
      headers: form2.getHeaders()
    });

    const imageUrl2 = await uploadRes2.text();

    if (imageUrl2 && imageUrl2.startsWith('https://')) {
      const res = await fetch(`https://api.delirius.store/ia/visual?url=${encodeURIComponent(imageUrl2)}&prompt=${encodeURIComponent('Analyze this image for NSFW/adult content. Rate from 0-100% how explicit it is. Respond with just the percentage number.')}`);
      const data = await res.json();

      if (data?.status === 200 && data?.result) {
        await sock.sendMessage(from, {
          text: `🔍 *ANÁLISE NSFW* (via IA Visual)\n\n📝 ${data.result}\n\n_⚠️ Análise alternativa — precisão pode variar_`
        }, { quoted: msg });
        return;
      }
    }
  } catch (e) {
    console.log('NSFW check fallback failed:', e.message);
  }

  await sock.sendMessage(from, {
    text: '❌ Não consegui analisar a imagem. Tenta novamente.'
  }, { quoted: msg });
}
