export default {
  command: ['patrick', 'patrickbanner'],
  category: 'diversao',
  description: 'Cria um banner do Patrick com texto personalizado',
  botAdmin: false,

  async run({ msg, sock, text, usedPrefix, command }) {
    if (!text) return msg.reply(`❌ Use: *${usedPrefix}${command} texto*\n\nExemplo: ${usedPrefix}${command} Eu sou o melhor bot!`);

    await msg.react('⏳');
    try {
      const api = global.APIs.delirius.url;
      const url = `${api}/canvas/patrick?text=${encodeURIComponent(text)}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error(`API erro: ${res.status}`);
      const buffer = Buffer.from(await res.arrayBuffer());

      await sock.sendMessage(msg.chat, {
        image: buffer,
        caption: `🧽 *Patrick Banner*\n📝 ${text}`
      }, { quoted: msg });
      await msg.react('✅');
    } catch (e) {
      await msg.react('❌');
      await msg.reply(`❌ Erro ao gerar banner: ${e.message}`);
    }
  }
};
