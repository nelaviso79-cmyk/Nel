import fs from 'fs';
import { spawn } from 'child_process';

const filtros = {
  sepia: 'colorchannelmixer=.393:.769:.189:0:.349:.686:.168:0:.272:.534:.131',
  pretoebranco: 'hue=s=0',
  inverter: 'negate',
  brilho: 'eq=brightness=0.1',
  escuro: 'eq=brightness=-0.1',
  contraste: 'eq=contrast=2',
  vinho: 'colorchannelmixer=.4:.1:.1:0:.1:.1:.1:0:.1:.1:.4',
  gelo: 'colorchannelmixer=.1:.1:.4:0:.1:.2:.5:0:.3:.4:.6',
  vintage: 'colorchannelmixer=.5:.3:.1:0:.2:.5:.1:0:.1:.2:.4,eq=brightness=-0.03',
  neon: 'eq=brightness=0.05:contrast=1.5:saturation=3',
  dramático: 'eq=contrast=3:brightness=-0.05',
  quente: 'colorchannelmixer=1:0:0:0:0:.7:.1:0:0:0:.4',
  frio: 'colorchannelmixer=.1:0:.3:0:0:.5:.4:0:.3:.5:1'
};

export default {
  command: ['filtro', 'filter', 'efeito', 'efeitofoto'],
  category: 'utilidades',
  description: 'Aplicar filtros fotográficos numa imagem 🎨',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    const quoted = msg.quoted || msg;
    const mime = (quoted.msg || quoted).mimetype || '';
    
    if (!/image/.test(mime)) {
      return msg.reply(`◈ Responda a uma *imagem* com o filtro desejado.\n\n✎ Exemplo: *${usedPrefix + command} sepia*\n\n◈ Filtros disponíveis:\n${Object.keys(filtros).map(f => `▸ ${f}`).join('\n')}`);
    }
    
    const filtro = (text || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/é/g, 'e').replace(/á/g, 'a').replace(/í/g, 'i').replace(/ó/g, 'o').replace(/ú/g, 'u').replace(/ê/g, 'e').replace(/â/g, 'a');
    
    const filtroKey = Object.keys(filtros).find(k => k.normalize('NFD').replace(/[\u0300-\u036f]/g, '') === filtro) || 
                      Object.keys(filtros).find(k => k.startsWith(filtro));
    
    if (!filtroKey) {
      return msg.reply(`◈ Filtro "${text}" não encontrado!\n\n◈ Filtros disponíveis:\n${Object.keys(filtros).map(f => `▸ ${f}`).join('\n')}`);
    }
    
    await msg.react('⏳');
    
    try {
      const buffer = await quoted.download();
      const inputPath = `./tmp/filter_in_${Date.now()}.jpg`;
      const outputPath = `./tmp/filter_out_${Date.now()}.jpg`;
      fs.writeFileSync(inputPath, buffer);
      
      await new Promise((resolve, reject) => {
        const proc = spawn('ffmpeg', ['-y', '-i', inputPath, '-vf', filtros[filtroKey], outputPath]);
        let err = '';
        proc.stderr.on('data', d => err += d.toString());
        proc.on('close', code => code === 0 ? resolve() : reject(new Error(err)));
      });
      
      const result = fs.readFileSync(outputPath);
      fs.unlinkSync(inputPath);
      fs.unlinkSync(outputPath);
      
      await sock.sendMessage(msg.chat, { image: result, caption: `◈ Filtro *${filtroKey}* aplicado! 🎨` }, { quoted: msg });
      await msg.react('✅');
    } catch (e) {
      await msg.react('❌');
      return msg.reply(`◈ Erro: ${e.message}`);
    }
  }
};
