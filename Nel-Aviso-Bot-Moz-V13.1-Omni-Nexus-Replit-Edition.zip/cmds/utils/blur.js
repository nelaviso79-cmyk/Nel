import fs from 'fs';
import { spawn } from 'child_process';

export default {
  command: ['blur', 'desfocar', 'embaçar', 'borrar'],
  category: 'utilidades',
  description: 'Aplicar efeito de desfoque numa imagem 🌫️',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    const quoted = msg.quoted || msg;
    const mime = (quoted.msg || quoted).mimetype || '';
    
    if (!/image/.test(mime)) {
      return msg.reply(`◈ Responda a uma *imagem* com:\n${usedPrefix + command} [nível 1-20]\n\n✎ Exemplo: *${usedPrefix + command} 10*`);
    }
    
    const level = parseInt(text) || 5;
    if (level < 1 || level > 20) return msg.reply('◈ Nível inválido! Use de 1 a 20.');
    
    await msg.react('⏳');
    
    try {
      const buffer = await quoted.download();
      const inputPath = `./tmp/blur_in_${Date.now()}.jpg`;
      const outputPath = `./tmp/blur_out_${Date.now()}.jpg`;
      fs.writeFileSync(inputPath, buffer);
      
      await new Promise((resolve, reject) => {
        const proc = spawn('ffmpeg', ['-y', '-i', inputPath, '-vf', `gblur=sigma=${level * 2}`, outputPath]);
        let err = '';
        proc.stderr.on('data', d => err += d.toString());
        proc.on('close', code => code === 0 ? resolve() : reject(new Error(err)));
      });
      
      const result = fs.readFileSync(outputPath);
      fs.unlinkSync(inputPath);
      fs.unlinkSync(outputPath);
      
      await sock.sendMessage(msg.chat, { image: result, caption: `◈ Desfoque nível ${level} aplicado! 🌫️` }, { quoted: msg });
      await msg.react('✅');
    } catch (e) {
      await msg.react('❌');
      return msg.reply(`◈ Erro: ${e.message}`);
    }
  }
};
