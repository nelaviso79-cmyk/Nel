import fetch from 'node-fetch';
import axios from 'axios';
import db from '#db';

export default {
  command: ['copilot', 'bing', 'copilotai', 'microsoft'],
  category: 'ia',
  description: 'Pergunta algo ao Microsoft Copilot AI',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const text = args.join(' ').trim();
    if (!text) {
      return msg.reply(`❧ Escreva uma *pergunta* para o *Microsoft Copilot* responder.\n\n▸ Exemplo: *${usedPrefix + command} Qual a capital de Moçambique?*`);
    }
    const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    const settings = db.getSettings(botId);
    const user = db.getUser(msg.sender);
    const username = user?.name || 'usuário';
    const botname = settings.botname || 'Bot';

    try {
      const { key } = await sock.sendMessage(msg.chat, { text: `⏳ *Copilot AI* está a processar...` }, { quoted: msg });
      await msg.react('🟦');
      let responseText = null;

      // Método 1: API delirius - bing copilot
      try {
        const res = await fetch(`${global.APIs.delirius.url}/ia/bing?text=${encodeURIComponent(text)}`);
        const json = await res.json();
        if (json?.status && json?.data) responseText = json.data;
      } catch {}

      // Método 2: API siputzx com modelo copilot
      if (!responseText) {
        try {
          const requestBody = { content: text, user: msg.sender, model: 'copilot' };
          const res = await axios.post('https://ai.siputzx.my.id', requestBody);
          if (res.data?.result) responseText = res.data.result;
        } catch {}
      }

      // Método 3: API zenzxz - bing
      if (!responseText) {
        try {
          const res = await fetch(`${global.APIs.zenzxz.url}/ai/bing?text=${encodeURIComponent(text)}`);
          const json = await res.json();
          if (json?.result) responseText = json.result;
        } catch {}
      }

      if (!responseText) {
        return sock.sendMessage(msg.chat, { text: '❧ Não foi possível obter resposta do *Copilot AI*.', edit: key }, { quoted: msg });
      }

      await sock.sendMessage(msg.chat, { text: responseText.trim(), edit: key }, { quoted: msg });
      await msg.react('✅');
    } catch (e) {
      await msg.reply(`> Ocorreu um erro ao executar *${usedPrefix + command}*.\n> [Erro: *${e.message}*]`);
    }
  },
};
