import fs from 'fs';
import { spawn } from 'child_process';

export default {
  command: ['rotacionar', 'rotate', 'girar', 'rodar'],
  category: 'utilidades',
  description: 'Rotacionar uma imagem 🔄',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    const quoted = msg.quoted || msg;
    const mime = (quoted.msg || quoted).mimetype || '';
    
    if (!/image/.test(mime)) {
      return msg.reply(`◈ Responda a uma *imagem* com o ângulo.\n\n✎ Exemplo: *${usedPrefix + command} 90*\n✎ Ângulos: 90, 180, 270, 45, etc.`);
    }
    
    const angle = parseInt(text) || 90;
    if (angle < 1 || angle > 360) return msg.reply('◈ Ângulo inválido! Use 1-360.');
    
    await msg.react('⏳');
    
    try {
      const buffer = await quoted.download();
      const inputPath = `./tmp/rotate_in_${Date.now()}.jpg`;
      const outputPath = `./tmp/rotate_out_${Date.now()}.jpg`;
      fs.writeFileSync(inputPath, buffer);
      
      const rad = (angle * Math.PI) / 180;
      const vf = angle === 90 ? 'transpose=1' : angle === 180 ? 'transpose=1,transpose=1' : angle === 270 ? 'transpose=2' : `rotate=${rad}`;
      
      await new Promise((resolve, reject) => {
        const proc = spawn('ffmpeg', ['-y', '-i', inputPath, '-vf', vf, outputPath]);
        let err = '';
        proc.stderr.on('data', d => err += d.toString());
        proc.on('close', code => code === 0 ? resolve() : reject(new Error(err)));
      });
      
      const result = fs.readFileSync(outputPath);
      fs.unlinkSync(inputPath);
      fs.unlinkSync(outputPath);
      
      await sock.sendMessage(msg.chat, { image: result, caption: `◈ Imagem rotacionada ${angle}°! 🔄` }, { quoted: msg });
      await msg.react('✅');
    } catch (e) {
      await msg.react('❌');
      return msg.reply(`◈ Erro: ${e.message}`);
    }
  }
};
