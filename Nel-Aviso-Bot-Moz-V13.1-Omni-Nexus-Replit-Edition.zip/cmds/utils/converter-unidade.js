export default {
  command: ['converter', 'unidade', 'medida'],
  category: 'utilidades',
  description: 'Conversor de unidades (peso, medida, temperatura) 📏',
  run: async ({ msg, args, usedPrefix, command }) => {
    if (args.length < 3) {
      return msg.reply(
        `📏 *CONVERSOR NEXUS* 📏\n\n` +
        `Converta pesos, medidas e temperaturas facilmente.\n\n` +
        `▸ *Uso:* ${usedPrefix + command} <valor> <de> <para>\n` +
        `▸ *Exemplos:*\n` +
        `   • ${usedPrefix + command} 100 kg lb\n` +
        `   • ${usedPrefix + command} 5 km m\n` +
        `   • ${usedPrefix + command} 32 c f\n\n` +
        `*Unidades Suportadas:* \n` +
        `⚖️ Peso: kg, lb, g, oz\n` +
        `📏 Comprimento: m, km, cm, mm, inch, ft, mile\n` +
        `🌡️ Temperatura: c, f, k`
      );
    }

    const valor = parseFloat(args[0].replace(',', '.'));
    const de = args[1].toLowerCase();
    const para = args[2].toLowerCase();

    if (isNaN(valor)) return msg.reply(`❌ Valor inválido!`);

    const conversions = {
      // Peso (base: kg)
      kg: 1, lb: 0.453592, g: 0.001, oz: 0.0283495,
      // Comprimento (base: m)
      m: 1, km: 1000, cm: 0.01, mm: 0.001, inch: 0.0254, ft: 0.3048, mile: 1609.34
    };

    let result;
    let type = '';

    // Temperatura
    if (['c', 'f', 'k'].includes(de) && ['c', 'f', 'k'].includes(para)) {
      type = '🌡️ Temperatura';
      let celsius;
      if (de === 'c') celsius = valor;
      else if (de === 'f') celsius = (valor - 32) * 5 / 9;
      else if (de === 'k') celsius = valor - 273.15;

      if (para === 'c') result = celsius;
      else if (para === 'f') result = (celsius * 9 / 5) + 32;
      else if (para === 'k') result = celsius + 273.15;
    } 
    // Outras unidades
    else if (conversions[de] && conversions[para]) {
      // Verificar se são do mesmo tipo (simplificado)
      const isWeight = ['kg', 'lb', 'g', 'oz'].includes(de);
      const isLength = ['m', 'km', 'cm', 'mm', 'inch', 'ft', 'mile'].includes(de);
      const targetIsWeight = ['kg', 'lb', 'g', 'oz'].includes(para);
      const targetIsLength = ['m', 'km', 'cm', 'mm', 'inch', 'ft', 'mile'].includes(para);

      if ((isWeight && targetIsWeight) || (isLength && targetIsLength)) {
        type = isWeight ? '⚖️ Peso' : '📏 Comprimento';
        const valorEmBase = valor * conversions[de];
        result = valorEmBase / conversions[para];
      } else {
        return msg.reply(`❌ Não é possível converter *${de}* para *${para}*.`);
      }
    } else {
      return msg.reply(`❌ Unidade não suportada!`);
    }

    return msg.reply(
      `📏 *CONVERSOR NEXUS* 📏\n\n` +
      `▸ Tipo: *${type}*\n` +
      `▸ De: *${valor} ${de}*\n` +
      `▸ Para: *${result.toFixed(4)} ${para}*\n\n` +
      `_Nexus Utility Engine_ ⚙️`
    );
  }
};
