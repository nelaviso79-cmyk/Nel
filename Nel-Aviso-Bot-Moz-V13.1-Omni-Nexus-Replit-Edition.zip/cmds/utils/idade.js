// ╔══════════════════════════════════════════════════════════════╗
//   NEL-AVISO-BOT-MOZ · cmds/utils/idade.js
//   Age Detection — Estima idade e género a partir de foto (IA)
// ╚══════════════════════════════════════════════════════════════╝

export const command = {
  name: 'age',
  aliases: ['idadedetect', 'estimaridade', 'detectionage', 'faceage', 'detectface'],
  description: 'Estima idade e género de uma pessoa na foto (IA)',
  category: 'utilidades',
  usage: '.age (citar uma imagem)',
  example: '.age [citar foto de pessoa]'
};

export default async function ({ sock, msg, args, from, sender, config }) {
  const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
  const imageMsg = quoted?.imageMessage;

  if (!imageMsg) {
    return sock.sendMessage(from, {
      text: '❌ Cita uma imagem com uma pessoa!\n\n💡 *Uso:* .age [citar foto]\n📌 Responde a uma foto com o comando'
    }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });

  try {
    // Download da imagem
    const stream = await sock.downloadContentFromMessage(imageMsg, 'image');
    let buffer = Buffer.alloc(0);
    for await (const chunk of stream) {
      buffer = Buffer.concat([buffer, chunk]);
    }

    // Upload para catbox
    const FormData = (await import('form-data')).default;
    const form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('fileToUpload', buffer, 'image.jpg');

    const uploadRes = await fetch('https://catbox.moe/user/api.php', {
      method: 'POST',
      body: form,
      headers: form.getHeaders()
    });

    const imageUrl = await uploadRes.text();
    if (!imageUrl || !imageUrl.startsWith('https://')) {
      throw new Error('Upload failed');
    }

    // Delirius IA — /ia/age
    const res = await fetch(`https://api.delirius.store/ia/age?url=${encodeURIComponent(imageUrl)}`);
    const data = await res.json();

    if (data?.status === 200 && data?.result) {
      const r = data.result;
      const info = `👤 *ANÁLISE FACIAL* (IA)

━━━━━━━━━━━━━━━━━━━━

🔍 *Detecção:*
  • Idade estimada: ${r.age || r.ageRange || 'N/A'} anos
  • Género: ${r.gender || 'N/A'}
${r.genderProbability ? `  • Confiança género: ${(r.genderProbability * 100).toFixed(1)}%` : ''}
${r.emotion ? `  • Emoção: ${r.emotion}` : ''}

📊 *Confiança:* ${r.confidence ? `${(r.confidence * 100).toFixed(1)}%` : 'Alta'}

💡 _Resultado gerado por IA — pode não ser 100% preciso_`;

      await sock.sendMessage(from, { text: info }, { quoted: msg });
      return;
    }
  } catch (e) {
    console.log('Age detection primary failed:', e.message);
  }

  // Fallback — IA visual
  try {
    const stream2 = await sock.downloadContentFromMessage(imageMsg, 'image');
    let buffer2 = Buffer.alloc(0);
    for await (const chunk of stream2) {
      buffer2 = Buffer.concat([buffer2, chunk]);
    }

    const FormData2 = (await import('form-data')).default;
    const form2 = new FormData2();
    form2.append('reqtype', 'fileupload');
    form2.append('fileToUpload', buffer2, 'image.jpg');

    const uploadRes2 = await fetch('https://catbox.moe/user/api.php', {
      method: 'POST',
      body: form2,
      headers: form2.getHeaders()
    });

    const imageUrl2 = await uploadRes2.text();

    if (imageUrl2 && imageUrl2.startsWith('https://')) {
      const res = await fetch(`https://api.delirius.store/ia/visual?url=${encodeURIComponent(imageUrl2)}&prompt=${encodeURIComponent('Estimate the age and gender of the person in this image. Respond in Portuguese with: Idade estimada: X anos, Género: Y')}`);
      const data = await res.json();

      if (data?.status === 200 && data?.result) {
        await sock.sendMessage(from, {
          text: `👤 *ANÁLISE FACIAL* (IA Visual)\n\n📝 ${data.result}\n\n_⚠️ Análise alternativa via IA visual_`
        }, { quoted: msg });
        return;
      }
    }
  } catch (e) {
    console.log('Age detection fallback failed:', e.message);
  }

  await sock.sendMessage(from, {
    text: '❌ Não consegui analisar a imagem. Certifica-te que contém um rosto visível.'
  }, { quoted: msg });
}
