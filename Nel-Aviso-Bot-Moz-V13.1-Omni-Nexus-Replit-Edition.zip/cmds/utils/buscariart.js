import fetch from 'node-fetch';

export default {
  command: ['buscariart', 'lexica', 'artsearch'],
  category: 'ia',
  description: 'Procura artes incríveis geradas por IA na galeria Lexica.',
  run: async ({ msg, sock, text, usedPrefix, command }) => {
    if (!text) return msg.reply(`❌ O que queres procurar?\n\nExemplo: *${usedPrefix + command} cyberpunk city*`);

    await msg.react('🔍');
    try {
      const res = await fetch(`https://lexica.art/api/v1/search?q=${encodeURIComponent(text)}`);
      const json = await res.json();
      
      if (!json.images || json.images.length === 0) {
        return msg.reply('❌ Não encontrei nenhuma arte com esse tema.');
      }

      // Pegar 1 imagem aleatória das primeiras 10 encontradas
      const image = json.images[Math.floor(Math.random() * Math.min(json.images.length, 10))];

      await sock.sendMessage(msg.chat, {
        image: { url: image.src },
        caption: `🎨 *Arte de IA Encontrada*\n\n📝 *Prompt Original:* ${image.prompt}\n\n> 🔍 Procurado por: ${msg.pushName}\n> 🌐 Fonte: Lexica.art`
      }, { quoted: msg });
      
      await msg.react('✅');
    } catch (e) {
      console.error(e);
      await msg.react('❌');
      await msg.reply(`❌ Erro ao buscar arte de IA.\n> [Erro: ${e.message}]`);
    }
  }
};
