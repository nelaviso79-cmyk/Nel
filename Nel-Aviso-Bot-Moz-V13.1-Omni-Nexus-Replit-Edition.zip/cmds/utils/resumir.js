import fetch from 'node-fetch';

export default {
  command: ['resumir', 'resumo', 'summarize'],
  category: 'utilidades',
  description: 'Cria um resumo executivo de textos ou links 📝',
  run: async ({ msg, text, usedPrefix, command }) => {
    if (!text && !msg.quoted) {
      return msg.reply(
        `📝 *NEXUS SUMMARIZER* 📝\n\n` +
        `Transforme textos longos ou links em resumos executivos diretos.\n\n` +
        `▸ *Uso:* ${usedPrefix + command} <texto ou link>\n` +
        `▸ *Exemplo:* ${usedPrefix + command} (cite um texto longo)`
      );
    }

    const content = text || msg.quoted?.text || msg.quoted?.body;
    if (!content) return msg.reply(`❌ Não encontrei conteúdo para resumir.`);

    await msg.react('⏳');
    try {
      const prompt = `Cria um resumo executivo estruturado com pontos chave (bullet points) do seguinte conteúdo. Responde em português de Moçambique de forma profissional e concisa.\n\nCONTEÚDO: ${content}`;
      const res = await fetch(`https://api.vreden.web.id/api/ai/chatgpt?prompt=${encodeURIComponent('És um assistente de alta performance especializado em resumos executivos.')}&text=${encodeURIComponent(prompt)}`);
      const json = await res.json();

      if (!json.status || !json.result) throw new Error('Falha na IA');

      const result = `📝 *RESUMO EXECUTIVO NEXUS* 📝\n\n` +
        `${json.result}\n\n` +
        `> 🧠 _Nexus Intelligence V12_`;
      
      await msg.reply(result);
      await msg.react('✅');
    } catch (e) {
      await msg.react('❌');
      return msg.reply(`❌ Erro ao gerar resumo. Tente novamente mais tarde.`);
    }
  }
};
