export default {
  command: ['technews', 'tecnologia', 'techcrunch', 'devnews'],
  category: 'utilidades',
  description: 'Notícias de tecnologia do mundo (dev, IA, gadgets)',
  run: async ({ sock, msg, args, usedPrefix, command }) => {
    const from = msg.chat;
    await sock.sendMessage(from, { react: { text: '📰', key: msg.key } });

  try {
    const res = await fetch('https://api.delirius.store/search/google?query=technology+news+2024+latest&num=5');
    const data = await res.json();
    if (data?.status === 200 && data?.result && data.result.length > 0) {
      const news = data.result.slice(0, 5);
      let text = '📰 *TECH NEWS* — Últimas Notícias\n\n━━━━━━━━━━━━━━━━━━━━\n\n';

      for (let i = 0; i < news.length; i++) {
        const n = news[i];
        text += `${i + 1}. 📰 *${n.title || 'N/A'}*\n`;
        if (n.description) text += `   💬 ${n.description.substring(0, 150)}${n.description.length > 150 ? '...' : ''}\n`;
        if (n.url) text += `   🔗 ${n.url}\n`;
        text += '\n';
      }

      await sock.sendMessage(from, {
        text: text.trim(),
        contextInfo: {
          externalAdReply: {
            title: 'Tech News',
            body: 'Últimas notícias de tecnologia',
            thumbnailUrl: 'https://cdn-icons-png.flaticon.com/512/2920/2920349.png',
            mediaType: 1
          }
        }
      }, { quoted: msg });
      return;
    }
  } catch (e) {
    console.log('Tech news failed:', e.message);
  }

  await sock.sendMessage(from, { text: '❌ Não consegui obter notícias de tecnologia.' }, { quoted: msg });
  }
};
