export default {
  command: ['gerarsenha', 'senha', 'password', 'passgen'],
  category: 'utilidades',
  description: 'Gerar uma senha segura aleatória.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    let length = parseInt(args[0]) || 12;
    if (length < 6) length = 6;
    if (length > 50) length = 50;

    const uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const lowercase = 'abcdefghijklmnopqrstuvwxyz';
    const numbers = '0123456789';
    const symbols = '!@#$%^&*()_+-=[]{}|;:,.<>?';
    const all = uppercase + lowercase + numbers + symbols;

    let password = '';
    // Ensure at least one of each type
    password += uppercase[Math.floor(Math.random() * uppercase.length)];
    password += lowercase[Math.floor(Math.random() * lowercase.length)];
    password += numbers[Math.floor(Math.random() * numbers.length)];
    password += symbols[Math.floor(Math.random() * symbols.length)];

    for (let i = password.length; i < length; i++) {
      password += all[Math.floor(Math.random() * all.length)];
    }

    // Shuffle the password
    password = password.split('').sort(() => Math.random() - 0.5).join('');

    const strength = length >= 16 ? '💪 Muito Forte' : length >= 12 ? '✅ Forte' : length >= 8 ? '⚠️ Média' : '❌ Fraca';

    return msg.reply(
      `❧ *Senha Gerada* 🔐\n\n` +
      `▸ Senha: \`\`\`${password}\`\`\`\n` +
      `▸ Comprimento: *${length} caracteres*\n` +
      `▸ Força: *${strength}*\n\n` +
      `⚠️ Não partilhes esta senha com ninguém!\n` +
      `▸ Usa *${usedPrefix + command} 20* para uma senha de 20 caracteres.`
    );
  },
};
