export default {
  command: ['tagme', 'mencionar', 'marcar'],
  category: 'utilidades',
  description: 'Marcar a ti mesmo no grupo (útil para se destacar).',
  run: async ({ msg, sock }) => {
    const sender = msg.sender;
    const num = sender.split('@')[0];
    return sock.reply(msg.chat, `▸ @${num}`, msg, { mentions: [sender] });
  },
};
