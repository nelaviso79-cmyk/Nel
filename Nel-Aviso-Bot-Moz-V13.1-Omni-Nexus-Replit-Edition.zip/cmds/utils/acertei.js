export default {
  command: ['acertei', 'adivinhar', 'guess', 'adivinha'],
  category: 'diversao',
  description: 'Jogo de adivinhar o número (1-10) 🎯',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    const chatId = msg.key.remoteJid;
    if (!global._guessGame) global._guessGame = {};

    if (text === 'novo' || text === 'new' || !global._guessGame[chatId]) {
      const number = Math.floor(Math.random() * 10) + 1;
      const attempts = 3;
      global._guessGame[chatId] = { number, attempts, maxAttempts: attempts };
      return await sock.sendMessage(msg.key.remoteJid, {
        text: `🎯 *ADIVINHE O NÚMERO*\n\nPensei num número de 1 a 10!\nTens *${attempts}* tentativas.\n\nUse: *${usedPrefix}${command} <número>*\nUse: *${usedPrefix}${command} novo* para reiniciar`
      }, { quoted: msg });
    }

    const guess = parseInt(text);
    if (isNaN(guess) || guess < 1 || guess > 10) {
      return await sock.sendMessage(msg.key.remoteJid, { text: '❌ Digite um número entre 1 e 10!' }, { quoted: msg });
    }

    const game = global._guessGame[chatId];
    game.attempts--;

    if (guess === game.number) {
      delete global._guessGame[chatId];
      return await sock.sendMessage(msg.key.remoteJid, {
        text: `🎉 *ACERTASTE!* 🎉\n\nO número era *${game.number}*!\nUsaste *${game.maxAttempts - game.attempts}* tentativa(s).\n\n🔄 *${usedPrefix}${command} novo* para jogar novamente!`
      }, { quoted: msg });
    }

    const hint = guess < game.number ? '⬆️ O número é MAIOR!' : '⬇️ O número é MENOR!';

    if (game.attempts <= 0) {
      const answer = game.number;
      delete global._guessGame[chatId];
      return await sock.sendMessage(msg.key.remoteJid, {
        text: `😢 *GAME OVER!*\n\nO número era *${answer}*.\n\n🔄 *${usedPrefix}${command} novo* para jogar novamente!`
      }, { quoted: msg });
    }

    await sock.sendMessage(msg.key.remoteJid, {
      text: `${hint}\n\n❌ Erraste! Restam *${game.attempts}* tentativa(s).`
    }, { quoted: msg });
  }
};
