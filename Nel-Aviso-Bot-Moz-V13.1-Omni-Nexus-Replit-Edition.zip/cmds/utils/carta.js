// ╔══════════════════════════════════════════════════════════╗
//   NEL-AVISO-BOT-MOZ · cmds/utils/carta.js
// ╚══════════════════════════════════════════════════════════╝

import fetch from 'node-fetch';

export default {
  command: ['carta', 'pokecard', 'cartapoke', 'pokemoncard'],
  category: 'diversao',
  description: 'Gerar carta Pokémon customizada com a tua foto 🃏⚡',

  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const q = msg.quoted;
    const pokeName = args.join(' ').trim() || 'pikachu';

    if (!q || !q.message?.imageMessage) {
      return msg.reply(
        `🃏 *CARTA POKÉMON CUSTOMIZADA* 🃏\n\n` +
        `Gere uma carta Pokémon com a tua foto!\n\n` +
        `📋 Como usar:\n` +
        `1️⃣ Responda a uma foto\n` +
        `2️⃣ *${usedPrefix}${command} pikachu*\n` +
        `3️⃣ *${usedPrefix}${command} charizard*\n\n` +
        `> A foto fica na carta Pokémon!`
      );
    }

    await msg.reply(`⏳ A gerar carta Pokémon de *${pokeName}*...`);

    try {
      // Download image
      const media = await sock.downloadMediaMessage(q);
      if (!media) throw new Error('Falha ao baixar imagem');

      // Upload to get URL
      const tmpForm = new FormData();
      const blob = new Blob([media]);
      tmpForm.append('reqtype', 'fileupload');
      tmpForm.append('fileToUpload', blob, 'image.jpg');
      const upRes = await fetch('https://catbox.moe/user/api.php', { method: 'POST', body: tmpForm });
      if (!upRes.ok) throw new Error('Falha ao hospedar imagem');
      const imgUrl = await upRes.text();

      if (!imgUrl || !imgUrl.startsWith('http')) throw new Error('URL inválida');

      // Use Delirius pokecard API
      const cardRes = await fetch(
        `https://api.delirius.store/search/pokecard?text=${encodeURIComponent(pokeName)}&url=${encodeURIComponent(imgUrl)}`
      );

      if (cardRes.ok) {
        const contentType = cardRes.headers.get('content-type') || '';
        if (contentType.includes('image')) {
          const buffer = Buffer.from(await cardRes.arrayBuffer());
          await sock.sendMessage(msg.chat, {
            image: buffer,
            caption: `🃏 *Carta Pokémon: ${pokeName}* ⚡\n\n👤 Dono: @${msg.sender.split('@')[0]}`
          }, { quoted: msg });
          return;
        }

        const data = await cardRes.json();
        if (data.status && data.result) {
          const cardUrl = data.result.url || data.result.image || data.result;
          await sock.sendMessage(msg.chat, {
            image: { url: cardUrl },
            caption: `🃏 *Carta Pokémon: ${pokeName}* ⚡\n\n👤 Dono: @${msg.sender.split('@')[0]}`
          }, { quoted: msg });
          return;
        }
      }

      await msg.reply(`❌ Não foi possível gerar a carta Pokémon. Tente novamente.`);

    } catch (e) {
      await msg.reply(`❌ Erro ao gerar carta: *${e.message}*`);
    }
  }
};
