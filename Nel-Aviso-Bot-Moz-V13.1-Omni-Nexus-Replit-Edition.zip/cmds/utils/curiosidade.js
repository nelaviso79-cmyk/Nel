/**
 * 💡 CURIOSIDADE — Factos curiosos aleatórios
 */
import fetch from 'node-fetch';

export default {
  command: ['curiosidade', 'curiosidades', 'facto', 'factoaleatorio', 'fact', 'didyouknow'],
  category: 'diversao',
  description: 'Factos curiosos aleatórios 💡',
  run: async ({ msg, sock }) => {
    try {
      let facto = null;

      // API 1: uselesfacts
      try {
        const res = await fetch('https://uselessfacts.jsph.pl/api/v2/facts/random?language=pt');
        const data = await res.json();
        if (data.text) facto = data.text;
      } catch {}

      // API 2: delirius
      if (!facto) {
        try {
          const res = await fetch('https://api.delirius.store/other/fact');
          const data = await res.json();
          if (data.status && data.result) facto = typeof data.result === 'string' ? data.result : data.result.fact || data.result.text;
        } catch {}
      }

      // API 3: Factos manuais em Português (Backup)
      if (!facto) {
        const factos = [
          "As formigas não têm pulmões.",
          "O coração de um camarão está na sua cabeça.",
          "É impossível espirrar com os olhos abertos.",
          "Os elefantes são os únicos animais que não conseguem saltar.",
          "O mel é o único alimento que não apodrece.",
          "O recorde de tempo de voo de uma galinha é de 13 segundos.",
          "Os golfinhos dormem com um olho aberto.",
          "A girafa não tem cordas vocais."
        ];
        facto = factos[Math.floor(Math.random() * factos.length)];
      }

      if (facto) {
        await msg.reply(`💡 *SABIA QUE...*\n\n${facto}\n\n_🧠 Facto curioso aleatório_`);
      } else {
        msg.reply(`💡 O cérebro humano usa cerca de 20% de toda a energia do corpo, mesmo pesando apenas 2% do peso total! 🧠`);
      }
    } catch (e) {
      msg.reply(`💡 As raposas podem fazer mais de 40 sons diferentes! 🦊`);
    }
  }
};
