export default {
  command: ['piadinhadodia', 'piada', 'humor', 'rir'],
  category: 'diversao',
  description: 'Receber uma piada aleatória para rir um pouco.',
  run: async ({ msg, sock, usedPrefix, command }) => {
    const piadas = [
      '😂 Por que o robô foi ao médico? Porque tinha um vírus!',
      '😂 O que a selva disse para o jacaré? "Eu te croco!"',
      '😂 Por que o livro de matemática está triste? Porque tem muitos problemas!',
      '😂 O que o lápis disse para o outro lápis? "Vives na minha ponta!"',
      '😂 Por que o computador foi ao hospital? Porque apanhou um vírus!',
      '😂 O que o zero disse ao oito? "Bonito cinto!"',
      '😂 Qual é o cúmulo da tecnologia? Um rádio WiFi!',
      '😂 O que a parede disse para a outra parede? "Encontramo-nos na esquina!"',
      '😂 Por que o bombeiro usa suspensórios vermelhos? Para segurar as calças!',
      '😂 O que o café disse para o açúcar? "Sem ti a minha vida é amarga!"',
      '😂 O que uma impressora disse para a outra? "Essa folha é tua ou é impressão minha?"',
      '😂 Por que o mar não seca? Porque tem sal na água... sal gosta de água salgada!',
      '😂 O que o pombo disse para o outro? "Voo contigo!"',
      '😂 Qual é a cidade que não tem táxi? "Pé-ru!"',
      '😂 Por que o guarda-chuva não vai à praia? Porque tem medo de se abrir!',
      '😂 O que o hamburger disse para o outro? "Estás com cara de pão!"',
      '😂 O que o relógio disse quando teve fome? "Já são horas de comer!"',
      '😂 Qual é o esporte mais esperançoso? O salto em altura, porque sempre está a subir!',
      '😂 Por que o peru se esconde? Porque é Dia de Ação de Graças!',
      '😂 O que o queijo disse quando se olhou ao espelho? "Eu sou gouda!"',
    ];

    const piada = piadas[Math.floor(Math.random() * piadas.length)];
    return msg.reply(`❧ *Piada do Dia* 😄\n\n${piada}\n\n▸ Usa *${usedPrefix + command}* para outra piada!`);
  },
};
