import fetch from 'node-fetch';

export default {
  command: ['conversormoeda', 'converter', 'cambio2'],
  category: 'utilidades',
  description: 'Converte valores entre diferentes moedas em tempo real.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    if (args.length < 3) {
      return msg.reply(`💰 *CONVERSOR DE MOEDAS* 💰\n\n▸ Use: *${usedPrefix + command} <valor> <de> <para>*\n▸ Exemplo: *${usedPrefix + command} 100 USD MZN*\n\n💱 Moedas comuns: MZN, USD, ZAR, EUR, BRL.`);
    }

    const amount = parseFloat(args[0]);
    const from = args[1].toUpperCase();
    const to = args[2].toUpperCase();

    if (isNaN(amount)) return msg.reply('❌ Por favor, insira um valor numérico válido.');

    await msg.react('💱');
    try {
      const res = await fetch(`https://api.exchangerate-api.com/v4/latest/${from}`);
      const data = await res.json();
      
      if (data.error) throw new Error('Moeda de origem não encontrada.');
      
      const rate = data.rates[to];
      if (!rate) throw new Error('Moeda de destino não encontrada.');
      
      const converted = (amount * rate).toLocaleString('pt-MZ', { minimumFractionDigits: 2 });
      
      const texto = `💱 *CONVERSÃO DE MOEDA*\n\n` +
                    `💵 *De:* ${amount.toLocaleString()} ${from}\n` +
                    `💸 *Para:* ${converted} ${to}\n` +
                    `📈 *Taxa:* 1 ${from} = ${rate.toFixed(4)} ${to}\n\n` +
                    `_Dados atualizados em tempo real_`;

      await msg.reply(texto);
      await msg.react('✅');
    } catch (e) {
      console.error(e);
      await msg.react('❌');
      await msg.reply(`❌ Erro ao converter: ${e.message}`);
    }
  }
};
