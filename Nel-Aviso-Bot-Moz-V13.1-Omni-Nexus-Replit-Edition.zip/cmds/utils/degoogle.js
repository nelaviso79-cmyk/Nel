export default {
  command: ['degoogle', 'gg', 'buscar', 'pesquisar'],
  category: 'utilidades',
  description: 'Pesquisar no Google e obter resultados 🔍',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    if (!text) return await sock.sendMessage(msg.key.remoteJid, { text: `✳️ Use: ${usedPrefix}${command} <pesquisa>\n\nExemplo: ${usedPrefix}${command} Moçambique turismo` }, { quoted: msg });

    try {
      const query = encodeURIComponent(text);
      const url = `https://www.google.com/search?q=${query}&hl=pt-BR`;
      const response = await fetch(url, {
        headers: { 'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/91.0.4472.120 Mobile Safari/537.36' }
      });
      const html = await response.text();

      // Extract search results
      const results = [];
      const regex = /<a href="\/url\?q=(https?:\/\/[^&]+)&[^"]*"[^>]*>(.*?)<\/a>/gi;
      let match;
      while ((match = regex.exec(html)) !== null && results.length < 5) {
        const link = decodeURIComponent(match[1]);
        const title = match[2].replace(/<[^>]+>/g, '').trim();
        if (title && !link.includes('google.com') && title.length > 3) {
          results.push({ title, link });
        }
      }

      if (results.length === 0) {
        // Fallback: just provide search link
        return await sock.sendMessage(msg.key.remoteJid, {
          text: `🔍 *Resultados para:* "${text}"\n\nNenhum resultado directo encontrado.\n🔗 Pesquisar: https://www.google.com/search?q=${query}&hl=pt-BR`
        }, { quoted: msg });
      }

      let result = `🔍 *PESQUISA: "${text}"*\n\n`;
      results.forEach((r, i) => {
        result += `${i + 1}. 📎 *${r.title}*\n   🔗 ${r.link}\n\n`;
      });
      result += `🔗 Mais: https://www.google.com/search?q=${query}&hl=pt-BR`;

      await sock.sendMessage(msg.key.remoteJid, { text: result }, { quoted: msg });
    } catch (e) {
      await sock.sendMessage(msg.key.remoteJid, {
        text: `🔍 *PESQUISA: "${text}"*\n\n🔗 https://www.google.com/search?q=${encodeURIComponent(text)}&hl=pt-BR`
      }, { quoted: msg });
    }
  }
};
