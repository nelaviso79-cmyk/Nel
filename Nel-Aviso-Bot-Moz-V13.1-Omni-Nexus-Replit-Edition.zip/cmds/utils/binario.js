export default {
  command: ['binario', 'binary', 'codigoBinario', 'codigobinario'],
  category: 'utilidades',
  description: 'Converter texto para código binário e vice-versa 💻',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    if (!text) return await sock.sendMessage(msg.key.remoteJid, { text: `✳️ Use: ${usedPrefix}${command} <texto ou binário>\n\nExemplos:\n${usedPrefix}${command} OLA\n${usedPrefix}${command} 01001111` }, { quoted: msg });

    // Detect if input is binary
    const isBinary = /^[01\s]+$/.test(text);

    let result = '';
    if (isBinary) {
      // Binary to text
      const bytes = text.trim().split(/\s+/);
      const decoded = bytes.map(b => {
        const code = parseInt(b, 2);
        return code > 0 ? String.fromCharCode(code) : '';
      }).join('');
      result = `💻 *BINÁRIO → TEXTO*\n\n`;
      result += `📥 Binário: ${text}\n`;
      result += `📤 Texto: *${decoded}*`;
    } else {
      // Text to binary
      const encoded = text.split('').map(ch => {
        const bin = ch.charCodeAt(0).toString(2);
        return bin.padStart(8, '0');
      }).join(' ');
      result = `💻 *TEXTO → BINÁRIO*\n\n`;
      result += `📥 Texto: ${text}\n`;
      result += `📤 Binário: *${encoded}*\n\n`;
      result += `📊 Total bits: *${text.length * 8}*\n`;
      result += `📊 Total bytes: *${text.length}*`;
    }

    await sock.sendMessage(msg.key.remoteJid, { text: result }, { quoted: msg });
  }
};
