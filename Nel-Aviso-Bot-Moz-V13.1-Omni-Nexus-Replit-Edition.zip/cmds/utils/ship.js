// ╔══════════════════════════════════════════════════════════╗
//   NEL-AVISO-BOT-MOZ · cmds/utils/ship.js
// ╚══════════════════════════════════════════════════════════╝

import fetch from 'node-fetch';

export default {
  command: ['ship', 'casalcard', 'match', 'compatibilidade', 'lovematch'],
  category: 'diversao',
  description: 'Card visual de compatibilidade amorosa entre 2 pessoas 💕',

  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const target1 = msg.mentionedJid?.[0] || msg.sender;
    const target2 = msg.mentionedJid?.[1] || (msg.quoted?.sender) || null;

    if (!target2) {
      return msg.reply(
        `💕 *SHIP — Compatibilidade Amorosa* 💕\n\n` +
        `Veja a compatibilidade entre duas pessoas com card visual!\n\n` +
        `📋 Como usar:\n` +
        `• *${usedPrefix}${command} @pessoa1 @pessoa2*\n` +
        `• Responda msg de alguém + *${usedPrefix}${command} @outra*\n\n` +
        `> Mostra card com % de compatibilidade!`
      );
    }

    if (target1 === target2) {
      return msg.reply(`❌ Não pode fazer ship consigo mesmo! 😂`);
    }

    await msg.reply(`💕 A calcular compatibilidade...`);

    try {
      const name1 = (await sock.getName(target1)) || target1.split('@')[0];
      const name2 = (await sock.getName(target2)) || target2.split('@')[0];

      // Calculate love percentage based on names (deterministic)
      const combined = [name1, name2].sort().join('').toLowerCase();
      let hash = 0;
      for (let i = 0; i < combined.length; i++) {
        hash = ((hash << 5) - hash) + combined.charCodeAt(i);
        hash = Math.abs(hash);
      }
      const percentage = (hash % 101); // 0-100
      const pct = Math.min(percentage, 100);

      // Love messages
      const loveMsg = pct >= 90 ? '🔥 Casamento perfeito!' :
        pct >= 75 ? '💕 Grande amor!' :
        pct >= 60 ? '❤️ Bom casal!' :
        pct >= 45 ? '💛 Talvez...' :
        pct >= 25 ? '🤔 Difícil...' :
        '💔 Sem chance!';

      // Try to get profile pictures
      let pfp1, pfp2;
      try { pfp1 = await sock.profilePictureUrl(target1, 'image'); } catch (e) { pfp1 = 'https://i.ibb.co/kQ2H5mf/default-pfp.png'; }
      try { pfp2 = await sock.profilePictureUrl(target2, 'image'); } catch (e) { pfp2 = 'https://i.ibb.co/kQ2H5mf/default-pfp.png'; }

      // Try canvas API
      try {
        const shipRes = await fetch(
          `https://api.delirius.store/canvas/ship?` +
          `image1=${encodeURIComponent(pfp1)}` +
          `&image2=${encodeURIComponent(pfp2)}` +
          `&name1=${encodeURIComponent(name1)}` +
          `&name2=${encodeURIComponent(name2)}` +
          `&percentage=${pct}`
        );

        if (shipRes.ok) {
          const contentType = shipRes.headers.get('content-type') || '';
          if (contentType.includes('image')) {
            const buffer = Buffer.from(await shipRes.arrayBuffer());
            await sock.sendMessage(msg.chat, {
              image: buffer,
              caption:
                `💕 *SHIP RESULT* 💕\n\n` +
                `👫 *${name1}* ❤️ *${name2}*\n` +
                `📊 Compatibilidade: *${pct}%*\n` +
                `${loveMsg}\n\n` +
                `> @${target1.split('@')[0]} + @${target2.split('@')[0]}`
            }, { quoted: msg });
            return;
          }
        }
      } catch (e) { /* Canvas failed, use text */ }

      // Try friendship card
      try {
        const friendRes = await fetch(
          `https://api.delirius.store/canvas/friendship?` +
          `image1=${encodeURIComponent(pfp1)}` +
          `&image2=${encodeURIComponent(pfp2)}` +
          `&name1=${encodeURIComponent(name1)}` +
          `&name2=${encodeURIComponent(name2)}` +
          `&percentage=${pct}` +
          `&text=${encodeURIComponent(loveMsg)}`
        );

        if (friendRes.ok) {
          const contentType = friendRes.headers.get('content-type') || '';
          if (contentType.includes('image')) {
            const buffer = Buffer.from(await friendRes.arrayBuffer());
            await sock.sendMessage(msg.chat, {
              image: buffer,
              caption:
                `💕 *SHIP RESULT* 💕\n\n` +
                `👫 *${name1}* ❤️ *${name2}*\n` +
                `📊 Compatibilidade: *${pct}%*\n${loveMsg}`
            }, { quoted: msg });
            return;
          }
        }
      } catch (e) { /* Canvas failed, use text */ }

      // Fallback: text-based ship
      const hearts = '❤️'.repeat(Math.ceil(pct / 10)) + '🖤'.repeat(10 - Math.ceil(pct / 10));
      await msg.reply(
        `💕 *SHIP RESULT* 💕\n\n` +
        `👫 *${name1}* ❤️ *${name2}*\n\n` +
        `📊 Compatibilidade: *${pct}%*\n` +
        `${hearts}\n` +
        `${loveMsg}`
      );

    } catch (e) {
      await msg.reply(`❌ Erro ao calcular ship: *${e.message}*`);
    }
  }
};
