export default {
  command: ['codigobarras', 'barcode', 'barras', 'codbarras'],
  category: 'utilidades',
  description: 'Gerar código de barras a partir de texto 📊',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    if (!text) return await sock.sendMessage(msg.key.remoteJid, { text: `✳️ Use: ${usedPrefix}${command} <texto ou número>\n\nExemplo: ${usedPrefix}${command} 123456789` }, { quoted: msg });

    try {
      const encoded = encodeURIComponent(text);
      const url = `https://bwipjs-api.metafloor.com/?bcid=code128&text=${encoded}&scale=3&includetext=true`;

      await sock.sendMessage(msg.key.remoteJid, {
        image: { url },
        caption: `📊 *CÓDIGO DE BARRAS*\n\n📝 Dados: ${text}\n🔗 Tipo: Code 128`
      }, { quoted: msg });
    } catch (e) {
      await sock.sendMessage(msg.key.remoteJid, { text: '❌ Erro ao gerar código de barras!' }, { quoted: msg });
    }
  }
};
