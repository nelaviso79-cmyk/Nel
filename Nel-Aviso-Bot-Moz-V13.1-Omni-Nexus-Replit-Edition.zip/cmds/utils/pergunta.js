/**
 * 🧠 PERGUNTA — IA responde perguntas com contexto moçambicano
 */
import fetch from 'node-fetch';

export default {
  command: ['pergunta', 'ask', 'perguntar', 'dizme'],
  category: 'ia',
  description: 'Fazer pergunta e obter resposta da IA 🧠',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const text = args.join(' ').trim();
    if (!text) return msg.reply(`❌ Use: *${usedPrefix}${command} <pergunta>*\nEx: *${usedPrefix}pergunta Como fazer baião de dois?*`);

    try {
      let resposta = null;

      // API 1: delirius GPT
      try {
        const res = await fetch(`https://api.delirius.store/ai/gpt?prompt=${encodeURIComponent(text)}`);
        const data = await res.json();
        if (data.status && data.result) resposta = data.result;
      } catch {}

      // API 2: siputzx GPT
      if (!resposta) {
        try {
          const res = await fetch(`https://app.siputzx.my.id/api/ai/gpt4?content=${encodeURIComponent(text)}`);
          const data = await res.json();
          if (data.status && data.data) resposta = typeof data.data === 'string' ? data.data : data.data.text || JSON.stringify(data.data);
        } catch {}
      }

      if (resposta) {
        let r = `🧠 *RESPOSTA*\n\n${resposta}\n\n_💭 Perguntou: ${text}_`;
        if (r.length > 4096) r = r.substring(0, 4096) + '...';
        await msg.reply(r);
      } else {
        msg.reply(`❌ Não foi possível obter resposta. Tente *.ia* como alternativa.`);
      }
    } catch (e) {
      msg.reply(`❌ Erro ao processar pergunta.`);
    }
  }
};
