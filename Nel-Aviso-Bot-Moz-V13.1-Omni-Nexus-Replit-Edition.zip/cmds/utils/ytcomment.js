import fetch from 'node-fetch';
import uploadImage from '#uploadImage';

export default {
  command: ['ytcomment', 'comentario', 'ytc'],
  category: 'diversao',
  description: 'Cria um comentário do YouTube com o teu avatar e texto.',
  run: async ({ msg, sock, text, usedPrefix, command }) => {
    if (!text) return msg.reply(`❌ O que queres comentar?\n\nExemplo: *${usedPrefix + command} Este bot é top!*`);

    await msg.react('📺');
    try {
      let profileUrl;
      try {
        profileUrl = await sock.profilePictureUrl(msg.sender, 'image');
      } catch {
        profileUrl = 'https://telegra.ph/file/241d9774659970966952e.jpg';
      }

      const username = msg.pushName || 'User';
      const api = `https://api.vreden.web.id/api/canvas/ytcomment?url=${encodeURIComponent(profileUrl)}&username=${encodeURIComponent(username)}&text=${encodeURIComponent(text)}`;
      const res = await fetch(api);
      
      if (!res.ok) throw new Error('Falha na API de Canvas');
      
      const buffer = Buffer.from(await res.arrayBuffer());

      await sock.sendMessage(msg.chat, {
        image: buffer,
        caption: `📺 *YouTube Comment*\n\n👤 *${username}:* ${text}`
      }, { quoted: msg });
      
      await msg.react('✅');
    } catch (e) {
      console.error(e);
      await msg.react('❌');
      await msg.reply(`❌ Erro ao gerar comentário. Tenta novamente mais tarde.\n> [Erro: ${e.message}]`);
    }
  }
};
