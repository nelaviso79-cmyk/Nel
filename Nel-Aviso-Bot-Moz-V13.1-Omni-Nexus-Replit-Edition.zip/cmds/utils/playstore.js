// ╔══════════════════════════════════════════════════════════════╗
//   NEL-AVISO-BOT-MOZ · cmds/utils/playstore.js
//   PlayStore — Busca de apps na Google Play Store
// ╚══════════════════════════════════════════════════════════════╝

export const command = {
  name: 'playstore',
  aliases: ['appsearch', 'appstore', 'buscarapp', 'playapp', 'appinfo'],
  description: 'Busca aplicativos na Google Play Store',
  category: 'utilidades',
  usage: '.playstore <nome do app>',
  example: '.playstore WhatsApp'
};

export default async function ({ sock, msg, args, from, sender, config }) {
  const query = args.join(' ').trim();
  if (!query) {
    return sock.sendMessage(from, {
      text: '❌ Escreve o nome do app!\n\n💡 *Uso:* .playstore <nome>\n📌 *Ex:* .playstore WhatsApp'
    }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '📱', key: msg.key } });

  try {
    // Delirius Search — /search/playstore
    const res = await fetch(`https://api.delirius.store/search/playstore?query=${encodeURIComponent(query)}`);
    const data = await res.json();

    if (data?.status === 200 && data?.result && data.result.length > 0) {
      const apps = data.result.slice(0, 3);
      let text = `📱 *PLAY STORE* — "${query}"\n\n━━━━━━━━━━━━━━━━━━━━\n\n`;

      for (let i = 0; i < apps.length; i++) {
        const app = apps[i];
        text += `${i === 0 ? '🥇' : i === 1 ? '🥈' : '🥉'} *${app.title || app.name || 'N/A'}*\n`;
        if (app.developer || app.author) text += `  👨‍💻 Dev: ${app.developer || app.author}\n`;
        if (app.rating || app.score) {
          const rating = app.rating || (app.score / 5 * 100).toFixed(0) + '%';
          text += `  ⭐ Avaliação: ${rating}\n`;
        }
        if (app.installs || app.downloads) text += `  📥 Downloads: ${app.installs || app.downloads}\n`;
        if (app.price) text += `  💰 Preço: ${app.price === '0' || app.price === 'Free' ? 'Gratuito 🆓' : app.price}\n`;
        if (app.genre || app.category) text += `  🏷️ Categoria: ${app.genre || app.category}\n`;
        if (app.description) text += `  💬 ${app.description.substring(0, 150)}${app.description.length > 150 ? '...' : ''}\n`;
        if (app.url || app.link || app.id) {
          const link = app.url || app.link || `https://play.google.com/store/apps/details?id=${app.id}`;
          text += `  🔗 ${link}\n`;
        }
        text += '\n';
      }

      // Enviar ícone do primeiro app se disponível
      const iconUrl = apps[0].icon || apps[0].image || apps[0].thumbnail;
      if (iconUrl) {
        try {
          const imgRes = await fetch(iconUrl);
          if (imgRes.ok) {
            const buffer = Buffer.from(await imgRes.arrayBuffer());
            await sock.sendMessage(from, {
              image: buffer,
              caption: text.trim(),
              contextInfo: {
                externalAdReply: {
                  title: apps[0].title || apps[0].name || query,
                  body: `Play Store — ${apps[0].developer || ''}`,
                  thumbnailUrl: iconUrl,
                  mediaType: 1
                }
              }
            }, { quoted: msg });
            return;
          }
        } catch (e) { }
      }

      await sock.sendMessage(from, { text: text.trim() }, { quoted: msg });
      return;
    }
  } catch (e) {
    console.log('PlayStore primary failed:', e.message);
  }

  // Fallback — Google search
  try {
    const res = await fetch(`https://api.delirius.store/search/google?query=${encodeURIComponent(query + ' site:play.google.com')}`);
    const data = await res.json();

    if (data?.status === 200 && data?.result && data.result.length > 0) {
      const results = data.result.slice(0, 3);
      let text = `📱 *PLAY STORE* — "${query}"\n_(Resultados via Google)_\n\n`;

      for (const r of results) {
        text += `📱 *${r.title}*\n🔗 ${r.url}\n📝 ${r.description || 'Sem descrição'}\n\n`;
      }

      await sock.sendMessage(from, { text: text.trim() }, { quoted: msg });
      return;
    }
  } catch (e) {
    console.log('PlayStore fallback failed:', e.message);
  }

  await sock.sendMessage(from, {
    text: `❌ Não encontrei "${query}" na Play Store.`
  }, { quoted: msg });
}
