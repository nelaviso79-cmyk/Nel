export default {
  command: ['velha', 'jogodavelha', 'tictactoe', 'velhajogo', 'trihalha'],
  category: 'diversao',
  description: 'Jogo da velha (Tic-Tac-Toe) contra o bot ❌⭕',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    if (!text || !text.includes('/')) {
      return msg.reply(
        `❌⭕ *JOGO DA VELHA* ❌⭕\n\n` +
        `◈ Jogue contra o bot!\n\n` +
        `✎ Formato: *${usedPrefix + command} posição*\n\n` +
        `▸ Posições (1-9):\n` +
        ` 1 │ 2 │ 3\n───┼───┼───\n 4 │ 5 │ 6\n───┼───┼───\n 7 │ 8 │ 9\n\n` +
        `✎ Exemplo: *${usedPrefix + command} 5* (centro)\n\n` +
        `◈ Tu jogas com ❌, o bot com ⭕`
      );
    }

    // Inicializar tabuleiro na memória global
    global._velha = global._velha || {};
    const chatId = msg.chat;
    const userId = msg.sender;

    if (!global._velha[chatId] || text === 'novo' || text === 'reset') {
      global._velha[chatId] = {
        tabuleiro: Array(9).fill('⬜'),
        jogador: userId,
        vez: '❌'
      };
      return msg.reply(
        `❌⭕ *NOVO JOGO DA VELHA* ❌⭕\n\n` +
        `⬜│⬜│⬜\n───┼───┼───\n⬜│⬜│⬜\n───┼───┼───\n⬜│⬜│⬜\n\n` +
        `▸ Tua vez! Jogue com: *${usedPrefix + command} 1-9*\n` +
        `▸ Tu: ❌ | Bot: ⭕`
      );
    }

    const jogo = global._velha[chatId];
    const pos = parseInt(text.trim()) - 1;

    if (isNaN(pos) || pos < 0 || pos > 8) return msg.reply('◈ Posição inválida! Use 1-9.');
    if (jogo.tabuleiro[pos] !== '⬜') return msg.reply('◈ Posição já ocupada! Escolha outra.');

    // Jogada do jogador
    jogo.tabuleiro[pos] = '❌';
    
    const vencedorJogador = checkVencedor(jogo.tabuleiro, '❌');
    if (vencedorJogador) {
      const display = mostrarTabuleiro(jogo.tabuleiro);
      delete global._velha[chatId];
      return msg.reply(`${display}\n\n🎉 *TU VENCESTE!* 🎉\n\n_${usedPrefix + command} novo_ para jogar de novo`);
    }
    
    if (jogo.tabuleiro.every(c => c !== '⬜')) {
      const display = mostrarTabuleiro(jogo.tabuleiro);
      delete global._velha[chatId];
      return msg.reply(`${display}\n\n🤝 *EMPATE!* 🤝\n\n_${usedPrefix + command} novo_ para jogar de novo`);
    }

    // Jogada do bot (IA simples)
    const posBot = jogadaBot(jogo.tabuleiro);
    jogo.tabuleiro[posBot] = '⭕';

    const vencedorBot = checkVencedor(jogo.tabuleiro, '⭕');
    const display = mostrarTabuleiro(jogo.tabuleiro);

    if (vencedorBot) {
      delete global._velha[chatId];
      return msg.reply(`${display}\n\n🤖 *O BOT VENCEU!* 😈\n\n_${usedPrefix + command} novo_ para jogar de novo`);
    }

    if (jogo.tabuleiro.every(c => c !== '⬜')) {
      delete global._velha[chatId];
      return msg.reply(`${display}\n\n🤝 *EMPATE!* 🤝\n\n_${usedPrefix + command} novo_ para jogar de novo`);
    }

    return msg.reply(
      `${display}\n\n` +
      `▸ Bot jogou na posição *${posBot + 1}*\n` +
      `▸ Tua vez! Use: *${usedPrefix + command} 1-9*`
    );
  }
};

function mostrarTabuleiro(t) {
  return `${t[0]}│${t[1]}│${t[2]}\n───┼───┼───\n${t[3]}│${t[4]}│${t[5]}\n───┼───┼───\n${t[6]}│${t[7]}│${t[8]}`;
}

function checkVencedor(t, s) {
  const linhas = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
  return linhas.some(([a,b,c]) => t[a] === s && t[b] === s && t[c] === s);
}

function jogadaBot(t) {
  // Tentar ganhar
  for (let i = 0; i < 9; i++) {
    if (t[i] === '⬜') {
      t[i] = '⭕';
      if (checkVencedor(t, '⭕')) { t[i] = '⬜'; return i; }
      t[i] = '⬜';
    }
  }
  // Bloquear jogador
  for (let i = 0; i < 9; i++) {
    if (t[i] === '⬜') {
      t[i] = '❌';
      if (checkVencedor(t, '❌')) { t[i] = '⬜'; return i; }
      t[i] = '⬜';
    }
  }
  // Centro
  if (t[4] === '⬜') return 4;
  // Cantos
  const cantos = [0, 2, 6, 8].filter(i => t[i] === '⬜');
  if (cantos.length) return cantos[Math.floor(Math.random() * cantos.length)];
  // Qualquer lugar
  const livres = t.map((v, i) => v === '⬜' ? i : -1).filter(i => i >= 0);
  return livres[Math.floor(Math.random() * livres.length)];
}
