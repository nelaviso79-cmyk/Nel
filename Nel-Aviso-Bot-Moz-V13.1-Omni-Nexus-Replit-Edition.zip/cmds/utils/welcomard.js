export const command = {
  name: 'welcomard',
  aliases: ['welcomecard', 'bemvindocard', 'bvcard', 'cardbv', 'boasvindas'],
  description: 'Gera card de boas-vindas bonita com foto e nome',
  category: 'grupos',
  usage: '.welcomard @membro',
  example: '.welcomard @João'
};

export default async function ({ sock, msg, args, from, sender, config }) {
  let targetJid = sender;
  if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]) {
    targetJid = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
  } else if (args[0]?.includes('@')) {
    targetJid = args[0].replace(/[@\s]/g, '') + '@s.whatsapp.net';
  }

  const targetName = args.join(' ').replace(/@\d+/g, '').trim() || msg.pushName || 'Membro';

  await sock.sendMessage(from, { react: { text: '👋', key: msg.key } });

  try {
    let avatarUrl = 'https://i.ibb.co/4p4NfKx/default-avatar.png';
    try { avatarUrl = await sock.profilePictureUrl(targetJid, 'image'); } catch (e) { }

    let bgUrl = 'https://i.ibb.co/4p4NfKx/default-avatar.png';
    try { bgUrl = await sock.profilePictureUrl(from, 'image'); } catch (e) { }

    const groupName = (await sock.groupMetadata(from)).subject || 'Grupo';

    const res = await fetch(`https://api.delirius.store/canvas/welcomecard?name=${encodeURIComponent(targetName)}&url=${encodeURIComponent(avatarUrl)}&background=${encodeURIComponent(bgUrl)}&group=${encodeURIComponent(groupName)}&member=count`);

    if (res.ok) {
      const buffer = Buffer.from(await res.arrayBuffer());
      await sock.sendMessage(from, {
        image: buffer,
        caption: `👋 Bem-vindo(a) *${targetName}* ao grupo *${groupName}*! 🎉`,
        mentions: [targetJid]
      }, { quoted: msg });
      return;
    }
  } catch (e) { console.log('Welcomecard failed:', e.message); }

  // Fallback com balcard genérico
  try {
    let avatarUrl = 'https://i.ibb.co/4p4NfKx/default-avatar.png';
    try { avatarUrl = await sock.profilePictureUrl(targetJid, 'image'); } catch (e) { }

    const groupName = (await sock.groupMetadata(from)).subject || 'Grupo';
    const memberCount = (await sock.groupMetadata(from)).participants.length;

    const res = await fetch(`https://api.delirius.store/canvas/balcard?name=${encodeURIComponent(targetName)}&url=${encodeURIComponent(avatarUrl)}&background=https://i.ibb.co/4p4NfKx/default-avatar.png&level=BEM-VINDO&xp=${memberCount}&role=Membro`);

    if (res.ok) {
      const buffer = Buffer.from(await res.arrayBuffer());
      await sock.sendMessage(from, {
        image: buffer,
        caption: `👋 Bem-vindo(a) *${targetName}* ao grupo *${groupName}*! 🎉`,
        mentions: [targetJid]
      }, { quoted: msg });
      return;
    }
  } catch (e) { console.log('Welcomecard fallback failed:', e.message); }

  // Fallback texto
  const groupName2 = (await sock.groupMetadata(from)).subject || 'Grupo';
  const memberCount2 = (await sock.groupMetadata(from)).participants.length;
  await sock.sendMessage(from, {
    text: `╔══════════════════════╗\n║  👋 *BEM-VINDO(A)*  ║\n╠══════════════════════╣\n║ 🧑 ${targetName}\n║ 📍 ${groupName2}\n║ 👥 Membro #${memberCount2}\n╚══════════════════════╝`,
    mentions: [targetJid]
  }, { quoted: msg });
}
