import fetch from 'node-fetch';

export default {
  command: ['ss', 'screenshot', 'captura', 'printsite'],
  category: 'utilidades',
  description: 'Capturar screenshot/print de um site 📸',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const url = args[0];
    if (!url) {
      return msg.reply(
        `📸 *SCREENSHOT DE SITE*\n\n` +
        `▸ Capture uma imagem de qualquer site!\n\n` +
        `✏️ *Exemplos:*\n` +
        `▸ *${usedPrefix + command} https://www.google.com*\n` +
        `▸ *${usedPrefix + command} https://www.youtube.com*\n\n` +
        `⚠️ O link deve começar com http:// ou https://`
      );
    }

    if (!/^https?:\/\//i.test(url)) {
      return msg.reply('❧ O link deve começar com http:// ou https://');
    }

    try {
      await msg.react('📸');
      let screenshotUrl = null;

      // Método 1: API delirius
      try {
        const res = await fetch(`${global.APIs.delirius.url}/tools/ss?url=${encodeURIComponent(url)}`);
        const json = await res.json();
        if (json?.status && json?.data?.url) screenshotUrl = json.data.url;
        else if (json?.status && json?.data) screenshotUrl = typeof json.data === 'string' ? json.data : json.data.image || json.data.screenshot;
      } catch {}

      // Método 2: API vreden
      if (!screenshotUrl) {
        try {
          const res = await fetch(`${global.APIs.vreden.url}/api/v1/tools/ss?url=${encodeURIComponent(url)}`);
          const json = await res.json();
          if (json?.status && json?.result) screenshotUrl = typeof json.result === 'string' ? json.result : json.result.url || json.result.image || json.result.screenshot;
        } catch {}
      }

      // Método 3: thum.io (serviço directo)
      if (!screenshotUrl) {
        try {
          screenshotUrl = `https://image.thum.io/get/width/1280/crop/800/${url}`;
          const testRes = await fetch(screenshotUrl, { method: 'HEAD', timeout: 15000 });
          if (!testRes.ok) screenshotUrl = null;
        } catch {}
      }

      // Método 4: screenshot.guru
      if (!screenshotUrl) {
        try {
          screenshotUrl = `https://api.screenshot.guru/?url=${encodeURIComponent(url)}&width=1280&height=800`;
        } catch {}
      }

      if (!screenshotUrl) {
        return msg.reply('❧ Não foi possível capturar o screenshot. Tente novamente.');
      }

      await sock.sendMessage(msg.chat, {
        image: { url: screenshotUrl },
        caption: `📸 *Screenshot*\n\n▸ Site: *${url}*\n▸ Resolução: 1280x800\n\n💡 Use *${usedPrefix + command}* para capturar mais sites!`
      }, { quoted: msg });
      await msg.react('✅');
    } catch (e) {
      await msg.reply(`> Erro: *${e.message}*`);
    }
  },
};
