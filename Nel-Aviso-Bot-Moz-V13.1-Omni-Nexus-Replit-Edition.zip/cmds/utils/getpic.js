export default {
  command: ['pfp', 'getpic'],
  category: 'utilidades',
  description: 'Ver a foto de perfil de um utilizador.',
  run: async ({ msg, sock, usedPrefix, command, text }) => {
    const who = msg.mentionedJid?.[0] || msg.quoted?.sender || null;
    if (!who) {
      return msg.reply(`《✧》 Etiqueta o menciona ao usuário del que quieras ver su foto de perfil.`);
    }
    try {
      const img = await sock.profilePictureUrl(who, 'image').catch(() => null);
      if (!img) {
        return sock.sendMessage(msg.chat, { text: `《✧》 Não foi possível obter a foto de perfil de @${who.split('@')[0]}.`, mentions: [who] }, { quoted: msg });
      }
      await sock.sendMessage(msg.chat, { image: { url: img }, caption: null }, { quoted: msg });
    } catch (e) {
      await msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  },
};