export default {
  command: ['contar', 'contador', 'charcount', 'contagem'],
  category: 'utilidades',
  description: 'Contar caracteres, palavras e linhas de um texto 🔢',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    if (!text) return await sock.sendMessage(msg.key.remoteJid, { text: `✳️ Use: ${usedPrefix}${command} <texto>\n\nExemplo: ${usedPrefix}${command} Olá mundo deste bot incrível` }, { quoted: msg });

    const chars = text.length;
    const charsNoSpace = text.replace(/\s/g, '').length;
    const words = text.trim().split(/\s+/).filter(w => w.length > 0).length;
    const lines = text.split('\n').length;
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0).length;
    const paragraphs = text.split(/\n\n+/).filter(p => p.trim().length > 0).length;

    let result = `📊 *CONTAGEM DE TEXTO*\n\n`;
    result += `📝 Caracteres: *${chars}*\n`;
    result += `📝 Caracteres (sem espaços): *${charsNoSpace}*\n`;
    result += `📖 Palavras: *${words}*\n`;
    result += `📄 Linhas: *${lines}*\n`;
    result += `📙 Frases: *${sentences}*\n`;
    result += `📑 Parágrafos: *${paragraphs}*\n\n`;
    result += `⏱️ Tempo de leitura: ~*${Math.ceil(words / 200)}* min\n`;
    result += `🗣️ Tempo de fala: ~*${Math.ceil(words / 130)}* min`;

    await sock.sendMessage(msg.key.remoteJid, { text: result }, { quoted: msg });
  }
};
