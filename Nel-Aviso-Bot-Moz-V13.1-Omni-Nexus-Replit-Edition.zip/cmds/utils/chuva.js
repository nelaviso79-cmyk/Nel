export default {
  command: ['chorar', 'parar', 'rain', 'pararDeChover'],
  category: 'diversao',
  description: 'Simular chuva com arte ASCII 🌧️',
  run: async ({ msg, sock, usedPrefix, command, text }) => {
    const chuvas = [
      '🌧️  .  .  .  ☁️  .  .  .  🌧️\n   .  .  .  .  .  .  .\n  .  .  🌧️  .  .  .  .\n ☁️  .  .  .  .  ☁️  .\n   .  .  .  🌧️  .  .  .',
      '⛈️  .  ⚡  .  .  ⚡  .  ⛈️\n  .  🌧️  .  .  .  🌧️  .\n 🌧️  .  .  ☁️  .  .  🌧️\n  .  .  🌧️  .  🌧️  .  .\n ☁️  .  .  .  .  .  ☁️',
      '🌈 ... está a chover!\n\n🌧️🌧️🌧️🌧️🌧️🌧️🌧️\n💧💧💧💧💧💧💧💧\n💦💦💦💦💦💦💦💦\n💧💧💧💧💧💧💧💧\n🌧️🌧️🌧️🌧️🌧️🌧️🌧️\n\n⛈️ Chove em Maputo! ⛈️',
      '🌦️ Sol e chuva em Moçambique!\n\n  🌤️  .  🌧️  .  🌤️\n   .  ☀️  .  🌧️  .\n  🌧️  .  ☁️  .  🌧️\n   .  .  🌈  .  .\n\n ☀️ A chuva passou! 🌈',
    ];

    const chuva = chuvas[Math.floor(Math.random() * chuvas.length)];

    const responses = [
      '🌧️ *CHOVENDO!* A chuva cai forte!\n\n' + chuva,
      '⛈️ *TEMPORAL!* Trovoada e chuva!\n\n' + chuva,
      '🌦️ *GAROA!* Chuva leve e sol!\n\n' + chuva,
    ];

    const response = responses[Math.floor(Math.random() * responses.length)];

    await sock.sendMessage(msg.key.remoteJid, { text: response + '\n\n🔄 *' + usedPrefix + command + '* para mais chuva!' }, { quoted: msg });
  }
};
