export default {
  command: ['lembrete', 'remind', 'lembrar', 'alerta'],
  category: 'utilidades',
  description: 'Definir um lembrete - o bot vai te lembrar! ⏰',
  run: async ({ msg, sock, args, usedPrefix, command, text, sender }) => {
    if (!text || !text.includes('|')) {
      return msg.reply(
        `⏰ *LEMBRETE* ⏰\n\n` +
        `◈ Defina um lembrete e eu te aviso!\n\n` +
        `✎ Formato: *${usedPrefix + command} tempo|mensagem*\n\n` +
        `✎ Exemplos:\n` +
        `▸ *${usedPrefix + command} 5m|Tomar água*\n` +
        `▸ *${usedPrefix + command} 30m|Reunião*\n` +
        `▸ *${usedPrefix + command} 1h|Almoço*\n` +
        `▸ *${usedPrefix + command} 2h|Ligar para mãe*\n\n` +
        `◈ Tempos: s=segundos, m=minutos, h=horas`
      );
    }

    const [tempo, ...msgParts] = text.split('|');
    const lembreteMsg = msgParts.join('|').trim();
    
    if (!lembreteMsg) return msg.reply('◈ Escrevai mensagem do lembrete!');
    
    // Parse tempo
    const match = tempo.trim().match(/^(\d+)(s|m|h)$/i);
    if (!match) return msg.reply('◈ Tempo inválido! Use: número + s/m/h (ex: 5m, 1h, 30s)');

    const num = parseInt(match[1]);
    const unit = match[2].toLowerCase();
    
    let ms;
    switch (unit) {
      case 's': ms = num * 1000; break;
      case 'm': ms = num * 60 * 1000; break;
      case 'h': ms = num * 3600 * 1000; break;
      default: return msg.reply('◈ Unidade inválida!');
    }

    if (ms < 5000) return msg.reply('◈ Tempo mínimo: 5 segundos');
    if (ms > 86400000) return msg.reply('◈ Tempo máximo: 24 horas');

    const unitNames = { s: 'segundo(s)', m: 'minuto(s)', h: 'hora(s)' };
    
    await msg.reply(
      `⏰ *LEMBRETE DEFINIDO* ⏰\n\n` +
      `▸ Mensagem: _${lembreteMsg}_\n` +
      `▸ Tempo: *${num} ${unitNames[unit]}*\n` +
      `▸ Para: @${sender.split('@')[0]}\n\n` +
      `◈ Eu vou te lembrar! ⏰`
    , { mentions: [sender] });

    // Definir timeout
    setTimeout(async () => {
      try {
        await sock.sendMessage(msg.chat, {
          text: `⏰ *LEMBRETE!* ⏰\n\n▸ @${sender.split('@')[0]}, lembrete:\n\n💬 _${lembreteMsg}_\n\n_Nel-Aviso-Bot-Moz_ 🇲🇿`,
          mentions: [sender]
        });
      } catch (e) {
        console.error('Erro ao enviar lembrete:', e);
      }
    }, ms);
  }
};
