import { downloadContentFromMessage, extractMessageContent } from 'baileys';

export default {
  command: ['readviewonce', 'read', 'readvo'],
  category: 'utilidades',
  description: 'Converter imagem/vídeo de visualização única em conteúdo.',
  run: async ({ msg, sock, usedPrefix, command }) => {
    const quoted = msg.quoted;
    if (!quoted) {
      return msg.reply('《✧》 Por favor, responde a uma mensagem "ViewOnce" para ver su conteúdo.');
    }
    try {
      await msg.react('🕒');
      const content = extractMessageContent(quoted.message || quoted);
      if (!content) {
        return msg.reply('《✧》 Não foi possível extraer el conteúdo.');
      }
      const messageType = Object.keys(content)[0];
      const mediaMessage = content[messageType];
      const stream = await downloadContentFromMessage(mediaMessage, messageType.replace('Message', '').toLowerCase());
      if (!stream) {
        return msg.reply('《✧》 Não foi possível baixar el conteúdo.');
      }
      let buffer = Buffer.from([]);
      for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
      }
      if (/video/i.test(messageType)) {
        await sock.sendMessage(msg.chat, { video: buffer, caption: mediaMessage.caption || '', mimetype: 'video/mp4' }, { quoted: msg });
      } else if (/image/i.test(messageType)) {
        await sock.sendMessage(msg.chat, { image: buffer, caption: mediaMessage.caption || '' }, { quoted: msg });
      } else if (/audio/i.test(messageType)) {
        await sock.sendMessage(msg.chat, { audio: buffer, mimetype: 'audio/ogg; codecs=opus', ptt: mediaMessage.ptt || false }, { quoted: msg });
      }      
      await msg.react('✔️');
    } catch (e) {
      await msg.react('✖️');
      await msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  }
};