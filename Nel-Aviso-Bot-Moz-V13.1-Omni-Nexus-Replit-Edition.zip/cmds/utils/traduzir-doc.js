export default {
  command: ['traduzir-doc', 'traddoc'],
  category: 'utilidades',
  description: 'Tradução de ficheiros de texto inteiros 📄',
  run: async ({ msg, sock, usedPrefix, command, args }) => {
    if (!msg.quoted || !msg.quoted.message?.documentMessage) {
      return msg.reply(`⚠️ Responda a um *ficheiro de texto (.txt)* com:\n*${usedPrefix + command} [idioma]*\n\nEx: *${usedPrefix + command} en*`);
    }

    const targetLang = args[0] || 'pt';
    await msg.react('📄');

    try {
      const buffer = await sock.downloadMediaMessage(msg.quoted);
      const text = buffer.toString('utf-8');
      
      if (text.length > 5000) return msg.reply(`❌ Ficheiro muito grande! O limite é de 5000 caracteres para tradução direta.`);

      await msg.reply(`⏳ Traduzindo documento para *${targetLang.toUpperCase()}*...`);

      const url = `https://api.translate.google.com/translate_a/single?client=gtx&sl=auto&tl=${targetLang}&dt=t&q=${encodeURIComponent(text)}`;
      const response = await fetch(url);
      const data = await response.json();

      let traducao = '';
      for (const part of data[0]) { if (part[0]) traducao += part[0]; }

      const fileName = `traduzido_${targetLang}_${msg.quoted.message.documentMessage.fileName || 'doc.txt'}`;
      
      await sock.sendMessage(msg.chat, {
        document: Buffer.from(traducao),
        fileName: fileName,
        mimetype: 'text/plain',
        caption: `✅ *Documento Traduzido*\n▸ Idioma: *${targetLang.toUpperCase()}*\n\n_Nexus Utility Engine_ ⚙️`
      }, { quoted: msg });

      await msg.react('✅');
    } catch (e) {
      console.error(e);
      await msg.react('❌');
      return msg.reply(`❌ Erro ao traduzir documento.`);
    }
  }
};
