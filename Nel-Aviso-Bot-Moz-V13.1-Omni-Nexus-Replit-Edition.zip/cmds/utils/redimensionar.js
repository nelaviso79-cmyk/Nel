import fs from 'fs';
import { spawn } from 'child_process';
import path from 'path';

export default {
  command: ['rediz-mensionar', 'resize', 'tamanho', 'diz-mensao'],
  category: 'utilidades',
  description: 'Rediz-mensionar uma imagem para o tamanho desejado 🖼️',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    const quoted = msg.quoted || msg;
    const mime = (quoted.msg || quoted).mimetype || '';
    
    if (!/image/.test(mime)) {
      return msg.reply(`◈ Responda a uma *imagem* com o tamanho desejado.\n\n✎ Exemplo: *${usedPrefix + command} 512x512*\n✎ Ou: *${usedPrefix + command} 50%*`);
    }
    
    if (!text) {
      return msg.reply(`◈ Especifique o tamanho!\n\n✎ Exemplo: *${usedPrefix + command} 512x512*\n✎ Ou: *${usedPrefix + command} 50%* (porcentagem)`);
    }
    
    await msg.react('⏳');
    
    try {
      const buffer = await quoted.download();
      const inputPath = `./tmp/resize_in_${Date.now()}.jpg`;
      const outputPath = `./tmp/resize_out_${Date.now()}.jpg`;
      fs.writeFileSync(inputPath, buffer);
      
      let ffmpegArgs;
      if (text.includes('%')) {
        const pct = parseInt(text);
        if (isNaN(pct) || pct < 1 || pct > 500) return msg.reply('◈ Porcentagem inválida (1-500%)');
        ffmpegArgs = ['-y', '-i', inputPath, '-vf', `scale=iw*${pct/100}:ih*${pct/100}`, outputPath];
      } else if (text.includes('x') || text.includes('X')) {
        const [w, h] = text.toLowerCase().split('x').map(Number);
        if (!w || !h || isNaN(w) || isNaN(h)) return msg.reply('◈ Diz-mensões inválidas. Use: LARGURAxALTURA');
        ffmpegArgs = ['-y', '-i', inputPath, '-vf', `scale=${w}:${h}`, outputPath];
      } else {
        const size = parseInt(text);
        if (isNaN(size)) return msg.reply('◈ Tamanho inválido. Use: LARGURAxALTURA ou porcentagem%');
        ffmpegArgs = ['-y', '-i', inputPath, '-vf', `scale=${size}:${size}:force_original_aspect_ratio=decrease,pad=${size}:${size}:(ow-iw)/2:(oh-ih)/2:color=white`, outputPath];
      }
      
      await new Promise((resolve, reject) => {
        const proc = spawn('ffmpeg', ffmpegArgs);
        let err = '';
        proc.stderr.on('data', d => err += d.toString());
        proc.on('close', code => code === 0 ? resolve() : reject(new Error(err)));
      });
      
      const result = fs.readFileSync(outputPath);
      fs.unlinkSync(inputPath);
      fs.unlinkSync(outputPath);
      
      await sock.sendMessage(msg.chat, { image: result, caption: '◈ Imagem rediz-mensionada com sucesso! ✅' }, { quoted: msg });
      await msg.react('✅');
    } catch (e) {
      await msg.react('❌');
      return msg.reply(`◈ Erro ao rediz-mensionar: ${e.message}`);
    }
  }
};
