import db from '#db';

export default {
  command: ['agenda', 'notas', 'nota', 'anotar'],
  category: 'utilidades',
  description: 'Sistema de notas e compromissos pessoal 📝',
  run: async ({ msg, sock, args, usedPrefix, command, sender }) => {
    const user = db.getUser(sender);
    let agenda = user.metadatos2 ? (typeof user.metadatos2 === 'string' ? JSON.parse(user.metadatos2) : user.metadatos2) : {};
    if (!agenda.notas) agenda.notas = [];

    if (!args.length) {
      let text = `📝 *MINHA AGENDA NEXUS* 📝\n\n`;
      if (agenda.notas.length === 0) {
        text += `> Nenhuma nota guardada.\n`;
      } else {
        agenda.notas.forEach((nota, i) => {
          text += `*${i + 1}.* ${nota.texto} _(${nota.data})_\n`;
        });
      }
      text += `\n*Comandos:*\n`;
      text += `▸ *${usedPrefix + command} add <texto>* - Adicionar nota\n`;
      text += `▸ *${usedPrefix + command} del <número>* - Apagar nota\n`;
      text += `▸ *${usedPrefix + command} clear* - Limpar tudo`;
      return msg.reply(text);
    }

    const action = args[0].toLowerCase();
    const content = args.slice(1).join(' ');

    if (action === 'add' || action === 'adicionar') {
      if (!content) return msg.reply(`❌ Digite o que deseja anotar!`);
      const novaNota = {
        texto: content,
        data: new Date().toLocaleString('pt-MZ')
      };
      agenda.notas.push(novaNota);
      db.setUser(sender, 'metadatos2', JSON.stringify(agenda));
      return msg.reply(`✅ Nota guardada com sucesso!`);
    }

    if (action === 'del' || action === 'apagar' || action === 'remover') {
      const index = parseInt(content) - 1;
      if (isNaN(index) || !agenda.notas[index]) return msg.reply(`❌ Número de nota inválido!`);
      agenda.notas.splice(index, 1);
      db.setUser(sender, 'metadatos2', JSON.stringify(agenda));
      return msg.reply(`✅ Nota removida!`);
    }

    if (action === 'clear' || action === 'limpar') {
      agenda.notas = [];
      db.setUser(sender, 'metadatos2', JSON.stringify(agenda));
      return msg.reply(`✅ Agenda limpa com sucesso!`);
    }

    return msg.reply(`❌ Comando desconhecido. Use *${usedPrefix + command}* para ajuda.`);
  }
};
