import fetch from 'node-fetch';

export default {
  command: ['crypto', 'bitcoin', 'criptomoeda', 'btc', 'eth'],
  category: 'utilidades',
  description: 'Cotação de criptomoedas em tempo real 💰',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const coin = args[0]?.toLowerCase() || 'bitcoin';
    
    try {
      await msg.react('💰');
      let cryptoData = null;

      // Método 1: CoinGecko (gratuito)
      try {
        const res = await fetch(`https://api.coingecko.com/api/v3/coins/${coin}?localization=false&tickers=false&community_data=false&developer_data=false`);
        if (res.ok) {
          const json = await res.json();
          if (json?.id) {
            cryptoData = {
              name: json.name,
              symbol: json.symbol?.toUpperCase(),
              rank: json.market_cap_rank || 'N/A',
              price_usd: json.market_data?.current_price?.usd?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 6 }) || 'N/A',
              price_eur: json.market_data?.current_price?.eur?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 6 }) || 'N/A',
              price_brl: json.market_data?.current_price?.brl?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 6 }) || 'N/A',
              price_mzn: json.market_data?.current_price?.mzn?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 6 }) || null,
              change_24h: json.market_data?.price_change_percentage_24h?.toFixed(2) || 'N/A',
              change_7d: json.market_data?.price_change_percentage_7d?.toFixed(2) || 'N/A',
              market_cap: json.market_data?.market_cap?.usd ? formatLargeNumber(json.market_data.market_cap.usd) : 'N/A',
              volume_24h: json.market_data?.total_volume?.usd ? formatLargeNumber(json.market_data.total_volume.usd) : 'N/A',
              high_24h: json.market_data?.high_24h?.usd?.toLocaleString('en-US') || 'N/A',
              low_24h: json.market_data?.low_24h?.usd?.toLocaleString('en-US') || 'N/A',
              ath: json.market_data?.ath?.usd?.toLocaleString('en-US') || 'N/A',
              ath_date: json.market_data?.ath_date?.usd ? new Date(json.market_data.ath_date.usd).toLocaleDateString('pt-MZ') : 'N/A',
              circulating_supply: json.market_data?.circulating_supply ? formatLargeNumber(json.market_data.circulating_supply) : 'N/A',
              image: json.image?.small || json.image?.thumb || null
            };
          }
        }
      } catch {}

      // Método 2: Lista de criptomoedas se a primeira falhar
      if (!cryptoData) {
        try {
          const res = await fetch(`https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=${coin}&order=market_cap_desc`);
          const json = await res.json();
          if (Array.isArray(json) && json.length > 0) {
            const c = json[0];
            cryptoData = {
              name: c.name,
              symbol: c.symbol?.toUpperCase(),
              rank: c.market_cap_rank || 'N/A',
              price_usd: c.current_price?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 6 }) || 'N/A',
              change_24h: c.price_change_percentage_24h?.toFixed(2) || 'N/A',
              market_cap: c.market_cap ? formatLargeNumber(c.market_cap) : 'N/A',
              volume_24h: c.total_volume ? formatLargeNumber(c.total_volume) : 'N/A',
              high_24h: c.high_24h?.toLocaleString('en-US') || 'N/A',
              low_24h: c.low_24h?.toLocaleString('en-US') || 'N/A',
              ath: c.ath?.toLocaleString('en-US') || 'N/A',
              image: c.image || null
            };
          }
        } catch {}
      }

      if (!cryptoData) {
        return msg.reply(
          `❧ Criptomoeda *${coin}* não encontrada.\n\n` +
          `💡 *Moedas populares:*\n` +
          `▸ *bitcoin* (btc)\n▸ *ethereum* (eth)\n▸ *solana* (sol)\n` +
          `▸ *cardano* (ada)\n▸ *dogecoin* (doge)\n▸ *ripple* (xrp)\n\n` +
          `▸ Use o ID da moeda: *${usedPrefix + command} ethereum*`
        );
      }

      const changeEmoji = parseFloat(cryptoData.change_24h) >= 0 ? '📈' : '📉';
      const change7dEmoji = cryptoData.change_7d ? (parseFloat(cryptoData.change_7d) >= 0 ? '📈' : '📉') : '';

      const result = `
💰 *${cryptoData.name} (${cryptoData.symbol})* 💰

📊 *Preço:*
▸ USD: *$${cryptoData.price_usd}*
${cryptoData.price_eur ? `▸ EUR: *€${cryptoData.price_eur}*\n` : ''}${cryptoData.price_brl ? `▸ BRL: *R$${cryptoData.price_brl}*\n` : ''}${cryptoData.price_mzn ? `▸ MZN: *MT${cryptoData.price_mzn}*\n` : ''}
📈 *Variação:*
▸ 24h: ${changeEmoji} *${cryptoData.change_24h}%*
${cryptoData.change_7d ? `▸ 7d: ${change7dEmoji} *${cryptoData.change_7d}%*\n` : ''}
📋 *Mercado:*
▸ Ranking: *#${cryptoData.rank}*
▸ Capitalização: *$${cryptoData.market_cap}*
▸ Volume 24h: *$${cryptoData.volume_24h}*
▸ Máxima 24h: *$${cryptoData.high_24h}*
▸ Mínima 24h: *$${cryptoData.low_24h}*
▸ ATH: *$${cryptoData.ath}*${cryptoData.ath_date ? ` (${cryptoData.ath_date})` : ''}
${cryptoData.circulating_supply ? `▸ Fornecimento: *${cryptoData.circulating_supply}*\n` : ''}
⏰ *Atualizado em tempo real*
`.trim();

      await msg.reply(result);
    } catch (e) {
      await msg.reply(`> Erro: *${e.message}*`);
    }
  },
};

function formatLargeNumber(num) {
  if (!num) return 'N/A';
  const n = Number(num);
  if (n >= 1e12) return `${(n / 1e12).toFixed(2)}T`;
  if (n >= 1e9) return `${(n / 1e9).toFixed(2)}B`;
  if (n >= 1e6) return `${(n / 1e6).toFixed(2)}M`;
  if (n >= 1e3) return `${(n / 1e3).toFixed(2)}K`;
  return n.toLocaleString('en-US');
}
