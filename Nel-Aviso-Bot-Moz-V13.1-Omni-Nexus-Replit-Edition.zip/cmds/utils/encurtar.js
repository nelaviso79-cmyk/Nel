/**
 * 🔗 ENCURTAR — Encurtador de URLs
 */
import fetch from 'node-fetch';

export default {
  command: ['encurtar', 'short', 'shorturl', 'tinyurl', 'urlcurta'],
  category: 'utilidades',
  description: 'Encurtar URLs longas 🔗',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const url = args[0];
    if (!url || !url.match(/^https?:\/\//)) {
      return msg.reply(`❌ Use: *${usedPrefix}${command} <URL>*\nEx: *${usedPrefix}short https://exemplo.com/pagina/muito/longa*`);
    }

    try {
      let short = null;

      // API 1: tinyurl
      try {
        const res = await fetch(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(url)}`);
        const text = await res.text();
        if (text.startsWith('http')) short = text;
      } catch {}

      // API 2: is.gd
      if (!short) {
        try {
          const res = await fetch(`https://is.gd/create.php?format=simple&url=${encodeURIComponent(url)}`);
          const text = await res.text();
          if (text.startsWith('http')) short = text;
        } catch {}
      }

      // API 3: vgd
      if (!short) {
        try {
          const res = await fetch(`https://v.gd/create.php?format=simple&url=${encodeURIComponent(url)}`);
          const text = await res.text();
          if (text.startsWith('http')) short = text;
        } catch {}
      }

      if (short) {
        msg.reply(`🔗 *URL Encurtada*\n\n📎 Original: ${url.substring(0, 60)}${url.length > 60 ? '...' : ''}\n✅ Curta: ${short}`);
      } else {
        msg.reply(`❌ Não foi possível encurtar a URL. Tente novamente.`);
      }
    } catch (e) {
      msg.reply(`❌ Erro ao encurtar URL.`);
    }
  }
};
