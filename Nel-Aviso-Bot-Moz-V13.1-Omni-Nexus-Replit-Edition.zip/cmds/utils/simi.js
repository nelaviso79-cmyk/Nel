// ╔══════════════════════════════════════════════════════════════╗
//   NEL-AVISO-BOT-MOZ · cmds/utils/simi.js
//   SimSimi — AI chatbot com respostas engraçadas/simuladas
// ╚══════════════════════════════════════════════════════════════╝

export const command = {
  name: 'simi',
  aliases: ['sim', 'simsimi', 'simchat', 'botchat'],
  description: 'Conversa com o SimSimi — respostas engraçadas e provocantes',
  category: 'ia',
  usage: '.simi <mensagem>',
  example: '.simi Olá como estás?'

};

export default async function ({ sock, msg, args, from, sender, config }) {
  const text = args.join(' ').trim();
  if (!text) {
    return sock.sendMessage(from, {
      text: '❌ Escreve algo para o SimSimi responder!\n\n💡 *Uso:* .simi <mensagem>\n📌 *Ex:* .simi Olá como estás?'
    }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '🤖', key: msg.key } });

  try {
    // Delirius SimSimi API
    const res = await fetch(`https://api.delirius.store/ia/simismi?text=${encodeURIComponent(text)}`);
    const data = await res.json();

    if (data?.status === 200 && data?.result) {
      const response = data.result;
      await sock.sendMessage(from, {
        text: `🤖 *SimSimi:*\n\n${response}`,
        contextInfo: {
          externalAdReply: {
            title: 'SimSimi AI',
            body: 'Conversa engraçada',
            thumbnailUrl: 'https://cdn-icons-png.flaticon.com/512/4733/4733089.png',
            mediaType: 1
          }
        }
      }, { quoted: msg });
      return;
    }
  } catch (e) {
    console.log('SimSimi primary failed:', e.message);
  }

  try {
    // Fallback — usar chatgpt com prompt SimSimi
    const res = await fetch(`https://api.delirius.store/ia/chatgpt?prompt=${encodeURIComponent('Responde como se fosses o SimSimi, um bot de chat engraçado, provocante e às vezes mal-educado. Responde de forma curta, engraçada e em português. Mensagem do utilizador: ' + text)}`);
    const data = await res.json();

    if (data?.status === 200 && data?.result) {
      await sock.sendMessage(from, {
        text: `🤖 *SimSimi:*\n\n${data.result}`,
        contextInfo: {
          externalAdReply: {
            title: 'SimSimi AI',
            body: 'Conversa engraçada',
            thumbnailUrl: 'https://cdn-icons-png.flaticon.com/512/4733/4733089.png',
            mediaType: 1
          }
        }
      }, { quoted: msg });
      return;
    }
  } catch (e) {
    console.log('SimSimi fallback failed:', e.message);
  }

  // Resposta offline se tudo falhar
  const respostas = [
    'Hmm, não sei o que dizer 😅',
    'Haha, isso foi engraçado! 🤣',
    'Tu és mesmo estranho 😂',
    'Ah é? Pois pois... 🙄',
    'Não entendi nada! 💀',
    'Sai daí com isso! 😤',
    'OLÁ! Eu sou o SimSimi e tu és chato 😜',
    'Talvez... quem sabe? 🤷',
    'Isso é segredo! 🤫',
    'Vai perguntar à tua avó! 👵😂'
  ];
  const random = respostas[Math.floor(Math.random() * respostas.length)];
  await sock.sendMessage(from, {
    text: `🤖 *SimSimi:*\n\n${random}\n\n_⚠️ Modo offline — API indisponível_`
  }, { quoted: msg });
}
