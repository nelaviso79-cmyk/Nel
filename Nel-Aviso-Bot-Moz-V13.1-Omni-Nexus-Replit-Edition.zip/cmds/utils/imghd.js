// ╔══════════════════════════════════════════════════════════╗
//   NEL-AVISO-BOT-MOZ · cmds/utils/imghd.js
// ╚══════════════════════════════════════════════════════════╝

import fetch from 'node-fetch';
import fs from 'fs';
import path from 'path';

export default {
  command: ['imghd', 'upscale', 'melhorarimg', 'upimg', 'hdimg'],
  category: 'utilidades',
  description: 'Melhorar/upscale imagem com IA (2x-4x resolução) 🔬',

  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const q = msg.quoted;
    const scale = args[0] || '2';

    // Validate scale
    const validScale = ['2', '3', '4'].includes(scale) ? scale : '2';

    // Check for quoted image
    if (!q || (!q.message?.imageMessage && !q.message?.viewOnceMessageV2Extension)) {
      return msg.reply(
        `🔬 *UPSCALE DE IMAGEM COM IA* 🔬\n\n` +
        `Melhore a qualidade/resolução de qualquer imagem!\n\n` +
        `📋 Como usar:\n` +
        `1️⃣ Responda a uma imagem\n` +
        `2️⃣ *${usedPrefix}${command} 2* (2x)\n` +
        `3️⃣ *${usedPrefix}${command} 4* (4x máx)\n\n` +
        `🔬 Escalas: *2x*, *3x*, *4x*\n` +
        `> Quanto maior a escala, maior o resultado!`
      );
    }

    if (!q.message?.imageMessage) {
      return msg.reply(`❌ Responda a uma *imagem* para melhorar!`);
    }

    await msg.reply(`⏳ A melhorar imagem com IA (*${validScale}x*)...\n> Isso pode demorar alguns segundos.`);

    try {
      // Download the image
      const media = await sock.downloadMediaMessage(q);
      if (!media) throw new Error('Falha ao baixar imagem');

      // Save temporarily
      const tmpPath = path.join(process.cwd(), 'tmp', `upscale_${Date.now()}.jpg`);
      const tmpDir = path.dirname(tmpPath);
      if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });
      fs.writeFileSync(tmpPath, media);

      // Upload to imgbb for URL
      const ibbRes = await fetch(`https://api.delirius.store/tools/ibb?image=${encodeURIComponent(tmpPath)}&filename=upscale_${Date.now()}`);
      let imgUrl = null;

      if (ibbRes.ok) {
        const ibbData = await ibbRes.json();
        if (ibbData.status && ibbData.result) {
          imgUrl = ibbData.result.url || ibbData.result.display_url || ibbData.result.image?.url;
        }
      }

      // If imgbb failed, try catbox
      if (!imgUrl) {
        try {
          const form = new FormData();
          const blob = new Blob([media]);
          form.append('reqtype', 'fileupload');
          form.append('fileToUpload', blob, 'image.jpg');
          const catRes = await fetch('https://catbox.moe/user/api.php', { method: 'POST', body: form });
          if (catRes.ok) imgUrl = await catRes.text();
        } catch (e) { /* ignore */ }
      }

      // Clean up temp file
      try { fs.unlinkSync(tmpPath); } catch (e) { /* ignore */ }

      if (!imgUrl) throw new Error('Falha ao hospedar imagem');

      // Primary: Delirius Upscale API
      const upscaleRes = await fetch(
        `https://api.delirius.store/ia/upscale?image=${encodeURIComponent(imgUrl)}`
      );

      if (upscaleRes.ok) {
        const contentType = upscaleRes.headers.get('content-type') || '';
        if (contentType.includes('image')) {
          const buffer = Buffer.from(await upscaleRes.arrayBuffer());
          await sock.sendMessage(msg.chat, {
            image: buffer,
            caption: `🔬 *Imagem melhorada com IA* ✅\n🔬 Escala: *${validScale}x*\n📐 Resolução aumentada automaticamente`
          }, { quoted: msg });
          return;
        }

        // If it returned JSON
        const data = await upscaleRes.json();
        if (data.status && data.result) {
          const resultUrl = data.result.url || data.result.image || data.result;
          await sock.sendMessage(msg.chat, {
            image: { url: resultUrl },
            caption: `🔬 *Imagem melhorada com IA* ✅\n🔬 Escala: *${validScale}x*`
          }, { quoted: msg });
          return;
        }
      }

      // Fallback: Delirius Enhance API
      const enhanceRes = await fetch(
        `https://api.delirius.store/ia/enhance?image=${encodeURIComponent(imgUrl)}&scale=${validScale}`
      );

      if (enhanceRes.ok) {
        const contentType2 = enhanceRes.headers.get('content-type') || '';
        if (contentType2.includes('image')) {
          const buffer2 = Buffer.from(await enhanceRes.arrayBuffer());
          await sock.sendMessage(msg.chat, {
            image: buffer2,
            caption: `🔬 *Imagem melhorada* ✅\n🔬 Escala: *${validScale}x*`
          }, { quoted: msg });
          return;
        }

        const data2 = await enhanceRes.json();
        if (data2.status && data2.result) {
          const resultUrl2 = data2.result.url || data2.result.image || data2.result;
          await sock.sendMessage(msg.chat, {
            image: { url: resultUrl2 },
            caption: `🔬 *Imagem melhorada* ✅\n🔬 Escala: *${validScale}x*`
          }, { quoted: msg });
          return;
        }
      }

      await msg.reply(`❌ Não foi possível melhorar a imagem. Tente novamente.`);

    } catch (e) {
      await msg.reply(`❌ Erro ao melhorar imagem: *${e.message}*`);
    }
  }
};
