export default {
  command: ['horoscopo', 'signo', 'zodiaco'],
  category: 'diversao',
  description: 'Ver o horóscopo do dia do teu signo.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const signos = {
      'aries': '♈ Áries (21 Mar - 19 Abr)', 'touro': '♉ Touro (20 Abr - 20 Mai)',
      'gemeos': '♊ Gémeos (21 Mai - 20 Jun)', 'cancer': '♋ Câncer (21 Jun - 22 Jul)',
      'leao': '♌ Leão (23 Jul - 22 Ago)', 'virgem': '♍ Virgem (23 Ago - 22 Set)',
      'libra': '♎ Libra (23 Set - 22 Out)', 'escorpiao': '♏ Escorpião (23 Out - 21 Nov)',
      'sagitario': '♐ Sagitário (22 Nov - 21 Dez)', 'capricornio': '♑ Capricórnio (22 Dez - 19 Jan)',
      'aquario': '♒ Aquário (20 Jan - 18 Fev)', 'peixes': '♓ Peixes (19 Fev - 20 Mar)',
      'aries': '♈ Áries', 'touro': '♉ Touro', 'leao': '♌ Leão',
    };

    if (!args.length) {
      return msg.reply(
        `❧ *Horóscopo do Dia* ✨\n\n` +
        `✎ Usa o comando com o teu signo:\n` +
        `> *${usedPrefix + command} aries*\n` +
        `> *${usedPrefix + command} leao*\n\n` +
        `▸ Signos: áries, touro, gémeos, câncer, leão, virgem, libra, escorpião, sagitário, capricórnio, aquário, peixes`
      );
    }

    const signo = args[0].toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    const signoMap = {
      'aries': 'aries', 'touro': 'touro', 'gemeos': 'gemeos', 'cancer': 'cancer',
      'leao': 'leao', 'virgem': 'virgem', 'libra': 'libra', 'escorpiao': 'escorpiao',
      'sagitario': 'sagitario', 'capricornio': 'capricornio', 'aquario': 'aquario', 'peixes': 'peixes'
    };

    if (!signoMap[signo]) {
      return msg.reply(`❧ Signo inválido! Usa um dos 12 signos do zodíaco.\n✎ Exemplo: *${usedPrefix + command} leao*`);
    }

    const previsoes = [
      'Hoje é um dia de grandes oportunidades. Não hesites em agir!',
      'O amor está no ar. Mantém o coração aberto para surpresas.',
      'Um velho amigo pode reaparecer na tua vida hoje.',
      'Confia na tua intuição. Ela guiar-te-á na direcção certa.',
      'Dia favorável para finanças. Uma boa oportunidade pode surgir.',
      'Tira tempo para descansar. O autocuidado é essencial hoje.',
      'Uma conversa importante pode mudar a tua perspectiva.',
      'A criatividade está em alta. Exprime-te sem medo!',
      'Paciência é a chave hoje. Não apresses as coisas.',
      'Surpresas positivas estão a caminho. Sorri mais!',
      'Dia ideal para aprender algo novo. O conhecimento abre portas.',
      'Relações familiares precisam de atenção. Liga para quem amas.',
      'Uma decisão difícil pode ser necessária. Confia em ti.',
      'A sorte está do teu lado hoje. Aproveita o momento!',
      'Evita conflitos desnecessários. A paz interior é valiosa.',
      'Um projecto antigo pode finalmente avançar hoje.',
      'A energia está alta. Usa-a para algo produtivo!',
      'Mudanças estão chegando. Aceita-as com positividade.',
      'Dia de reflexão. Pensa nos teus objectivos a longo prazo.',
      'Uma mensagem importante pode chegar hoje. Fica atento!',
    ];

    const previsao = previsoes[Math.floor(Math.random() * previsoes.length)];
    const emojis = { 'aries': '♈', 'touro': '♉', 'gemeos': '♊', 'cancer': '♋', 'leao': '♌', 'virgem': '♍', 'libra': '♎', 'escorpiao': '♏', 'sagitario': '♐', 'capricornio': '♑', 'aquario': '♒', 'peixes': '♓' };
    const signoNome = { 'aries': 'Áries', 'touro': 'Touro', 'gemeos': 'Gémeos', 'cancer': 'Câncer', 'leao': 'Leão', 'virgem': 'Virgem', 'libra': 'Libra', 'escorpiao': 'Escorpião', 'sagitario': 'Sagitário', 'capricornio': 'Capricórnio', 'aquario': 'Aquário', 'peixes': 'Peixes' };

    const key = signoMap[signo];
    const sorte = Math.floor(Math.random() * 10) + 1;
    const amor = Math.floor(Math.random() * 10) + 1;
    const saude = Math.floor(Math.random() * 10) + 1;
    const dinheiro = Math.floor(Math.random() * 10) + 1;

    return msg.reply(
      `❧ *Horóscopo do Dia* ✨\n\n` +
      `${emojis[key]} *${signoNome[key]}*\n\n` +
      `▸ Previsão: ${previsao}\n\n` +
      `💰 Dinheiro: ${'⭐'.repeat(dinheiro)}${'☆'.repeat(10-dinheiro)} ${dinheiro}/10\n` +
      `❤️ Amor: ${'⭐'.repeat(amor)}${'☆'.repeat(10-amor)} ${amor}/10\n` +
      `🏥 Saúde: ${'⭐'.repeat(saude)}${'☆'.repeat(10-saude)} ${saude}/10\n` +
      `🍀 Sorte: ${'⭐'.repeat(sorte)}${'☆'.repeat(10-sorte)} ${sorte}/10`
    );
  },
};
