import fetch from 'node-fetch';
import uploadImage from '#uploadImage';

export default {
  command: ['ocr', 'extrairtexto', 'lerimagem'],
  category: 'utilidades',
  description: 'Lê e extrai todo o texto contido numa imagem.',
  run: async ({ msg, sock, usedPrefix, command }) => {
    const q = msg.quoted || msg;
    const mime = (q.msg || q).mimetype || '';
    
    if (!/image/.test(mime)) return msg.reply(`❌ Responde a uma imagem ou envia uma foto com *${usedPrefix + command}* para eu ler o texto.`);

    await msg.react('👁️');
    try {
      const media = await q.download();
      const imageUrl = await uploadImage(media, mime);
      
      const res = await fetch(`https://api.vreden.web.id/api/tools/ocr?url=${encodeURIComponent(imageUrl)}`);
      const json = await res.json();
      
      if (!json.status || !json.result) {
        return msg.reply('❌ Não consegui detectar nenhum texto nesta imagem.');
      }

      const textoExtraido = json.result;
      
      await msg.reply(`📖 *TEXTO EXTRAÍDO DA IMAGEM* 📖\n\n${textoExtraido}\n\n> _Processado por Nel-Aviso-Bot-Moz_`);
      await msg.react('✅');
    } catch (e) {
      console.error(e);
      await msg.react('❌');
      await msg.reply(`❌ Erro ao processar OCR: ${e.message}`);
    }
  }
};
