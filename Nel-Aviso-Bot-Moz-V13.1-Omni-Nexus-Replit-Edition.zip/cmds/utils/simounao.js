export default {
  command: ['simounao', 'simnao', 'decidir', 'escolha'],
  category: 'diversao',
  description: 'O bot decide por ti! Pergunta algo e ele responde Sim ou Não.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    if (!args.length) {
      return msg.reply(`❧ *Sim ou Não* 🤔\n\n✎ Faz uma pergunta:\n> *${usedPrefix + command} Devo ir à festa hoje?*`);
    }

    const question = args.join(' ');
    const answers = [
      { text: '✅ Sim!', emoji: '💪' },
      { text: '✅ Com certeza!', emoji: '🔥' },
      { text: '✅ Definitivamente sim!', emoji: '⭐' },
      { text: '✅ Sem dúvida!', emoji: '🌟' },
      { text: '✅ É isso!', emoji: '🎯' },
      { text: '❌ Não!', emoji: '🚫' },
      { text: '❌ Definitivamente não!', emoji: '⛔' },
      { text: '❌ Nem pensar!', emoji: '🛑' },
      { text: '❌ Melhor não...', emoji: '⚠️' },
      { text: '❌ Aconselho a não!', emoji: '🔴' },
      { text: '🤔 Talvez...', emoji: '🌀' },
      { text: '🤔 Pensa melhor nisso.', emoji: '💭' },
      { text: '🤔 Depende de ti!', emoji: '⚖️' },
      { text: '🤔 Não tenho certeza...', emoji: '🎲' },
    ];

    const answer = answers[Math.floor(Math.random() * answers.length)];
    return msg.reply(
      `❧ *Sim ou Não* ${answer.emoji}\n\n` +
      `▸ Pergunta: *${question}*\n\n` +
      `▸ Resposta: *${answer.text}*\n\n` +
      `▸ Pergunta outra coisa com *${usedPrefix + command}*`
    );
  },
};
