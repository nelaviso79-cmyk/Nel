export default {
  command: ['dado', 'dice', 'rolar', 'roll'],
  category: 'diversao',
  description: 'Rolar um dado virtual 🎲',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    const faces = parseInt(text) || 6;
    if (faces < 2 || faces > 100) return msg.reply('◈ Número de faces inválido! Use 2-100.');
    
    const resultado = Math.floor(Math.random() * faces) + 1;
    const dadoEmojis = { 1: '⚀', 2: '⚁', 3: '⚂', 4: '⚃', 5: '⚄', 6: '⚅' };
    const emoji = faces <= 6 ? dadoEmojis[resultado] || '🎲' : '🎲';
    
    const barra = '▓'.repeat(Math.floor(resultado / faces * 10)) + '░'.repeat(10 - Math.floor(resultado / faces * 10));
    
    return msg.reply(
      `${emoji} *DADO ROLADO* ${emoji}\n\n` +
      `▸ Faces: ${faces}\n` +
      `▸ Resultado: *${resultado}*\n\n` +
      `[${barra}] ${Math.round(resultado / faces * 100)}%\n\n` +
      `_🎲 Nel-Aviso-Bot_`
    );
  }
};
