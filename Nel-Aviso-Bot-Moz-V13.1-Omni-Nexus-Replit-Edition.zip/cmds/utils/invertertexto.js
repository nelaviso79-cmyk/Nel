export default {
  command: ['textocontrário', 'reverse', 'invertertexto', 'espelhtexto'],
  category: 'utilidades',
  description: 'Inverter texto - escrever ao contrário 🔄',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    if (!text) {
      return msg.reply(
        `🔄 *INVERTER TEXTO* 🔄\n\n` +
        `◈ Escreva o texto para inverter!\n\n` +
        `✎ Exemplo: *${usedPrefix + command} Nel Aviso Bot*`
      );
    }

    const invertido = text.split('').reverse().join('');
    const maiusculo = text.toUpperCase();
    const minusculo = text.toLowerCase();
    const alternado = text.split('').map((c, i) => i % 2 === 0 ? c.toLowerCase() : c.toUpperCase()).join('');

    return msg.reply(
      `🔄 *TRANSFORMAÇÕES DE TEXTO* 🔄\n\n` +
      `▸ Original: ${text}\n` +
      `▸ Invertido: ${invertido}\n` +
      `▸ MAIÚSCULO: ${maiusculo}\n` +
      `▸ minúsculo: ${minusculo}\n` +
      `▸ AlTeRnAdO: ${alternado}\n\n` +
      `_🔄 Nel-Aviso-Bot-Moz_`
    );
  }
};
