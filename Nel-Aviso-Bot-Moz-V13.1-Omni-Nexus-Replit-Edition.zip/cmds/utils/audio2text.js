import fetch from 'node-fetch';
import axios from 'axios';

export default {
  command: ['audio2text', 'transcrever', 'transcribe', 'ouvir'],
  category: 'utilidades',
  description: 'Transcrever áudio/voz para texto 🎙️',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    // Verificar se há áudio citado
    let audioMsg = null;
    if (msg.quoted) {
      const qMsg = msg.quoted.message;
      if (qMsg?.audioMessage || qMsg?.documentMessage?.mimetype?.startsWith('audio') || qMsg?.voiceMessage || qMsg?.pttMessage) {
        audioMsg = msg.quoted;
      }
    }

    if (!audioMsg) {
      return msg.reply(
        `🎙️ *TRANSCRIÇÃO DE ÁUDIO* 🎙️\n\n` +
        `▸ Responda a uma mensagem de áudio/voz!\n\n` +
        `✏️ *Como usar:*\n` +
        `▸ Responda a um áudio com: *${usedPrefix + command}*\n` +
        `▸ Funciona com notas de voz, áudios e documentos de áudio\n\n` +
        `💡 O áudio será transcrito para texto automaticamente!`
      );
    }

    try {
      const { key } = await sock.sendMessage(msg.chat, { text: '🎙️ A transcrever áudio...' }, { quoted: msg });
      await msg.react('🎙️');

      // Baixar o áudio
      const buffer = await sock.downloadMediaMessage(audioMsg);
      if (!buffer) {
        return sock.sendMessage(msg.chat, { text: '❧ Não foi possível baixar o áudio.', edit: key }, { quoted: msg });
      }

      let transcribedText = null;

      // Método 1: API siputzx
      try {
        const FormData = (await import('form-data')).default;
        const body = new FormData();
        body.append('audio', buffer, 'audio.ogg');
        const res = await axios.post('https://api.siputzx.my.id/api/s/audio2text', body, { headers: body.getHeaders() });
        if (res.data?.status && res.data?.data) transcribedText = res.data.data;
      } catch {}

      // Método 2: API delirius
      if (!transcribedText) {
        try {
          const FormData = (await import('form-data')).default;
          const body = new FormData();
          body.append('audio', buffer, 'audio.ogg');
          const res = await axios.post(`${global.APIs.delirius.url}/tools/audio2text`, body, { headers: body.getHeaders() });
          if (res.data?.status && res.data?.data) transcribedText = res.data.data;
        } catch {}
      }

      if (!transcribedText) {
        return sock.sendMessage(msg.chat, {
          text: '❧ Não foi possível transcrever o áudio. Tente com um áudio mais curto ou claro.',
          edit: key
        }, { quoted: msg });
      }

      await sock.sendMessage(msg.chat, {
        text: `🎙️ *Transcrição de Áudio*\n\n📝 *Texto transcrito:*\n\n${transcribedText}\n\n💡 Use *${usedPrefix + command}* para transcrever mais áudios!`,
        edit: key
      }, { quoted: msg });
      await msg.react('✅');
    } catch (e) {
      await msg.reply(`> Erro ao transcrever: *${e.message}*`);
    }
  },
};
