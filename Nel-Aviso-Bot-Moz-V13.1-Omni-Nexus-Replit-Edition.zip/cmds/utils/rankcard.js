export const command = {
  name: 'rankcard',
  aliases: ['rankimg', 'levelcard', 'lvcard', 'cardlevel', 'cardranking'],
  description: 'Gera card visual do teu nível e ranking no bot',
  category: 'perfil',
  usage: '.rankcard',
  example: '.rankcard'
};

export default async function ({ sock, msg, args, from, sender, config }) {
  await sock.sendMessage(from, { react: { text: '🏆', key: msg.key } });

  try {
    // Obter dados do utilizador da DB
    const db = global.db;
    const userData = db?.users?.[sender] || {};
    const name = userData.name || msg.pushName || 'User';
    const level = userData.level || 1;
    const xp = userData.xp || 0;
    const coins = userData.coins || userData.money || 0;
    const bank = userData.bank || 0;
    const role = userData.role || 'Membro';
    const msgCount = userData.messageCount || userData.messages || 0;

    let avatarUrl = 'https://i.ibb.co/4p4NfKx/default-avatar.png';
    try { avatarUrl = await sock.profilePictureUrl(sender, 'image'); } catch (e) { }

    // Delirius Canvas — balcard
    const res = await fetch(`https://api.delirius.store/canvas/balcard?name=${encodeURIComponent(name)}&url=${encodeURIComponent(avatarUrl)}&background=https://i.ibb.co/4p4NfKx/default-avatar.png&level=${level}&xp=${xp}&role=${encodeURIComponent(role)}`);

    if (res.ok) {
      const buffer = Buffer.from(await res.arrayBuffer());
      await sock.sendMessage(from, {
        image: buffer,
        caption: `🏆 *Rank Card*\n\n🧑 ${name}\n⭐ Level: ${level}\n✨ XP: ${xp.toLocaleString()}\n💰 Moedas: ${coins.toLocaleString()}\n🏦 Banco: ${bank.toLocaleString()}\n📋 Role: ${role}\n💬 Mensagens: ${msgCount.toLocaleString()}`
      }, { quoted: msg });
      return;
    }
  } catch (e) { console.log('Rankcard failed:', e.message); }

  // Fallback texto
  const db = global.db;
  const userData = db?.users?.[sender] || {};
  const name = userData.name || msg.pushName || 'User';
  const level = userData.level || 1;
  const xp = userData.xp || 0;
  const coins = userData.coins || userData.money || 0;
  const role = userData.role || 'Membro';

  const xpPercent = Math.min(100, Math.floor((xp % 500) / 5));
  const barLen = 20;
  const filled = Math.round((xpPercent / 100) * barLen);

  await sock.sendMessage(from, {
    text: `🏆 *RANK CARD*

━━━━━━━━━━━━━━━━━━━━

🧑 *${name}*
⭐ Level: *${level}*
✨ XP: *${xp.toLocaleString()}*
📊 Progresso: ${'█'.repeat(filled)}${'░'.repeat(barLen - filled)} ${xpPercent}%
💰 Moedas: *${coins.toLocaleString()}*
📋 Role: *${role}*

━━━━━━━━━━━━━━━━━━━━`
  }, { quoted: msg });
}
