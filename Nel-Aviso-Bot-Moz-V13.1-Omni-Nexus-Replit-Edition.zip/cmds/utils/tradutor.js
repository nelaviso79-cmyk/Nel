export default {
  command: ['tradutor', 'idioma', 'linguagem'],
  category: 'utilidades',
  description: 'Traduzir texto para qualquer idioma 🌍',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    if (!text) {
      return msg.reply(
        `🌍 *TRADUTOR* 🌍\n\n` +
        `◈ Traduza texto para qualquer idioma!\n\n` +
        `✎ Formato: *${usedPrefix + command} idioma|texto*\n\n` +
        `✎ Exemplos:\n` +
        `▸ *${usedPrefix + command} pt|Hello world*\n` +
        `▸ *${usedPrefix + command} en|Olá mundo*\n` +
        `▸ *${usedPrefix + command} fr|Bom dia*\n\n` +
        `◈ Idiomas: pt=Português, en=Inglês, es=Espanhol,\n  fr=Francês, de=Alemão, it=Italiano, ja=Japonês,\n  ko=Coreano, zh=Chinês, ru=Russo, ar=Árabe`
      );
    }

    if (!text.includes('|')) {
      return msg.reply(`◈ Use o formato: *${usedPrefix + command} idioma|texto*\n\nExemplo: *${usedPrefix + command} pt|Hello world*`);
    }

    const [idioma, ...textoParts] = text.split('|');
    const textoTraduzir = textoParts.join('|').trim();
    const lang = idioma.trim().toLowerCase();

    if (!textoTraduzir) return msg.reply('◈ Escreva o texto para traduzir!');

    await msg.react('⏳');

    try {
      const url = `https://api.translate.google.com/translate_a/single?client=gtx&sl=auto&tl=${lang}&dt=t&q=${encodeURIComponent(textoTraduzir)}`;
      const response = await fetch(url);
      const data = await response.json();

      if (!data || !data[0]) {
        await msg.react('❌');
        return msg.reply('◈ Não foi possível traduzir. Verifique o idioma!');
      }

      let traducao = '';
      for (const part of data[0]) {
        if (part[0]) traducao += part[0];
      }

      const idiomaDetectado = data[2] || 'desconhecido';

      await msg.reply(
        `🌍 *TRADUÇÃO* 🌍\n\n` +
        `▸ De: *${idiomaDetectado.toUpperCase()}*\n` +
        `▸ Para: *${lang.toUpperCase()}*\n\n` +
        `📝 *Original:* _${textoTraduzir}_\n\n` +
        `📝 *Tradução:* _${traducao}_\n\n` +
        `_🌍 Nel-Aviso-Bot-Moz_`
      );

      await msg.react('✅');
    } catch (e) {
      await msg.react('❌');
      return msg.reply(`◈ Erro na tradução: ${e.message}`);
    }
  }
};
