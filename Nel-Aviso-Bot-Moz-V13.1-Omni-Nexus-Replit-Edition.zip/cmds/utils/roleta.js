export default {
  command: ['roleta', 'roulette', 'girar'],
  category: 'diversao',
  description: 'Roleta russa - Quem será o escolhido? 🔫',
  run: async ({ msg, sock, usedPrefix, command, participants }) => {
    if (!msg.isGroup) return msg.reply('◈ Este comando só funciona em grupos!');
    
    const alive = participants.filter(p => p.id && !p.id.startsWith('258')).map(p => p.id);
    if (alive.length < 2) return msg.reply('◈ Precisa de pelo menos 2 membros!');
    
    const tiro = Math.floor(Math.random() * 6) + 1;
    const vitima = alive[Math.floor(Math.random() * alive.length)];
    const nomeVitima = vitima.split('@')[0];
    
    if (tiro === 1) {
      const mensagens = [
        `🔫 *ROLETA RUSSA* 🔫\n\n💥 BANG! @${nomeVitima} foi baleado!\n\n🪦 Descanse em paz... 😵`,
        `🔫 *ROLETA RUSSA* 🔫\n\n💣 A bala encontrou @${nomeVitima}!\n\n😵 Não sobreviveu à roleta!`,
        `🔫 *ROLETA RUSSA* 🔫\n\n⚡ @${nomeVitima} não teve sorte!\n\n💀 A roleta decidiu!`
      ];
      return msg.reply(mensagens[Math.floor(Math.random() * mensagens.length)], { mentions: [vitima] });
    } else {
      const sobreviveu = [
        `🔫 *ROLETA RUSSA* 🔫\n\n🎵 *CLICK* ... Nada aconteceu!\n\n@${nomeVitima} sobreviveu! 🎉\n▸ A bala estava na câmara ${tiro}/6`,
        `🔫 *ROLETA RUSSA* 🔫\n\n🎵 *CLICK* ... Silêncio!\n\n😊 @${nomeVitima} teve sorte!\n▸ A bala estava na câmara ${tiro}/6`,
        `🔫 *ROLETA RUSSA* 🔫\n\n🎵 *CLICK CLICK* ... Nada!\n\n🍀 @${nomeVitima} escapou ileso!\n▸ A bala estava na câmara ${tiro}/6`
      ];
      return msg.reply(sobreviveu[Math.floor(Math.random() * sobreviveu.length)], { mentions: [vitima] });
    }
  }
};
