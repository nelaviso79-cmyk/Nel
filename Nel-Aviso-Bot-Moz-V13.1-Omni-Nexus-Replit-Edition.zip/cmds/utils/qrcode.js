export default {
  command: ['qrcode', 'qr', 'gerarqr', 'criarqr'],
  category: 'utilidades',
  description: 'Gerar um QR Code a partir de texto ou link 📱',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    if (!text) {
      return msg.reply(
        `📱 *GERAR QR CODE* 📱\n\n` +
        `◈ Escreva o texto ou link para gerar o QR!\n\n` +
        `✎ Exemplos:\n` +
        `▸ *${usedPrefix + command} https://wa.me/258876365643*\n` +
        `▸ *${usedPrefix + command} Meu texto secreto*\n` +
        `▸ *${usedPrefix + command} Nel-Aviso-Bot-Moz*`
      );
    }

    await msg.react('⏳');

    try {
      const qrText = encodeURIComponent(text);
      const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=512x512&data=${qrText}&bgcolor=FFFFFF&color=000000&margin=10`;
      
      await sock.sendMessage(msg.chat, {
        image: { url: qrUrl },
        caption: `📱 *QR CODE GERADO* 📱\n\n▸ Conteúdo: _${text}_\n\n_Nel-Aviso-Bot-Moz_ 🇲🇿`
      }, { quoted: msg });

      await msg.react('✅');
    } catch (e) {
      await msg.react('❌');
      return msg.reply(`◈ Erro ao gerar QR: ${e.message}`);
    }
  }
};
