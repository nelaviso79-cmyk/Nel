export default {
  command: ['destino', 'bola8', 'magic8', 'boladecristal'],
  category: 'diversao',
  description: 'Pergunta à Bola de Cristal e recebe uma resposta mística!',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    if (!args.length) {
      return msg.reply(`❧ Faz uma pergunta à *Bola de Cristal* 🔮\n\n✎ Exemplo: *${usedPrefix + command} Vou ter sorte hoje?*`);
    }

    const question = args.join(' ');
    const respostas = [
      '✅ Com certeza!',
      '✅ Sim, definitivamente!',
      '✅ Sem dúvida!',
      '✅ Podes contar com isso!',
      '✅ Muito provavelmente!',
      '👍 Sim, mas com paciência.',
      '🤔 Talvez... o destino é misterioso.',
      '🌀 Pergunta novamente mais tarde...',
      '🌀 Não contes com isso agora.',
      '⚠️ É possível, mas não garanto.',
      '❌ Provavelmente não.',
      '❌ Definitivamente não!',
      '❌ A minha resposta é não.',
      '❌ Nem pensar!',
      '🌟 Os astros dizem que sim!',
      '🌑 Os astros dizem que talvez.',
      '🔥 O fogo indica mudança... prepare-se!',
      '🌊 A água diz para ter calma e esperar.',
      '🌍 O universo está do teu lado!',
      '🌙 A lua pede reflexão antes de agir.',
    ];

    const resposta = respostas[Math.floor(Math.random() * respostas.length)];

    return msg.reply(
      `❧ *Bola de Cristal* 🔮\n\n` +
      `▸ Pergunta: *${question}*\n\n` +
      `🔮 Resposta: *${resposta}*\n\n` +
      `▸ Pergunta outra coisa com *${usedPrefix + command}*`
    );
  },
};
