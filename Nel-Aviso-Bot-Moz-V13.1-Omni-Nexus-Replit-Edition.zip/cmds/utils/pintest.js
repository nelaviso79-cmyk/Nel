export const command = {
  name: 'pintest',
  aliases: ['pinterestsearch', 'pinsearch', 'pins', 'pinimg', 'pinterestimg'],
  description: 'Busca imagens no Pinterest (várias imagens por busca)',
  category: 'downloads',
  usage: '.pintest <termo de busca>',
  example: '.pintest anime wallpaper'
};

export default async function ({ sock, msg, args, from, sender, config }) {
  const query = args.join(' ').trim();
  if (!query) {
    return sock.sendMessage(from, {
      text: '❌ Escreve o que queres buscar!\n\n💡 *Uso:* .pintest <termo>\n📌 *Ex:* .pintest anime wallpaper'
    }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '📌', key: msg.key } });

  try {
    const res = await fetch(`https://api.delirius.store/search/pinterest?query=${encodeURIComponent(query)}`);
    const data = await res.json();
    if (data?.status === 200 && data?.result && data.result.length > 0) {
      const images = data.result.slice(0, 5);
      let sentCount = 0;

      for (const img of images) {
        const imgUrl = img.url || img.image || img.thumbnail || img.src || img;
        if (typeof imgUrl === 'string' && imgUrl.startsWith('http')) {
          try {
            const imgRes = await fetch(imgUrl);
            if (imgRes.ok) {
              const buffer = Buffer.from(await imgRes.arrayBuffer());
              await sock.sendMessage(from, {
                image: buffer,
                caption: sentCount === 0 ? `📌 *Pinterest* — "${query}"\n🖼️ ${images.length} imagens encontradas` : '',
                contextInfo: sentCount === 0 ? {
                  externalAdReply: { title: 'Pinterest Search', body: query, thumbnailUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3c/Pinterest_Logo.svg/1200px-Pinterest_Logo.svg.png', mediaType: 1 }
                } : undefined
              }, { quoted: msg });
              sentCount++;
              if (sentCount >= 3) break; // Max 3 images
            }
          } catch (e) { }
        }
      }

      if (sentCount > 0) return;
    }
  } catch (e) {
    console.log('Pinterest search failed:', e.message);
  }

  await sock.sendMessage(from, { text: `❌ Não encontrei imagens de "${query}" no Pinterest.` }, { quoted: msg });
}
