export default {
  command: ['quiz', 'trivia', 'pergunta'],
  category: 'diversao',
  description: 'Quiz de cultura geral com perguntas aleatórias sobre Moçambique e o mundo.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const quizzes = [
      { q: 'Qual é a capital de Moçambique?', opts: ['A) Maputo', 'B) Beira', 'C) Nampula', 'D) Quelimane'], a: 'A' },
      { q: 'Qual é a moeda oficial de Moçambique?', opts: ['A) Rand', 'B) Metical', 'C) Dólar', 'D) Euro'], a: 'B' },
      { q: 'Qual é o maior país do mundo em área?', opts: ['A) Canadá', 'B) China', 'C) Rússia', 'D) EUA'], a: 'C' },
      { q: 'Quem pintou a Mona Lisa?', opts: ['A) Michelangelo', 'B) Picasso', 'C) Da Vinci', 'D) Van Gogh'], a: 'C' },
      { q: 'Quantos continentes existem?', opts: ['A) 5', 'B) 6', 'C) 7', 'D) 8'], a: 'C' },
      { q: 'Qual é o rio mais longo do mundo?', opts: ['A) Amazonas', 'B) Nilo', 'C) Mississippi', 'D) Danúbio'], a: 'B' },
      { q: 'Em que ano Moçambique tornou-se independente?', opts: ['A) 1964', 'B) 1970', 'C) 1975', 'D) 1980'], a: 'C' },
      { q: 'Qual planeta é conhecido como Planeta Vermelho?', opts: ['A) Júpiter', 'B) Marte', 'C) Saturno', 'D) Vénus'], a: 'B' },
      { q: 'Qual é a língua oficial de Moçambique?', opts: ['A) Inglês', 'B) Português', 'C) Francês', 'D) Espanhol'], a: 'B' },
      { q: 'Quantos ossos tem o corpo humano adulto?', opts: ['A) 186', 'B) 206', 'C) 226', 'D) 256'], a: 'B' },
      { q: 'Qual é o animal mais rápido do mundo?', opts: ['A) Leão', 'B) Cavalo', 'C) Falcão-peregrino', 'D) Guepardo'], a: 'D' },
      { q: 'Qual é o oceano entre África e América?', opts: ['A) Pacífico', 'B) Índico', 'C) Atlântico', 'D) Ártico'], a: 'C' },
      { q: 'Quem escreveu "Os Lusíadas"?', opts: ['A) Fernando Pessoa', 'B) Camões', 'C) Eça de Queirós', 'D) Saramago'], a: 'B' },
      { q: 'Quantos jogadores tem um time de futebol em campo?', opts: ['A) 9', 'B) 10', 'C) 11', 'D) 12'], a: 'C' },
      { q: 'Qual é o maior oceano do mundo?', opts: ['A) Atlântico', 'B) Índico', 'C) Pacífico', 'D) Ártico'], a: 'C' },
      { q: 'Qual é a montanha mais alta de Moçambique?', opts: ['A) Monte Binga', 'B) Monte Namúli', 'C) Monte Chiperone', 'D) Monte Gorongosa'], a: 'A' },
      { q: 'Qual é o elemento químico com símbolo O?', opts: ['A) Ouro', 'B) Ósmio', 'C) Oxigénio', 'D) Olho'], a: 'C' },
      { q: 'Em que continente fica Moçambique?', opts: ['A) Europa', 'B) Ásia', 'C) América', 'D) África'], a: 'D' },
      { q: 'Qual é a provincia mais populosa de Moçambique?', opts: ['A) Maputo', 'B) Zambézia', 'C) Nampula', 'D) Sofala'], a: 'C' },
      { q: 'Quem foi o primeiro presidente de Moçambique?', opts: ['A) Joaquim Chissano', 'B) Samora Machel', 'C) Armando Guebuza', 'D) Filipe Nyusi'], a: 'B' },
    ];

    const quiz = quizzes[Math.floor(Math.random() * quizzes.length)];
    const text = 
      `❧ *Quiz de Cultura* 🧠\n\n` +
      `▸ Pergunta: *${quiz.q}*\n\n` +
      `${quiz.opts.join('\n')}\n\n` +
      `▸ Responde com a letra correcta! Exemplo: *A*\n` +
      `▸ Resposta: ||${quiz.a}||`;

    return msg.reply(text);
  },
};
