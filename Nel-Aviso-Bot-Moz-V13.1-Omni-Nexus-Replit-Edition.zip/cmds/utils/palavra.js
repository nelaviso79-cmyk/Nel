export default {
  command: ['palavra', 'palavradooia', 'dicionario', 'definir'],
  category: 'utilidades',
  description: 'Palavra aleatória com definição 📖',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    const palavras = [
      { palavra: 'Ubuntu', definicao: 'Filosofia africana que significa "Eu sou porque nós somos". Base da comunidade e solidariedade.', origem: 'Zulu/Xhosa' },
      { palavra: 'Saudade', definicao: 'Sentimento nostálgico e profundo de falta de algo ou alguém amado. Sentimento único da língua portuguesa.', origem: 'Português' },
      { palavra: 'Kizomba', definicao: 'Género musical e dança originário de Angola, caracterizado pelo ritmo sensual e compasso 4/4.', origem: 'Angola' },
      { palavra: 'Mafalala', definicao: 'Bairro histórico de Maputo, berço de grandes escritores e artistas moçambicanos.', origem: 'Moçambique' },
      { palavra: 'Timbila', definicao: 'Instrumento musical tradicional dos Chopi, reconhecido pela UNESCO como património imaterial.', origem: 'Moçambique' },
      { palavra: 'Hakuna', definicao: 'Expressão swahili que significa "não há" ou "sem problema". Popularizada pelo filme Rei Leão.', origem: 'Swahili' },
      { palavra: 'Capulana', definicao: 'Pano colorido usado pelas mulheres moçambicanas como vestimenta e símbolo cultural.', origem: 'Moçambique' },
      { palavra: 'Xipoco', definicao: 'Espírito ancestral na cultura tradicional moçambicana, guia espiritual das famílias.', origem: 'Moçambique' },
      { palavra: 'Muti', definicao: 'Medicina tradicional africana, usando plantas e rituais para cura. Significa "árvore" em Zulu.', origem: 'Zulu' },
      { palavra: 'Chimurenga', definicao: 'Palavra shona que significa "luta de libertação". Nome dado às guerras de independência no Zimbabwe.', origem: 'Shona' },
      { palavra: 'Ndebele', definicao: 'Povo e língua do sul de África, conhecidos pela arte geométrica colorida nas casas.', origem: 'África do Sul' },
      { palavra: 'Nyama', definicao: 'Carne em várias línguas bantu. Também significa "espírito" ou "essência" em contextos espirituais.', origem: 'Bantu' },
      { palavra: 'Libombo', definicao: 'Montanha na fronteira Moçambique-Eswatini, com significado espiritual para as comunidades locais.', origem: 'Moçambique' },
      { palavra: 'Marimba', definicao: 'Instrumento de percussão africano, precursor do xilofone moderno, feito com madeira e cabaças.', origem: 'África' },
      { palavra: 'Djembe', definicao: 'Tambor em forma de cálice da África Ocidental, usado em cerimónias e celebrações.', origem: 'Mali' },
      { palavra: 'Ashanti', definicao: 'Povo e reino do Gana, conhecidos pela ourivesaria e kente-cloth (tecido real).', origem: 'Gana' },
      { palavra: 'Vuvuzela', definicao: 'Trompete plástico sul-africano, famoso na Copa 2010. Traz a energia dos estádios africanos.', origem: 'África do Sul' },
      { palavra: 'Shweshwe', definicao: 'Tecido estampado tradicional sul-africano com padrões geométricos em índigo.', origem: 'África do Sul' },
    ];

    const p = palavras[Math.floor(Math.random() * palavras.length)];

    let result = `📖 *PALAVRA DO DIA*\n\n`;
    result += `📝 Palavra: *${p.palavra}*\n`;
    result += `🌍 Origem: *${p.origem}*\n`;
    result += `📋 Definição: ${p.definicao}\n\n`;
    result += `🔄 Use *${usedPrefix}${command}* para outra palavra!`;

    await sock.sendMessage(msg.key.remoteJid, { text: result }, { quoted: msg });
  }
};
