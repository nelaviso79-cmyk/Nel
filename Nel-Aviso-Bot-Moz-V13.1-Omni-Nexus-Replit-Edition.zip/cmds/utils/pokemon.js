// ╔══════════════════════════════════════════════════════════╗
//   NEL-AVISO-BOT-MOZ · cmds/utils/pokemon.js
// ╚══════════════════════════════════════════════════════════╝

import fetch from 'node-fetch';

export default {
  command: ['pokemon', 'poke', 'pokedex', 'pokeinfo'],
  category: 'utilidades',
  description: 'Informação detalhada de Pokémon com imagem e stats ⚡',

  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const query = args.join(' ').trim().toLowerCase();

    if (!query) {
      return msg.reply(
        `⚡ *POKÉDEX* ⚡\n\n` +
        `Busque informações de qualquer Pokémon!\n\n` +
        `📋 Exemplos:\n` +
        `• *${usedPrefix}${command} pikachu*\n` +
        `• *${usedPrefix}${command} charizard*\n` +
        `• *${usedPrefix}${command} 25* (por número)\n\n` +
        `> Mostra tipo, stats, habilidades e cadeia evolutiva!`
      );
    }

    await msg.reply(`⏳ A buscar dados de *${query}* na Pokédex...`);

    try {
      // Primary: Delirius Pokémon API
      const res = await fetch(
        `https://api.delirius.store/tools/pokemon?query=${encodeURIComponent(query)}&language=pt`
      );
      const data = await res.json();

      if (data.status && data.result) {
        const p = data.result;
        let text =
          `⚡ *POKÉDEX* ⚡\n\n` +
          `📛 Nome: *${p.name || query}*\n` +
          `🔢 Nº: *#${String(p.id || p.number || '').padStart(3, '0')}*\n` +
          `📏 Altura: ${p.height || 'N/A'}\n` +
          `⚖️ Peso: ${p.weight || 'N/A'}\n` +
          `🎨 Cor: ${p.color || 'N/A'}\n\n`;

        if (p.types || p.type) {
          const types = Array.isArray(p.types || p.type) ? (p.types || p.type) : [p.types || p.type];
          text += `🏷 *TIPO:* ${types.map(t => typeof t === 'object' ? t.name || t.type?.name : t).join(' / ')}\n\n`;
        }

        if (p.abilities || p.ability) {
          const abilities = Array.isArray(p.abilities || p.ability) ? (p.abilities || p.ability) : [p.abilities || p.ability];
          text += `✨ *HABILIDADES:*\n`;
          for (const a of abilities) {
            const name = typeof a === 'object' ? a.name || a.ability?.name : a;
            const hidden = typeof a === 'object' && a.hidden ? ' (oculta)' : '';
            text += `• ${name}${hidden}\n`;
          }
          text += '\n';
        }

        if (p.stats) {
          text += `📊 *BASE STATS:*\n`;
          const statNames = {
            hp: '❤️ HP', attack: '⚔️ Ataque', defense: '🛡 Defesa',
            'special-attack': '🔮 Atq.Esp', 'special-defense': '🛡✨ Def.Esp', speed: '💨 Velocidade'
          };
          for (const s of (Array.isArray(p.stats) ? p.stats : [])) {
            const name = statNames[s.stat?.name || s.name] || s.stat?.name || s.name;
            const val = s.base_stat || s.value || 0;
            const bar = '█'.repeat(Math.min(Math.floor(val / 10), 15)) + '░'.repeat(Math.max(15 - Math.floor(val / 10), 0));
            text += `${name}: ${bar} *${val}*\n`;
          }
          text += '\n';
        }

        if (p.evolution || p.evolutions) {
          const evos = p.evolution || p.evolutions;
          if (Array.isArray(evos) && evos.length > 0) {
            text += `🧬 *EVOLUÇÃO:* ${evos.map(e => typeof e === 'object' ? e.name || e.species?.name : e).join(' → ')}\n\n`;
          } else if (typeof evos === 'string') {
            text += `🧬 *EVOLUÇÃO:* ${evos}\n\n`;
          }
        }

        if (p.description || p.summary) {
          text += `📖 *DESCRIÇÃO:*\n${p.description || p.summary}\n`;
        }

        const img = p.image || p.sprite || p.sprites?.front_default || p.artwork ||
          `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${p.id || 1}.png`;

        await sock.sendMessage(msg.chat, {
          image: { url: img },
          caption: text
        }, { quoted: msg });
        return;
      }

      // Fallback: PokeAPI direct
      const res2 = await fetch(`https://pokeapi.co/api/v2/pokemon/${encodeURIComponent(query)}`);
      if (!res2.ok) throw new Error('Pokémon não encontrado');
      const p2 = await res2.json();

      const stats = p2.stats.map(s => {
        const bar = '█'.repeat(Math.min(Math.floor(s.base_stat / 10), 15)) + '░'.repeat(Math.max(15 - Math.floor(s.base_stat / 10), 0));
        return `${statLabel(s.stat.name)}: ${bar} *${s.base_stat}*`;
      }).join('\n');

      const types = p2.types.map(t => t.type.name).join(' / ');
      const abilities = p2.abilities.map(a => a.ability.name + (a.is_hidden ? ' (oculta)' : '')).join(', ');

      const text =
        `⚡ *POKÉDEX* ⚡\n\n` +
        `📛 Nome: *${p2.name}*\n` +
        `🔢 Nº: *#${String(p2.id).padStart(3, '0')}*\n` +
        `📏 Altura: ${(p2.height / 10).toFixed(1)}m\n` +
        `⚖️ Peso: ${(p2.weight / 10).toFixed(1)}kg\n` +
        `🏷 Tipo: *${types}*\n\n` +
        `✨ Habilidades: ${abilities}\n\n` +
        `📊 *BASE STATS:*\n${stats}`;

      const img = p2.sprites?.other?.['official-artwork']?.front_default ||
        p2.sprites?.front_default ||
        `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${p2.id}.png`;

      await sock.sendMessage(msg.chat, {
        image: { url: img },
        caption: text
      }, { quoted: msg });

    } catch (e) {
      await msg.reply(
        `❌ Pokémon *${query}* não encontrado!\n` +
        `> Verifique o nome ou número. Ex: *pikachu* ou *25*`
      );
    }
  }
};

function statLabel(name) {
  const map = {
    hp: '❤️ HP', attack: '⚔️ Ataque', defense: '🛡 Defesa',
    'special-attack': '🔮 Atq.Esp', 'special-defense': '🛡✨ Def.Esp', speed: '💨 Velocidade'
  };
  return map[name] || name;
}
