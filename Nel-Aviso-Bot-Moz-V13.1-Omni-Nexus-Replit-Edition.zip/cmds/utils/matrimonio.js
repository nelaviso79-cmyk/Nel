export default {
  command: ['matrimonio', 'casarcomigo', 'compatibilidade', 'casamento'],
  category: 'diversao',
  description: 'Teste de compatibilidade matrimonial 💒',
  run: async ({ msg, sock, usedPrefix, command, participants }) => {
    if (!msg.key.remoteJid.endsWith('@g.us')) return await sock.sendMessage(msg.key.remoteJid, { text: '❌ Este comando só funciona em grupos!' }, { quoted: msg });

    const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (mentioned.length < 1) return await sock.sendMessage(msg.key.remoteJid, { text: `✳️ Use: ${usedPrefix}${command} @pessoa\n\nMarque alguém para testar compatibilidade!` }, { quoted: msg });

    const sender = msg.key.participant || msg.key.remoteJid;
    const target = mentioned[0];

    // Generate deterministic but fun results based on phone numbers
    const s1 = sender.replace(/[^0-9]/g, '');
    const s2 = target.replace(/[^0-9]/g, '');
    let seed = 0;
    for (let i = 0; i < Math.min(s1.length, s2.length); i++) {
      seed += parseInt(s1[i] || 0) * parseInt(s2[i] || 0);
    }

    const compat = (seed % 41) + 60; // 60-100

    const aspects = [
      { name: 'Amor', emoji: '❤️', score: (seed * 7 + 13) % 41 + 60 },
      { name: 'Comunicação', emoji: '💬', score: (seed * 11 + 7) % 41 + 60 },
      { name: 'Confiança', emoji: '🤝', score: (seed * 3 + 19) % 41 + 60 },
      { name: 'Lealdade', emoji: '💜', score: (seed * 13 + 3) % 41 + 60 },
      { name: 'Compreensão', emoji: '🧠', score: (seed * 5 + 23) % 41 + 60 },
      { name: 'Romance', emoji: '🌹', score: (seed * 17 + 11) % 41 + 60 },
    ];

    const getBar = (score) => {
      const filled = Math.floor(score / 10);
      return '█'.repeat(filled) + '░'.repeat(10 - filled);
    };

    const getVerdict = (score) => {
      if (score >= 95) return '💍 CASAMENTO PERFEITO! Almas gémeas!';
      if (score >= 85) return '💕 Excelente compatibilidade! Relação forte!';
      if (score >= 75) return '❤️ Boa compatibilidade! Tem potencial!';
      if (score >= 65) return '💛 Compatibilidade moderada. Precisa de esforço!';
      return '💔 Difícil... mas o amor supera tudo!';
    };

    let name1 = '@' + sender.split('@')[0];
    let name2 = '@' + target.split('@')[0];

    let result = `💒 *TESTE DE COMPATIBILIDADE MATRIMONIAL*\n\n`;
    result += `👫 ${name1} + ${name2}\n\n`;
    result += `💝 Compatibilidade Geral: *${compat}%*\n${getBar(compat)}\n\n`;

    for (const a of aspects) {
      result += `${a.emoji} ${a.name}: *${a.score}%* ${getBar(a.score)}\n`;
    }

    result += `\n${getVerdict(compat)}`;
    result += `\n\n🔄 Use *${usedPrefix}${command} @pessoa* para outro teste!`;

    await sock.sendMessage(msg.key.remoteJid, {
      text: result,
      mentions: [sender, target]
    }, { quoted: msg });
  }
};
