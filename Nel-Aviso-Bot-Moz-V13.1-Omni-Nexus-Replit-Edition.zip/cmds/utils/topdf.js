import fetch from 'node-fetch';
import uploadImage from '#uploadImage';

export default {
  command: ['topdf', 'img2pdf', 'pdf'],
  category: 'utilidades',
  description: 'Converte uma imagem num documento PDF profissional.',
  run: async ({ msg, sock, usedPrefix, command }) => {
    const q = msg.quoted || msg;
    const mime = (q.msg || q).mimetype || '';
    
    if (!/image/.test(mime)) return msg.reply(`❌ Responde a uma imagem para converter em PDF.`);

    await msg.react('📄');
    try {
      const media = await q.download();
      const imageUrl = await uploadImage(media, mime);
      
      // Usando uma API de conversão de imagem para PDF
      const pdfUrl = `https://api.vreden.web.id/api/tools/img2pdf?url=${encodeURIComponent(imageUrl)}`;
      const res = await fetch(pdfUrl);
      
      if (!res.ok) throw new Error('Falha ao gerar PDF');
      
      const buffer = Buffer.from(await res.arrayBuffer());

      await sock.sendMessage(msg.chat, {
        document: buffer,
        mimetype: 'application/pdf',
        fileName: `Nel-Aviso-Documento-${Date.now()}.pdf`,
        caption: `📄 *PDF Gerado com Sucesso!*\n\n> _Convertido por Nel-Aviso-Bot-Moz_`
      }, { quoted: msg });
      
      await msg.react('✅');
    } catch (e) {
      console.error(e);
      await msg.react('❌');
      await msg.reply(`❌ Erro ao converter para PDF: ${e.message}`);
    }
  }
};
