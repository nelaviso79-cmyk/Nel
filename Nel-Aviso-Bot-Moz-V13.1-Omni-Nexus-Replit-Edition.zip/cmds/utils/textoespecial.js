export default {
  command: ['textoespecial', 'fancy', 'fancytext', 'textolegal', 'estiloso'],
  category: 'utilidades',
  description: 'Converter texto em estilos especiais ✨',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    if (!text) {
      return msg.reply(
        `✨ *TEXTO ESPECIAL* ✨\n\n` +
        `◈ Transforme seu texto em estilos únicos!\n\n` +
        `✎ Exemplo: *${usedPrefix + command} Nel Aviso*\n\n` +
        `◈ Vários estilos serão gerados!`
      );
    }

    const estilos = {
      '𝗡𝗲𝗴𝗿𝗶𝘁𝗼': (t) => t.split('').map(c => {
        const map = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        const bold = '𝗮𝗯𝗰𝗱𝗲𝗳𝗴𝗵𝗶𝗷𝗸𝗹𝗺𝗻𝗼𝗽𝗾𝗿𝘀𝘁𝘂𝘃𝘄𝘅𝘆𝘇𝗔𝗕𝗖𝗗𝗘𝗙𝗚𝗛𝗜𝗝𝗞𝗟𝗠𝗡𝗢𝗣𝗤𝗥𝗦𝗧𝗨𝗩𝗪𝗫𝗬𝗭𝟬𝟭𝟮𝟯𝟰𝟱𝟲𝟳𝟴𝟵';
        const i = map.indexOf(c);
        return i >= 0 ? bold[i] : c;
      }).join(''),
      '𝘛𝘢𝘭𝘪𝘤𝘰': (t) => t.split('').map(c => {
        const map = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const italic = '𝘢𝘣𝘤𝘥𝘦𝘧𝘨𝘩𝘪𝘫𝘬𝘭𝘮𝘯𝘰𝘱𝘲𝘳𝘴𝘵𝘶𝘷𝘸𝘹𝘻𝘈𝘉𝘊𝘋𝘌𝘍𝘎𝘏𝘐𝘑𝘒𝘓𝘔𝘕𝘖𝘗𝘘𝘙𝘚𝘛𝘜𝘝𝘞𝘟𝘠𝘡';
        const i = map.indexOf(c);
        return i >= 0 ? italic[i] : c;
      }).join(''),
      '𝕄𝕠𝕟𝕠': (t) => t.split('').map(c => {
        const map = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const mono = '𝕒𝕓𝕔𝕕𝕖𝕗𝕘𝕙𝕚𝕛𝕜𝕝𝕞𝕟𝕠𝕡𝕢𝕣𝕤𝕥𝕦𝕧𝕨𝕩𝕪𝕫𝔸𝔹ℂ𝔻𝔼𝔽𝔾ℍ𝕀𝕁𝕂𝕃𝕄ℕ𝕆ℙℚℝ𝕊𝕋𝕌𝕍𝕎𝕏𝕐ℤ';
        const i = map.indexOf(c);
        return i >= 0 ? mono[i] : c;
      }).join(''),
      'ᵀᶦⁿʸ': (t) => t.split('').map(c => {
        const map = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const tiny = 'ᵃᵇᶜᵈᵉᶠᵍʰⁱʲᵏˡᵐⁿᵒᵖᑫʳˢᵗᵘᵛʷˣʸᶻᴬᴮᶜᴰᴱᶠᴳᴴᴵᴶᴷᴸᴹᴺᴼᴾQᴿˢᵀᵁⱽᵂˣʸᶻ';
        const i = map.indexOf(c);
        return i >= 0 ? tiny[i] : c;
      }).join(''),
      'ⓦⓞⓞⓓⓢ': (t) => t.split('').map(c => {
        const map = 'abcdefghijklmnopqrstuvwxyz';
        const circle = 'ⓐⓑⓒⓓⓔⓕⓖⓗⓘⓙⓚⓛⓜⓝⓞⓟⓠⓡⓢⓣⓤⓥⓦⓧⓨⓩ';
        const i = map.indexOf(c.toLowerCase());
        return i >= 0 ? circle[i] : c;
      }).join(''),
      '【K】【A】【K】【U】【J】【I】': (t) => t.split('').map(c => {
        if (c === ' ') return ' ';
        return `【${c}】`;
      }).join(''),
      '🅂🅀🅄🄰🅁🄴': (t) => t.split('').map(c => {
        const map = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const sq = '🄰🄱🄲🄳🄴🄵🄶🄷🄸🄹🄺🄻🄼🄽🄾🄿🅀🅁🅂🅃🅄🅅🅆🅇🅈🅉🄰🄱🄲🄳🄴🄵🄶🄷🄸🄹🄺🄻🄼🄽🄾🄿🅀🅁🅂🅃🅄🅅🅆🅇🅈🅉';
        const i = map.indexOf(c);
        return i >= 0 ? sq[i] : c;
      }).join(''),
      'sᴍᴀʟʟ ᴄᴀᴘs': (t) => t.split('').map(c => {
        const map = 'abcdefghijklmnopqrstuvwxyz';
        const sc = 'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴩꞯʀꜱᴛᴜᴠᴡxʏᴢ';
        const i = map.indexOf(c);
        return i >= 0 ? sc[i] : c.toLowerCase();
      }).join(''),
      'ꜰᴜʟʟ ᴡɪᴅᴛʜ': (t) => t.split('').map(c => {
        const map = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        const fw = 'ａｂｃｄｅｆｇｈｉｊｋｌｍｎｏｐｑｒｓｔｕｖｗｘｙｚＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸＹＺ０１２３４５６７８９';
        const i = map.indexOf(c);
        return i >= 0 ? fw[i] : c;
      }).join(''),
      '𝐹𝓇𝒶𝒸𝓉𝓊𝓇': (t) => t.split('').map(c => {
        const map = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const fr = '𝒶𝒷𝒸𝒹𝑒𝒻𝑔𝒽𝒾𝒿𝓀𝓁𝓂𝓃𝑜𝓅𝓆𝓇𝓈𝓉𝓊𝓋𝓌𝓍𝓎𝓏𝒜𝐵𝒞𝒟𝐸𝐹𝒢𝐻𝐼𝒥𝒦𝐿𝑀𝒩𝒪𝒫𝒬𝑅𝒮𝒯𝒰𝒱𝒲𝒳𝒴𝒵';
        const i = map.indexOf(c);
        return i >= 0 ? fr[i] : c;
      }).join('')
    };

    let result = `✨ *TEXTO ESPECIAL* ✨\n\n▸ Original: _${text}_\n\n`;
    
    for (const [nome, fn] of Object.entries(estilos)) {
      try {
        const transformed = fn(text);
        if (transformed !== text) {
          result += `▸ ${nome}: ${transformed}\n\n`;
        }
      } catch {}
    }

    result += `_✨ Nel-Aviso-Bot-Moz_`;
    return msg.reply(result);
  }
};
