import fetch from 'node-fetch';

export default {
  command: ['fakechat', 'falso', 'fakeWA', 'conversafalsa'],
  category: 'diversao',
  description: 'Criar uma conversa falsa de WhatsApp 📱',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    if (!text || !text.includes('|')) {
      return msg.reply(
        `📱 *FAKE CHAT* 📱\n\n` +
        `◈ Crie uma conversa falsa de WhatsApp!\n\n` +
        `✎ Formato: *${usedPrefix + command} nome|mensagem*\n\n` +
        `✎ Exemplo:\n` +
        `▸ *${usedPrefix + command} Maria|Oi tudo bem?*\n` +
        `▸ *${usedPrefix + command} João|Vou chegar atrasado!|20:30*`
      );
    }

    const parts = text.split('|');
    const nome = parts[0]?.trim() || 'Pessoa';
    const mensagem = parts[1]?.trim() || 'Olá!';
    const hora = parts[2]?.trim() || new Date().toLocaleTimeString('pt-MZ', { hour: '2-digit', minute: '2-digit' });

    await msg.react('⏳');

    try {
      const apiUrl = `https://api.yuki-wabot.my.id/api/fakechat?name=${encodeURIComponent(nome)}&message=${encodeURIComponent(mensagem)}&time=${encodeURIComponent(hora)}&apikey=NelBot-WD`;
      const response = await fetch(apiUrl);
      
      if (!response.ok) {
        // Fallback: criar texto formatado
        return msg.reply(
          `📱 *CONVERSA FALSA* 📱\n\n` +
          `┌───────────────────┐\n` +
          `│ 🟢 ${nome}\n` +
          `│ ─────────────────\n` +
          `│ 💬 ${mensagem}\n` +
          `│ 🕐 ${hora} ✓✓\n` +
          `└───────────────────┘\n\n` +
          `_📱 Nel-Aviso-Bot_`
        );
      }
      
      const buffer = await response.buffer();
      await sock.sendMessage(msg.chat, {
        image: buffer,
        caption: `📱 *Fake Chat de ${nome}*\n\n_Nel-Aviso-Bot-Moz_ 🇲🇿`
      }, { quoted: msg });

      await msg.react('✅');
    } catch (e) {
      // Fallback em texto
      return msg.reply(
        `📱 *CONVERSA FALSA* 📱\n\n` +
        `┌───────────────────┐\n` +
        `│ 🟢 ${nome}\n` +
        `│ ─────────────────\n` +
        `│ 💬 ${mensagem}\n` +
        `│ 🕐 ${hora} ✓✓\n` +
        `└───────────────────┘\n\n` +
        `_📱 Nel-Aviso-Bot_`
      );
    }
  }
};
