import fetch from 'node-fetch';
import axios from 'axios';
import db from '#db';

export default {
  command: ['claude', 'claudeai', 'anthropic'],
  category: 'ia',
  description: 'Pergunta algo ao Claude AI da Anthropic',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const text = args.join(' ').trim();
    if (!text) {
      return msg.reply(`❧ Escreva uma *pergunta* para o *Claude AI* responder.\n\n▸ Exemplo: *${usedPrefix + command} Explique-me a teoria da relatividade*`);
    }
    const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    const settings = db.getSettings(botId);
    const user = db.getUser(msg.sender);
    const username = user?.name || 'usuário';
    const botname = settings.botname || 'Bot';
    const basePrompt = `O teu nome é ${botname}. Tu usas o idioma Português (Português de Moçambique). Responde SEMPRE em Português. Sê detalhado e preciso. ${username}`;

    try {
      const { key } = await sock.sendMessage(msg.chat, { text: `⏳ *Claude AI* está a processar...` }, { quoted: msg });
      await msg.react('🟠');
      let responseText = null;

      // Método 1: API siputzx com modelo claude
      try {
        const requestBody = { content: text, user: msg.sender, prompt: basePrompt, model: 'claude' };
        const res = await axios.post('https://ai.siputzx.my.id', requestBody);
        if (res.data?.result) responseText = res.data.result;
      } catch {}

      // Método 2: API delirius
      if (!responseText) {
        try {
          const res = await fetch(`${global.APIs.delirius.url}/ia/claude?text=${encodeURIComponent(text)}`);
          const json = await res.json();
          if (json?.status && json?.data) responseText = json.data;
        } catch {}
      }

      // Método 3: API ootaizumi
      if (!responseText) {
        try {
          const res = await fetch(`${global.APIs.ootaizumi.url}/ai/claude?text=${encodeURIComponent(text)}`);
          const json = await res.json();
          if (json?.status && json?.result) responseText = json.result;
        } catch {}
      }

      if (!responseText) {
        return sock.sendMessage(msg.chat, { text: '❧ Não foi possível obter resposta do *Claude AI*.', edit: key }, { quoted: msg });
      }

      await sock.sendMessage(msg.chat, { text: responseText.trim(), edit: key }, { quoted: msg });
      await msg.react('✅');
    } catch (e) {
      await msg.reply(`> Ocorreu um erro ao executar *${usedPrefix + command}*.\n> [Erro: *${e.message}*]`);
    }
  },
};
