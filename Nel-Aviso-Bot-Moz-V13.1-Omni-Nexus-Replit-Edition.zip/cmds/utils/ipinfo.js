// ╔══════════════════════════════════════════════════════════════╗
//   NEL-AVISO-BOT-MOZ · cmds/utils/ipinfo.js
//   IP Info — Informações detalhadas de um endereço IP
// ╚══════════════════════════════════════════════════════════════╝

export const command = {
  name: 'ipinfo',
  aliases: ['ip', 'iplookup', 'iplocalizar', 'geolocalizar', 'ipcheck'],
  description: 'Informações detalhadas de um endereço IP (localização, ISP, etc.)',
  category: 'utilidades',
  usage: '.ipinfo <endereço IP>',
  example: '.ipinfo 8.8.8.8'
};

export default async function ({ sock, msg, args, from, sender, config }) {
  const ip = args[0];
  if (!ip) {
    return sock.sendMessage(from, {
      text: '❌ Fornece um endereço IP!\n\n💡 *Uso:* .ipinfo <IP>\n📌 *Ex:* .ipinfo 8.8.8.8'
    }, { quoted: msg });
  }

  // Validar formato de IP
  const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
  if (!ipRegex.test(ip)) {
    return sock.sendMessage(from, {
      text: '❌ Formato de IP inválido! Use formato: 0.0.0.0'
    }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '🌐', key: msg.key } });

  try {
    // Delirius Tools — /tools/ipinfo
    const res = await fetch(`https://api.delirius.store/tools/ipinfo?ip=${ip}`);
    const data = await res.json();

    if (data?.status === 200 && data?.result) {
      const r = data.result;
      const info = `🌐 *IP INFO* — \`${ip}\`

━━━━━━━━━━━━━━━━━━━━

📍 *Localização:*
  • País: ${r.country || 'N/A'} ${r.countryCode ? `(${r.countryCode})` : ''}
  • Região: ${r.regionName || 'N/A'} ${r.region ? `[${r.region}]` : ''}
  • Cidade: ${r.city || 'N/A'}
  • Código Postal: ${r.zip || 'N/A'}
  • Latitude: ${r.lat || 'N/A'}
  • Longitude: ${r.lon || 'N/A'}

🔌 *Conexão:*
  • ISP: ${r.isp || 'N/A'}
  • Organização: ${r.org || 'N/A'}
  • AS: ${r.as || 'N/A'}
  • Timezone: ${r.timezone || 'N/A'}

🛡️ *Outros:*
  • Hostname: ${r.hostname || 'N/A'}
  • Anycast: ${r.anycast ? '✅ Sim' : '❌ Não'}
  • Proxy: ${r.proxy ? '⚠️ Detectado' : '✅ Não detectado'}
  • Mobile: ${r.mobile ? '📱 Sim' : '🖥️ Não'}
  • Hosting: ${r.hosting ? '🏢 Sim' : '🏠 Não'}`;

      await sock.sendMessage(from, {
        text: info,
        contextInfo: {
          externalAdReply: {
            title: `IP Lookup: ${ip}`,
            body: `${r.city || '?'}, ${r.country || '?'}`,
            thumbnailUrl: 'https://cdn-icons-png.flaticon.com/512/2920/2920349.png',
            mediaType: 1
          }
        }
      }, { quoted: msg });
      return;
    }
  } catch (e) {
    console.log('IP info primary failed:', e.message);
  }

  // Fallback — ip-api.com (gratuito)
  try {
    const res = await fetch(`http://ip-api.com/json/${ip}?fields=status,country,countryCode,region,regionName,city,zip,lat,lon,timezone,isp,org,as,hosting,mobile,proxy,query`);
    const r = await res.json();

    if (r.status === 'success') {
      const info = `🌐 *IP INFO* — \`${ip}\`

━━━━━━━━━━━━━━━━━━━━

📍 *Localização:*
  • País: ${r.country || 'N/A'} (${r.countryCode || '?'})
  • Região: ${r.regionName || 'N/A'} [${r.region || '?'}]
  • Cidade: ${r.city || 'N/A'}
  • Código Postal: ${r.zip || 'N/A'}
  • Coordenadas: ${r.lat}, ${r.lon}

🔌 *Conexão:*
  • ISP: ${r.isp || 'N/A'}
  • Organização: ${r.org || 'N/A'}
  • AS: ${r.as || 'N/A'}
  • Timezone: ${r.timezone || 'N/A'}

🛡️ *Detecções:*
  • Proxy: ${r.proxy ? '⚠️ Sim' : '✅ Não'}
  • Mobile: ${r.mobile ? '📱 Sim' : '🖥️ Não'}
  • Hosting: ${r.hosting ? '🏢 Sim' : '🏠 Não'}`;

      await sock.sendMessage(from, { text: info }, { quoted: msg });
      return;
    }
  } catch (e) {
    console.log('IP info fallback failed:', e.message);
  }

  await sock.sendMessage(from, {
    text: '❌ Não consegui obter informações sobre esse IP. Verifica se o endereço está correto.'
  }, { quoted: msg });
}
