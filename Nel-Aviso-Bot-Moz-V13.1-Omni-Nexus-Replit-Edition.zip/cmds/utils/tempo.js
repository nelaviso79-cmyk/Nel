export default {
  command: ['tempo', 'horamundo', 'worldtime', 'quehoras'],
  category: 'utilidades',
  description: 'Ver hora em qualquer fuso horário do mundo 🌍',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    const timezones = {
      'maputo': 'Africa/Maputo', 'beira': 'Africa/Maputo', 'nampula': 'Africa/Maputo',
      'mozambique': 'Africa/Maputo', 'mocambique': 'Africa/Maputo',
      'sao paulo': 'America/Sao_Paulo', 'rio': 'America/Sao_Paulo', 'brasil': 'America/Sao_Paulo',
      'lisboa': 'Europe/Lisbon', 'portugal': 'Europe/Lisbon',
      'londres': 'Europe/London', 'inglaterra': 'Europe/London',
      'nova york': 'America/New_York', 'eua': 'America/New_York',
      'los angeles': 'America/Los_Angeles',
      'toquio': 'Asia/Tokyo', 'japao': 'Asia/Tokyo',
      'pequim': 'Asia/Shanghai', 'china': 'Asia/Shanghai',
      'dubai': 'Asia/Dubai', 'emirados': 'Asia/Dubai',
      'paris': 'Europe/Paris', 'franca': 'Europe/Paris',
      'berlim': 'Europe/Berlin', 'alemanha': 'Europe/Berlin',
      'moscou': 'Europe/Moscow', 'russia': 'Europe/Moscow',
      'sydney': 'Australia/Sydney', 'australia': 'Australia/Sydney',
      'india': 'Asia/Kolkata', 'mumbai': 'Asia/Kolkata',
      'cairo': 'Africa/Cairo', 'egito': 'Africa/Cairo',
      'nairobi': 'Africa/Nairobi', 'kenya': 'Africa/Nairobi',
      'joanesburgo': 'Africa/Johannesburg', 'africa do sul': 'Africa/Johannesburg',
      'bangkok': 'Asia/Bangkok', 'tailandia': 'Asia/Bangkok',
      'seul': 'Asia/Seoul', 'coreia': 'Asia/Seoul',
    };

    if (!text) {
      // Show time in major cities
      const cities = ['Maputo', 'São Paulo', 'Lisboa', 'Londres', 'Nova York', 'Dubai', 'Toquio', 'Sydney'];
      const tzMap = ['Africa/Maputo', 'America/Sao_Paulo', 'Europe/Lisbon', 'Europe/London', 'America/New_York', 'Asia/Dubai', 'Asia/Tokyo', 'Australia/Sydney'];

      let result = `🌍 *HORA NO MUNDO*\n\n`;
      for (let i = 0; i < cities.length; i++) {
        const time = new Date().toLocaleTimeString('pt-BR', { timeZone: tzMap[i], hour: '2-digit', minute: '2-digit', second: '2-digit' });
        const date = new Date().toLocaleDateString('pt-BR', { timeZone: tzMap[i], weekday: 'long', day: 'numeric', month: 'long' });
        result += `🕐 ${cities[i]}: *${time}*\n   ${date}\n\n`;
      }
      result += `\n✳️ Use: ${usedPrefix}${command} <cidade> para ver hora específica`;
      return await sock.sendMessage(msg.key.remoteJid, { text: result }, { quoted: msg });
    }

    const city = text.toLowerCase().trim();
    const tz = timezones[city];
    if (!tz) {
      let available = Object.keys(timezones).filter(k => !k.includes(' ')).join(', ');
      return await sock.sendMessage(msg.key.remoteJid, { text: `❌ Cidade não encontrada!\n\nCidades disponíveis: ${available}` }, { quoted: msg });
    }

    const time = new Date().toLocaleTimeString('pt-BR', { timeZone: tz, hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const date = new Date().toLocaleDateString('pt-BR', { timeZone: tz, weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
    const offset = new Date().toLocaleTimeString('pt-BR', { timeZone: tz, timeZoneName: 'short' }).split(' ').pop();

    let result = `🕐 *HORA EM ${text.toUpperCase()}*\n\n`;
    result += `⏰ Hora: *${time}*\n`;
    result += `📅 Data: *${date}*\n`;
    result += `🌐 Fuso: *${offset}*\n`;

    await sock.sendMessage(msg.key.remoteJid, { text: result }, { quoted: msg });
  }
};
