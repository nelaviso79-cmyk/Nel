export default {
  command: ['emergencia', 'emergências', 'urgente', 'socorro', 'sos'],
  category: 'utilidades',
  description: 'Números de emergência de Moçambique 🚨',
  run: async ({ msg, sock, usedPrefix, command }) => {
    return msg.reply(
      `🚨 *EMERGÊNCIAS MOÇAMBIQUE* 🚨\n\n` +
      `━━━━━━━━━━━━━━━━━━━━\n\n` +
      `▸ 🚔 Polícia: *119*\n` +
      `▸ 🚑 Ambulância: *117*\n` +
      `▸ 🚒 Bombeiros: *198*\n` +
      `▸ ⚡ Electricidade: *840*\n` +
      `▸ 💧 Água (FIPAG): *801*\n` +
      `▸ 🛣️ Estradas: *8011*\n` +
      `▸ ☠️ Intoxicação: *115*\n\n` +
      `━━━━━━━━━━━━━━━━━━━━\n\n` +
      `▸ 📱 Vodacom: *8411 111 111*\n` +
      `▸ 📱 Movitel: *861 111 111*\n` +
      `▸ 📱 Mcell: *821 111 000*\n\n` +
      `━━━━━━━━━━━━━━━━━━━━\n\n` +
      `▸ 🌊 INAMET (Meteo): *2149 2000*\n` +
      `▸ 🦠 Saúde (MISAU): *21 42 12 00*\n` +
      `▸ 👩 Violência Doméstica: *116*\n` +
      `▸ 🧒 Linha da Criança: *116*\n\n` +
      `_🇲🇿 Nel-Aviso-Bot-Moz_`
    );
  }
};
