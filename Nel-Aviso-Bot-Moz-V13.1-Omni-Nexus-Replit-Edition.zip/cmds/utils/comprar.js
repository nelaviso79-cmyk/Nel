/**
 * ╔════════════════════════════════════════════════════════════════════╗
 * ║  🛒 SISTEMA DE COMPRAS — Registo + Ranking + Histórico            ║
 * ║  Regista cada compra validada por comprovativo M-Pesa/E-Mola       ║
 * ║  Ranking de maiores compradores com bónus                          ║
 * ╚════════════════════════════════════════════════════════════════════╝
 */

import db from '#db';

// ═══════════════════════════════════════════════════════
// TABELA DE PACOTES — Mapeia valor MT → MB
// (Baseado no menu NEL NET Express)
// ═══════════════════════════════════════════════════════
const PACOTES = {
  // Diários
  5: 200, 10: 400, 15: 600, 20: 800, 22: 850, 25: 1024,
  30: 1200, 35: 1400, 40: 1600, 45: 1850, 50: 2048,
  55: 2150, 65: 2800, 75: 3072, 80: 3300, 100: 4096,
  130: 5120, 255: 10240,
  // Mensais
  185: 6042, 190: 6144, 220: 7168, 280: 10752,
  450: 17613, 870: 36454, 1800: 73216
};

function mbToReadable(mb) {
  if (mb >= 1024) return (mb / 1024).toFixed(2) + 'GB';
  return mb + 'MB';
}

function getMegasForValor(valor) {
  if (!valor) return null;
  // Procura correspondência exata
  if (PACOTES[valor]) return PACOTES[valor];
  // Procura a mais próxima (margem de 2 MT)
  const keys = Object.keys(PACOTES).map(Number).sort((a, b) => a - b);
  for (const k of keys) {
    if (Math.abs(k - valor) <= 2) return PACOTES[k];
  }
  // Se não encontrar, calcular proporcionalmente (base: 25MT = 1024MB)
  return Math.round(valor * 1024 / 25);
}

function getTodayStr() {
  return new Date().toLocaleDateString('pt-MZ', { timeZone: 'Africa/Maputo', year: 'numeric', month: '2-digit', day: '2-digit' }).split('/').reverse().join('-');
}

function getNowMaputo() {
  return new Date().toLocaleString('pt-MZ', { timeZone: 'Africa/Maputo', hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit', year: 'numeric' });
}

/**
 * Obtém o registo de compras de um grupo (do DB)
 */
function getComprasGrupo(chatId) {
  const chat = db.getChat(chatId) || {};
  if (!chat.compras) chat.compras = { totalGeral: 0, compradores: {} };
  return chat.compras;
}

/**
 * Guarda o registo de compras no DB
 */
function saveComprasGrupo(chatId, compras) {
  db.updateChatSetting(chatId, 'compras', compras);
}

/**
 * Regista uma nova compra
 */
function registarCompra(chatId, sender, nome, valorMT, megas) {
  const compras = getComprasGrupo(chatId);
  const today = getTodayStr();
  const phone = sender.split('@')[0];

  if (!compras.compradores[phone]) {
    compras.compradores[phone] = {
      nome: nome || phone,
      totalMT: 0,
      totalMB: 0,
      totalCompras: 0,
      primeiraCompra: new Date().toISOString(),
      ultimaCompra: null,
      comprasHoje: 0,
      ultimoDia: null,
      historico: []
    };
  }

  const comp = compras.compradores[phone];
  comp.nome = nome || comp.nome || phone;
  comp.totalMT += valorMT;
  comp.totalMB += megas;
  comp.totalCompras += 1;
  comp.ultimaCompra = new Date().toISOString();

  // Reset diário
  if (comp.ultimoDia !== today) {
    comp.comprasHoje = 0;
    comp.ultimoDia = today;
  }
  comp.comprasHoje += 1;

  // Histórico (últimas 20)
  comp.historico.push({
    data: getNowMaputo(),
    valor: valorMT,
    megas: megas,
    tipo: valorMT >= 185 ? 'mensal' : 'diário'
  });
  if (comp.historico.length > 20) comp.historico = comp.historico.slice(-20);

  // Total geral do grupo
  compras.totalGeral = (compras.totalGeral || 0) + valorMT;

  saveComprasGrupo(chatId, compras);
  return comp;
}

/**
 * Obtém o ranking de compradores
 */
function getRanking(chatId, limite = 10) {
  const compras = getComprasGrupo(chatId);
  const entries = Object.entries(compras.compradores || {});
  entries.sort((a, b) => b[1].totalMB - a[1].totalMB);
  return entries.slice(0, limite);
}

/**
 * Gera mensagem de confirmação de compra (estilo do exemplo)
 */
function gerarMensagemCompra(nome, megas, compradores, ranking) {
  const totalReadable = mbToReadable(megas);
  const posicao = ranking.findIndex(([phone]) => phone === nome?.replace(/\D/g, '') || nome) + 1 || compradores.length;
  const maiorComprador = ranking.length > 0 ? ranking[0] : null;
  const maiorMB = maiorComprador ? maiorComprador[1].totalMB : 0;
  const comprador = compradores[nome?.replace(/\D/g, '')] || Object.values(compradores).find(c => c.nome === nome) || null;
  const comprasHoje = comprador?.comprasHoje || 1;
  const totalAcumulado = comprador?.totalMB || megas;

  const primeiraCompra = comprasHoje <= 1;

  let msg = `Obrigado @${nome || 'cliente'} por comprar *${megas >= 1024 ? mbToReadable(megas) : megas + 'MB'}*!\n\n`;

  if (primeiraCompra) {
    msg += `🌟 Você está fazendo a sua *primeira compra do dia*!\n\n`;
  } else {
    msg += `🔄 Esta é a sua *${comprasHoje}ª compra do dia*!\n\n`;
  }

  msg += `Você é o comprador nº *${posicao}* do grupo, com um total acumulado de *${mbToReadable(totalAcumulado)}*.\n`;

  if (maiorComprador && maiorMB > totalAcumulado) {
    msg += `O maior comprador já acumulou *${mbToReadable(maiorMB)}*.\n`;
    msg += `🏆 Rumo ao topo para desbloquear bônus!\n`;
  } else if (maiorComprador && totalAcumulado >= maiorMB) {
    msg += `👑 *Você é o MAIOR comprador do grupo!* Parabéns!\n`;
  }

  // Bônus por posição
  if (posicao === 1) msg += `\n🎁 Bônus de líder: +50MB grátis!`;
  else if (posicao === 2) msg += `\n🎁 Bônus de vice: +25MB grátis!`;
  else if (posicao === 3) msg += `\n🎁 Bônus de top 3: +10MB grátis!`;

  return msg;
}

export default {
  command: ['comprar', 'regcompra', 'registrarcompra', 'compra'],
  category: 'pagamentos',
  description: 'Registar compra de pacote de dados',
  run: async ({ msg, sock, args, usedPrefix, command, sender, pushname, from, isOwner, isAdmins }) => {
    const subcmd = (args[0] || '').toLowerCase();

    // ═══ AJUDA ═══
    if (!subcmd || subcmd === 'ajuda' || subcmd === 'help') {
      return msg.reply(
        `┌──「 🛒 *SISTEMA DE COMPRAS* 」\n│\n` +
        `│ 📋 *Comandos:*\n│\n` +
        `│ ▸ *${usedPrefix}comprar <valorMT>* — Registar compra\n` +
        `│   Ex: *${usedPrefix}comprar 25*\n` +
        `│\n` +
        `│ ▸ *${usedPrefix}comprar confirmar <valorMT> <número>*\n` +
        `│   (Admin confirma compra de cliente)\n` +
        `│\n` +
        `│ ▸ *${usedPrefix}ranking* — Ver ranking de compradores\n` +
        `│ ▸ *${usedPrefix}minhascompras* — Ver tuas compras\n` +
        `│ ▸ *${usedPrefix}historicocompras* — Histórico do grupo\n` +
        `│\n` +
        `│ 💡 Comprovativos M-Pesa são detectados\n` +
        `│ automaticamente! Basta enviar o comprovativo.\n` +
        `└───────────────`
      );
    }

    // ═══ REGISTAR COMPRA PRÓPRIA ═══
    const valorNum = parseFloat(subcmd);
    if (!isNaN(valorNum) && valorNum > 0) {
      const megas = getMegasForValor(valorNum);
      if (!megas) return msg.reply(`❌ Valor *${valorNum}MT* não corresponde a nenhum pacote. Use *${usedPrefix}megas* para ver os pacotes.`);

      const phone = sender.split('@')[0];
      const nome = pushname || phone;

      // Verificar se é admin a confirmar para outro
      const targetPhone = args[1]?.replace(/\D/g, '');
      let targetSender = sender;
      let targetNome = nome;

      if (targetPhone && (isOwner || isAdmins)) {
        targetSender = targetPhone + '@s.whatsapp.net';
        targetNome = args.slice(2).join(' ') || targetPhone;
      }

      const comp = registarCompra(from, targetSender, targetNome, valorNum, megas);
      const ranking = getRanking(from);
      const compras = getComprasGrupo(from);
      const msgCompra = gerarMensagemCompra(targetNome, megas, compras.compradores, ranking);

      let r = `┌──「 🛒 *COMPRA REGISTADA* 」\n│\n`;
      r += `│ ✅ ${msgCompra.split('\n').join('\n│ ')}\n│\n`;
      r += `│ 💵 Valor: *${valorNum.toFixed(2)} MT*\n`;
      r += `│ 📦 Pacote: *${megas >= 1024 ? mbToReadable(megas) : megas + 'MB'}*\n`;
      r += `│ 📊 Total acumulado: *${mbToReadable(comp.totalMB)}*\n`;
      r += `│ 🛒 Total de compras: *${comp.totalCompras}*\n`;
      r += `│\n└───────────────`;

      const mentions = targetPhone ? [targetSender] : [];
      return sock.sendMessage(msg.chat, { text: r, mentions }, { quoted: msg });
    }

    // ═══ CONFIRMAR COMPRA (Admin) ═══
    if (subcmd === 'confirmar' || subcmd === 'confirm') {
      if (!isOwner && !isAdmins) {
        return msg.reply(`⚠️ Apenas admins podem confirmar compras.`);
      }
      const valor = parseFloat(args[1]);
      const numero = args[2]?.replace(/\D/g, '');

      if (isNaN(valor) || valor <= 0) return msg.reply(`⚠️ Especifique o valor. Ex: *${usedPrefix}comprar confirmar 25 858457134*`);
      if (!numero || numero.length < 9) return msg.reply(`⚠️ Especifique o número. Ex: *${usedPrefix}comprar confirmar 25 858457134*`);

      const megas = getMegasForValor(valor);
      const targetSender = numero + '@s.whatsapp.net';
      const comp = registarCompra(from, targetSender, numero, valor, megas);
      const ranking = getRanking(from);
      const compras = getComprasGrupo(from);

      let r = `┌──「 ✅ *COMPRA CONFIRMADA* 」\n│\n`;
      r += `│ 📱 Cliente: *@${numero}*\n`;
      r += `│ 💵 Valor: *${valor.toFixed(2)} MT*\n`;
      r += `│ 📦 Pacote: *${megas >= 1024 ? mbToReadable(megas) : megas + 'MB'}*\n`;
      r += `│ 📊 Acumulado: *${mbToReadable(comp.totalMB)}*\n`;
      r += `│ 🛒 Compras totais: *${comp.totalCompras}*\n`;
      r += `│\n`;
      r += `│ ${comp.comprasHoje <= 1 ? '🌟 Primeira compra do dia!' : '🔄 ' + comp.comprasHoje + 'ª compra do dia'}\n`;
      r += `└───────────────`;

      return sock.sendMessage(msg.chat, { text: r, mentions: [targetSender] }, { quoted: msg });
    }

    // ═══ DEFAULT ═══
    return msg.reply(`⚠️ Use *${usedPrefix}comprar <valorMT>* para registar uma compra.\nEx: *${usedPrefix}comprar 25*\n\n📋 *${usedPrefix}comprar ajuda* para mais opções.`);
  }
};
