import fetch from 'node-fetch';
import uploadImage from '#uploadImage';

export default {
  command: ['wanted', 'procurado', 'cartaz'],
  category: 'diversao',
  description: 'Cria um cartaz de procurado com a foto de alguém.',
  run: async ({ msg, sock, usedPrefix, command }) => {
    const q = msg.quoted || msg;
    const mime = (q.msg || q).mimetype || '';
    
    if (!/image/.test(mime)) return msg.reply(`❌ Responde a uma imagem ou envia uma foto com *${usedPrefix + command}* para criar o cartaz.`);

    await msg.react('🤠');
    try {
      const media = await q.download();
      const imageUrl = await uploadImage(media, mime);
      
      const api = `https://api.vreden.web.id/api/canvas/wanted?url=${encodeURIComponent(imageUrl)}`;
      const res = await fetch(api);
      
      if (!res.ok) throw new Error('Falha na API de Canvas');
      
      const buffer = Buffer.from(await res.arrayBuffer());

      await sock.sendMessage(msg.chat, {
        image: buffer,
        caption: `🤠 *PROCURADO: VIVO OU MORTO*\n\n> 💰 Recompensa: 1,000,000 MT\n> 👤 Alvo: ${msg.pushName}\n\n_Gerado por Nel-Aviso-Bot_`
      }, { quoted: msg });
      
      await msg.react('✅');
    } catch (e) {
      console.error(e);
      await msg.react('❌');
      await msg.reply(`❌ Erro ao gerar cartaz. Tenta novamente mais tarde.\n> [Erro: ${e.message}]`);
    }
  }
};
