/**
 * 📖 DICIONÁRIO — Buscar definição de palavras
 */
import fetch from 'node-fetch';

export default {
  command: ['dicionario', 'define', 'definir', 'significado', 'definicao'],
  category: 'utilidades',
  description: 'Buscar definição de palavras 📖',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const word = args.join(' ').trim();
    if (!word) return msg.reply(`❌ Use: *${usedPrefix}${command} <palavra>*\nEx: *${usedPrefix}dicionario amor*`);

    try {
      let definition = null;

      // API 1: dicio.com.br (PT-BR)
      try {
        const res = await fetch(`https://api.delirius.store/search/dictionary?word=${encodeURIComponent(word)}`);
        const data = await res.json();
        if (data.status && data.result) definition = data.result;
      } catch {}

      // API 2: Free Dictionary API (EN)
      if (!definition) {
        try {
          const res = await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(word)}`);
          const data = await res.json();
          if (Array.isArray(data) && data[0]) {
            const entry = data[0];
            definition = {
              word: entry.word,
              phonetic: entry.phonetic,
              meaning: entry.meanings?.[0]?.definitions?.[0]?.definition,
              example: entry.meanings?.[0]?.definitions?.[0]?.example,
              partOfSpeech: entry.meanings?.[0]?.partOfSpeech,
              language: 'Inglês'
            };
          }
        } catch {}
      }

      if (!definition) return msg.reply(`❌ Palavra "${word}" não encontrada.`);

      let r = `📖 *DICIONÁRIO* 📖\n\n`;
      r += `🔍 *${definition.word || word}*\n`;
      if (definition.phonetic || definition.pronuncia) r += `🔊 ${definition.phonetic || definition.pronuncia}\n`;
      if (definition.partOfSpeech || definition.classe) r += `📝 ${definition.partOfSpeech || definition.classe}\n\n`;
      r += `📋 *Definição:*\n${definition.meaning || definition.significado || definition.definition}\n`;
      if (definition.example || definition.exemplo) r += `\n💡 *Exemplo:* ${definition.example || definition.exemplo}\n`;
      if (definition.etymology || definition.etimologia) r += `\n📜 *Etimologia:* ${definition.etymology || definition.etimologia}\n`;
      if (definition.language) r += `\n🌐 Idioma: ${definition.language}`;

      await msg.reply(r.trim());
    } catch (e) {
      msg.reply(`❌ Erro ao buscar definição.`);
    }
  }
};
