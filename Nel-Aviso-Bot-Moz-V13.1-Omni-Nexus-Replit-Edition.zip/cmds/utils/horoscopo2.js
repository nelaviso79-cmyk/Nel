/**
 * 🔮 HORÓSCOPO DETALHADO — Horóscopo com previsão completa
 */
import fetch from 'node-fetch';

const SIGNOS = {
  aries: 'Áries', touro: 'Touro', gemeos: 'Gémeos', cancer: 'Câncer',
  leao: 'Leão', virgem: 'Virgem', libra: 'Libra', escorpiao: 'Escorpião',
  sagitario: 'Sagitário', capricornio: 'Capricórnio', aquario: 'Aquário',
  peixes: 'Peixes'
};
const SIGNOS_KEYS = Object.keys(SIGNOS);

export default {
  command: ['horoscopo2', 'horoscopodetalhado', 'horoscopofull', 'signodetalhado'],
  category: 'diversao',
  description: 'Horóscopo detalhado com previsão completa 🔮',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const signo = args[0]?.toLowerCase();

    if (!signo || !SIGNOS_KEYS.includes(signo)) {
      const lista = SIGNOS_KEYS.map(k => `• ${k} = ${SIGNOS[k]}`).join('\n');
      return msg.reply(`🔮 Use: *${usedPrefix}${command} <signo>*\n\n*Signos:*\n${lista}\n\nEx: *${usedPrefix}${command} leao*`);
    }

    try {
      let horoscopo = null;

      // API 1: delirius
      try {
        const res = await fetch(`https://api.delirius.store/other/horoscope?sign=${signo}`);
        const data = await res.json();
        if (data.status && data.result) horoscopo = data.result;
      } catch {}

      // API 2: siputzx
      if (!horoscopo) {
        try {
          const res = await fetch(`https://app.siputzx.my.id/api/entertainment/horoscope?sign=${signo}`);
          const data = await res.json();
          if (data.status && data.data) horoscopo = data.data;
        } catch {}
      }

      if (!horoscopo) return msg.reply(`❌ Não foi possível obter o horóscopo.`);

      let r = `🔮 *HORÓSCOPO — ${SIGNOS[signo]}* 🔮\n\n`;

      if (horoscopo.daily || horoscopo.description) {
        r += `📅 *Hoje:*\n${horoscopo.daily || horoscopo.description}\n\n`;
      }
      if (horoscopo.compatibility || horoscopo.compatibilidade) {
        r += `❤️ Compatibilidade: ${horoscopo.compatibility || horoscopo.compatibilidade}\n`;
      }
      if (horoscopo.mood || horoscopo.humor) {
        r += `😊 Humor: ${horoscopo.mood || horoscopo.humor}\n`;
      }
      if (horoscopo.lucky_number || horoscopo.numeroSorte) {
        r += `🔢 Número sorte: ${horoscopo.lucky_number || horoscopo.numeroSorte}\n`;
      }
      if (horoscopo.lucky_time || horoscopo.horaSorte) {
        r += `⏰ Hora sorte: ${horoscopo.lucky_time || horoscopo.horaSorte}\n`;
      }
      if (horoscopo.color || horoscopo.cor) {
        r += `🎨 Cor: ${horoscopo.color || horoscopo.cor}\n`;
      }

      // Se não tem detalhes, só mostra o que vier
      if (!horoscopo.daily && !horoscopo.description && typeof horoscopo === 'object') {
        for (const [k, v] of Object.entries(horoscopo)) {
          if (typeof v === 'string' && v.length > 5) {
            r += `• ${k}: ${v}\n`;
          }
        }
      }

      await msg.reply(r.trim());
    } catch (e) {
      msg.reply(`❌ Erro ao buscar horóscopo.`);
    }
  }
};
