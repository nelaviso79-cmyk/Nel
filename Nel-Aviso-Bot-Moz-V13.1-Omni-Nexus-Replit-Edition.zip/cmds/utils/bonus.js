import db from '#db';

export default {
  command: ['bonus', 'fidelidade', 'premios'],
  category: 'utilidades',
  description: 'Ver bónus e prémios de fidelidade Nel Net.',
  run: async ({ msg, users, usedPrefix }) => {
    const totalMB = users.totalMB || 0;
    const totalCompras = users.totalCompras || 0;
    
    let proxPremio = "";
    if (totalCompras < 5) proxPremio = `Faltam *${5 - totalCompras}* compras para o bónus de *200MB*!`;
    else if (totalCompras < 10) proxPremio = `Faltam *${10 - totalCompras}* compras para o bónus de *500MB*!`;
    else proxPremio = "Você é um cliente VIP! Fale com o suporte para bónus personalizados.";

    const texto = `🎁 *PROGRAMA DE FIDELIDADE NEL NET*
    
👤 Cliente: *@${msg.sender.split('@')[0]}*
📊 Compras Totais: *${totalCompras}*
📦 Volume Total: *${totalMB >= 1024 ? (totalMB/1024).toFixed(2)+'GB' : totalMB+'MB'}*

🎯 *Próximo Objetivo:*
${proxPremio}

💡 *Como ganhar?*
Cada compra registada automaticamente via M-Pesa/E-Mola conta para o seu ranking. Os top 3 do mês ganham pacotes grátis!

_Nel Aviso · Onde a net nunca para_`;

    return msg.reply(texto);
  }
};
