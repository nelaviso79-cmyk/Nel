export default {
  command: ['slot2', 'caçaníqueis', 'jackpot', 'slots777'],
  category: 'diversao',
  description: 'Máquina de caça-níqueis virtual 🎰',
  run: async ({ msg, sock, usedPrefix, command }) => {
    const simbolos = ['🍒', '🍋', '🍊', '🍇', '💎', '7️⃣', '⭐', '🔔', '💰'];
    
    const rolo1 = simbolos[Math.floor(Math.random() * simbolos.length)];
    const rolo2 = simbolos[Math.floor(Math.random() * simbolos.length)];
    const rolo3 = simbolos[Math.floor(Math.random() * simbolos.length)];
    
    let resultado = '';
    let multiplicador = 0;
    
    if (rolo1 === rolo2 && rolo2 === rolo3) {
      if (rolo1 === '7️⃣') {
        resultado = '🎰 JACKPOT! TRÊS 7s! 🎰';
        multiplicador = 77;
      } else if (rolo1 === '💎') {
        resultado = '💎 DIAMANTE TRIPLO! 💎';
        multiplicador = 50;
      } else {
        resultado = '🎉 TRIO IGUAL! 🎉';
        multiplicador = 25;
      }
    } else if (rolo1 === rolo2 || rolo2 === rolo3 || rolo1 === rolo3) {
      resultado = '👍 Par parcial! Quase lá!';
      multiplicador = 2;
    } else {
      const tem7 = [rolo1, rolo2, rolo3].includes('7️⃣');
      if (tem7) {
        resultado = '7️⃣ Sorte do 7! Pequena vitória!';
        multiplicador = 3;
      } else {
        resultado = '😅 Nada! Tente novamente!';
        multiplicador = 0;
      }
    }
    
    const animacao = [
      `🔄 Girando...`,
      `🔄 ${simbolos[Math.floor(Math.random()*simbolos.length)]} | ${simbolos[Math.floor(Math.random()*simbolos.length)]} | ${simbolos[Math.floor(Math.random()*simbolos.length)]}`,
      `🎰 ${rolo1} | ${rolo2} | ${rolo3}`
    ];
    
    return msg.reply(
      `🎰 *CAÇA-NÍQUEIS 777* 🎰\n\n` +
      `${animacao[0]}\n${animacao[1]}\n${animacao[2]}\n\n` +
      `▸ Resultado: ┃ ${rolo1} ┃ ${rolo2} ┃ ${rolo3} ┃\n\n` +
      `${resultado}\n` +
      `▸ Multiplicador: *x${multiplicador}*\n\n` +
      `_🎰 Nel-Aviso-Bot-Moz_`
    );
  }
};
