import fetch from 'node-fetch';
import axios from 'axios';
import db from '#db';

export default {
  command: ['blackbox', 'bb', 'blackboxai'],
  category: 'ia',
  description: 'Pergunta algo ao Blackbox AI - excelente para programação',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const text = args.join(' ').trim();
    if (!text) {
      return msg.reply(`❧ Escreva uma *pergunta* para o *Blackbox AI* responder.\n\n▸ Exemplo: *${usedPrefix + command} Como criar uma API em Node.js?*`);
    }
    const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    const settings = db.getSettings(botId);
    const user = db.getUser(msg.sender);
    const username = user?.name || 'usuário';
    const botname = settings.botname || 'Bot';

    try {
      const { key } = await sock.sendMessage(msg.chat, { text: `⏳ *Blackbox AI* está a processar...` }, { quoted: msg });
      await msg.react('⬛');
      let responseText = null;

      // Método 1: API delirius
      try {
        const res = await fetch(`${global.APIs.delirius.url}/ia/blackbox?text=${encodeURIComponent(text)}`);
        const json = await res.json();
        if (json?.status && json?.data) responseText = json.data;
      } catch {}

      // Método 2: API siputzx
      if (!responseText) {
        try {
          const requestBody = { content: text, user: msg.sender, model: 'blackbox' };
          const res = await axios.post('https://ai.siputzx.my.id', requestBody);
          if (res.data?.result) responseText = res.data.result;
        } catch {}
      }

      // Método 3: API ootaizumi
      if (!responseText) {
        try {
          const res = await fetch(`${global.APIs.ootaizumi.url}/ai/blackbox?text=${encodeURIComponent(text)}`);
          const json = await res.json();
          if (json?.status && json?.result) responseText = json.result;
        } catch {}
      }

      if (!responseText) {
        return sock.sendMessage(msg.chat, { text: '❧ Não foi possível obter resposta do *Blackbox AI*.', edit: key }, { quoted: msg });
      }

      const clean = responseText.trim();
      // Se contém código, enviar como documento
      if (/```/.test(clean) || /function\s|const\s|import\s|class\s|def\s/.test(clean)) {
        const ext = /```(\w+)/.exec(clean)?.[1] || 'js';
        const codeOnly = clean.replace(/```\w*\n?/g, '').trim();
        await sock.sendMessage(msg.chat, {
          document: Buffer.from(codeOnly),
          fileName: `blackbox_response.${ext === 'javascript' ? 'js' : ext === 'python' ? 'py' : ext}`,
          mimetype: 'text/plain',
          caption: `⬛ *Blackbox AI* - Resposta\n▸ Linguagem: ${ext}\n▸ Caracteres: ${codeOnly.length}`
        }, { quoted: msg });
      } else {
        await sock.sendMessage(msg.chat, { text: clean, edit: key }, { quoted: msg });
      }
      await msg.react('✅');
    } catch (e) {
      await msg.reply(`> Ocorreu um erro ao executar *${usedPrefix + command}*.\n> [Erro: *${e.message}*]`);
    }
  },
};
