export default {
  command: ['proverbio', 'ditado', 'provérbio'],
  category: 'diversao',
  description: 'Receber um provérbio moçambicano ou africano aleatório.',
  run: async ({ msg, sock, usedPrefix, command }) => {
    const proverbios = [
      '🦁 "Quando o leão envelhece, as moscas zumbem à sua volta." — Provérbio Moçambicano',
      '🌊 "A água que passa não volta ao mesmo lugar." — Provérbio Moçambicano',
      '🐜 "A formiga que trabalha, come. A que dorme, passa fome." — Provérbio Africano',
      '🌍 "Aquele que não conhece o caminho, pergunta. Aquele que conhece, caminha." — Provérbio Africano',
      '🌳 "A árvore que cai faz mais barulho do que a floresta que cresce." — Provérbio Africano',
      '🖐️ "Uma mão lavai outra, e as duas lavam o rosto." — Provérbio Moçambicano',
      '🏠 "A casa de um homem é o seu castelo, mas a casa de uma mulher é o seu reino." — Provérbio Africano',
      '🦅 "Quem quer voar com as águias, não deve pastar com as galinhas." — Provérbio Africano',
      '🌙 "A noite é mãe do dia. A dor é mãe da sabedoria." — Provérbio Moçambicano',
      '🔥 "O fogo que aquece também pode queimar." — Provérbio Africano',
      '🐫 "O camelo não vê a sua própria corcova, mas vê a do outro." — Provérbio Africano',
      '🌱 "A semente que plantas hoje, dará frutos amanhã." — Provérbio Moçambicano',
      '🤝 "O amigo não é aquele que te dá, mas aquele que te ensina a pescar." — Provérbio Africano',
      '🏃 "Quem corre sozinho, corre rápido. Quem corre junto, vai longe." — Provérbio Africano',
      '🧠 "A sabedoria não vem da idade, mas da experiência vivida." — Provérbio Moçambicano',
      '🐘 "O elefante não se incomoda com o mosquito." — Provérbio Africano',
      '☀️ "O sol nasce para todos, mas nem todos aproveitam a luz." — Provérbio Africano',
      '💧 "Uma gota de água não faz um rio, mas muitas gotas fazem um oceano." — Provérbio Moçambicano',
      '🎯 "Aquele que mira alto, não atira no chão." — Provérbio Africano',
      '🦶 "O caminho de mil quilómetros começa com um simples passo." — Provérbio Chinês (popular em Moçambique)',
    ];

    const proverbio = proverbios[Math.floor(Math.random() * proverbios.length)];
    return msg.reply(`❧ *Provérbi do Dia* 🌍\n\n${proverbio}\n\n▸ Usa *${usedPrefix + command}* para outro provérbio!`);
  },
};
