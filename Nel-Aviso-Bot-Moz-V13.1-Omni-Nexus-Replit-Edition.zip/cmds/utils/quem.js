export default {
  command: ['quem', 'quemxe', 'quemamigo', 'quemsera'],
  category: 'diversao',
  description: 'Quem no grupo é mais provável de... 🤔',
  run: async ({ msg, sock, usedPrefix, command, participants }) => {
    if (!msg.key.remoteJid.endsWith('@g.us')) return await sock.sendMessage(msg.key.remoteJid, { text: '❌ Apenas em grupos!' }, { quoted: msg });
    if (!participants || participants.length < 3) return await sock.sendMessage(msg.key.remoteJid, { text: '❌ Precisa de pelo menos 3 membros!' }, { quoted: msg });

    const perguntas = [
      'quem é mais provável de ficar famoso?',
      'quem é mais provável de ficar rico?',
      'quem é mais provável de dormir o dia todo?',
      'quem é mais provável de comer até não aguentar?',
      'quem é mais provável de viajar o mundo?',
      'quem é mais provável de se casar primeiro?',
      'quem é mais provável de ser presidente?',
      'quem é mais provável de ficar viral?',
      'quem é mais provável de vencer um reality show?',
      'quem é mais provável de fazer algo maluco?',
      'quem é mais provável de ser o mais engraçado?',
      'quem é mais provável de sobreviver numa ilha?',
      'quem é mais provável de se perder no mato?',
      'quem é mais provável de dormir no culto?',
      'quem é mais provável de mandar mensagem errada?',
      'quem é mais provável de esquecer o nome de alguém?',
      'quem é mais provável de comer escondido?',
      'quem é mais provável de dançar na rua?',
      'quem é mais provável de ficar online até tarde?',
      'quem é mais provável de ajudar todo mundo?',
    ];

    const pergunta = perguntas[Math.floor(Math.random() * perguntas.length)];
    const chosen = participants[Math.floor(Math.random() * participants.length)];

    let result = `🤔 *QUEM É MAIS PROVÁVEL...*\n\n`;
    result += `❓ "${pergunta}"\n\n`;
    result += `👉 @${chosen.split('@')[0]} !! 🎯\n\n`;
    result += `😂 É o que o destino diz!\n\n`;
    result += `🔄 *${usedPrefix}${command}* para outra pergunta!`;

    await sock.sendMessage(msg.key.remoteJid, {
      text: result,
      mentions: [chosen]
    }, { quoted: msg });
  }
};
