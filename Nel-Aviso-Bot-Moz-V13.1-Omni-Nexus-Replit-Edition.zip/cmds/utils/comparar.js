/**
 * 📱 COMPARAR — Comparar dois celulares/tabela de especificações
 */
import fetch from 'node-fetch';

export default {
  command: ['comparar', 'compare', 'celular', 'telemovel', 'phoneinfo', 'spec'],
  category: 'utilidades',
  description: 'Comparar especificações de telemóveis 📱',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const text = args.join(' ').trim();
    if (!text) return msg.reply(`❌ Use: *${usedPrefix}${command} <modelo>*\nEx: *${usedPrefix}celular Samsung A54*`);

    try {
      let phone = null;

      // API 1: delirius gsmarena
      try {
        const res = await fetch(`https://api.delirius.store/search/gsmarena?query=${encodeURIComponent(text)}`);
        const data = await res.json();
        if (data.status && data.result?.length) phone = data.result[0];
      } catch {}

      // API 2: phone specs via search
      if (!phone) {
        try {
          const res = await fetch(`https://api.delirius.store/search/gadgets?query=${encodeURIComponent(text)}`);
          const data = await res.json();
          if (data.status && data.result?.length) phone = data.result[0];
        } catch {}
      }

      if (!phone) return msg.reply(`❌ Não encontrei "${text}". Tente nome mais específico.`);

      let r = `📱 *${phone.name || phone.title || text}*\n\n`;

      const specs = phone.specifications || phone.specs || phone;
      if (typeof specs === 'object') {
        for (const [key, val] of Object.entries(specs)) {
          if (typeof val === 'string' && val.length > 0) {
            r += `• ${key}: ${val}\n`;
          } else if (Array.isArray(val)) {
            r += `• ${key}: ${val.join(', ')}\n`;
          }
        }
      }

      if (phone.image || phone.img || phone.thumbnail) {
        const imgUrl = phone.image || phone.img || phone.thumbnail;
        try {
          await sock.sendMessage(msg.chat, {
            image: { url: imgUrl },
            caption: r.substring(0, 1024)
          }, { quoted: msg });
          return;
        } catch {}
      }

      if (r.length > 4096) r = r.substring(0, 4096) + '...';
      await msg.reply(r.trim());
    } catch (e) {
      msg.reply(`❌ Erro ao buscar informações do telemóvel.`);
    }
  }
};
