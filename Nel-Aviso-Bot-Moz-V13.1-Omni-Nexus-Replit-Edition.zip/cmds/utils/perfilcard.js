// ╔══════════════════════════════════════════════════════════╗
//   NEL-AVISO-BOT-MOZ · cmds/utils/perfilcard.js
// ╚══════════════════════════════════════════════════════════╝

import fetch from 'node-fetch';
import db from '#db';

export default {
  command: ['perfilcard', 'profilecard', 'card', 'mycard', 'meucard'],
  category: 'perfil',
  description: 'Card visual do teu perfil com stats do bot 🎴',

  run: async ({ msg, sock, args, usedPrefix, command }) => {
    try {
      const target = msg.mentionedJid?.[0] || (msg.quoted?.sender) || msg.sender;
      const user = db.getUser(target) || {};
      const chat = db.getChat(msg.chat) || {};
      const isGroup = msg.isGroup;

      const name = user.name || target.split('@')[0];
      const level = user.level || 1;
      const xp = user.exp || user.xp || 0;
      const coins = user.money || user.coins || 0;
      const bank = user.bank || 0;
      const role = user.role || 'Membro';
      const gender = user.gender || '👤';
      const messageCount = user.messageCount || user.msgCount || 0;

      // Try to get profile picture
      let pfpUrl;
      try {
        pfpUrl = await sock.profilePictureUrl(target, 'image');
      } catch (e) {
        pfpUrl = 'https://i.ibb.co/kQ2H5mf/default-pfp.png';
      }

      await msg.reply(`⏳ A gerar card de perfil...`);

      // Primary: Delirius balcard
      const bgColors = [
        'https://i.ibb.co/4pKNPjM/bg1.jpg',
        'https://i.ibb.co/ZWy3gQf/bg2.jpg',
        'https://i.ibb.co/QY3L3kR/bg3.jpg'
      ];
      const bg = bgColors[Math.floor(Math.random() * bgColors.length)];

      const cardRes = await fetch(
        `https://api.delirius.store/canvas/balcard?` +
        `url=${encodeURIComponent(pfpUrl)}` +
        `&background=${encodeURIComponent(bg)}` +
        `&username=${encodeURIComponent(name)}` +
        `&discriminator=${encodeURIComponent(role)}` +
        `&money=${encodeURIComponent(coins.toLocaleString())}` +
        `&xp=${encodeURIComponent(xp.toLocaleString())}` +
        `&level=${encodeURIComponent(level)}`
      );

      if (cardRes.ok) {
        const contentType = cardRes.headers.get('content-type') || '';
        if (contentType.includes('image')) {
          const buffer = Buffer.from(await cardRes.arrayBuffer());
          await sock.sendMessage(msg.chat, {
            image: buffer,
            caption:
              `🎴 *PERFIL CARD* 🎴\n\n` +
              `👤 ${name}\n` +
              `⭐ Nível: *${level}*\n` +
              `✨ XP: *${xp.toLocaleString()}*\n` +
              `💰 Moedas: *${coins.toLocaleString()}*\n` +
              `🏦 Banco: *${bank.toLocaleString()}*\n` +
              `🏷 Cargo: *${role}*\n` +
              `${isGroup ? `💬 Mensagens: *${messageCount.toLocaleString()}*\n` : ''}` +
              `${gender !== '👤' ? `🏳️ Género: *${gender}*\n` : ''}`
          }, { quoted: msg });
          return;
        }

        const data = await cardRes.json();
        if (data.status && data.result) {
          const cardUrl = data.result.url || data.result.image || data.result;
          await sock.sendMessage(msg.chat, {
            image: { url: cardUrl },
            caption: `🎴 *PERFIL CARD* 🎴\n\n👤 ${name} | ⭐ Lv.${level} | 💰 ${coins.toLocaleString()}`
          }, { quoted: msg });
          return;
        }
      }

      // Fallback: Text-based profile card
      const xpBar = '█'.repeat(Math.min(Math.floor(xp / 100), 20)) + '░'.repeat(Math.max(20 - Math.floor(xp / 100), 0));
      const levelBar = '█'.repeat(Math.min(level, 20)) + '░'.repeat(Math.max(20 - level, 0));

      const text =
        `🎴 ═══════════════════ 🎴\n` +
        `     *PERFIL CARD*\n` +
        `🎴 ═══════════════════ 🎴\n\n` +
        `${gender} *${name}*\n` +
        `🏷 Cargo: *${role}*\n\n` +
        `⭐ Nível [${level}]\n${levelBar}\n\n` +
        `✨ XP [${xp.toLocaleString()}]\n${xpBar}\n\n` +
        `💰 Moedas: *${coins.toLocaleString()}*\n` +
        `🏦 Banco: *${bank.toLocaleString()}*\n` +
        `💬 Mensagens: *${messageCount.toLocaleString()}*\n\n` +
        `🎴 ═══════════════════ 🎴`;

      await msg.reply(text);

    } catch (e) {
      await msg.reply(`❌ Erro ao gerar card: *${e.message}*`);
    }
  }
};
