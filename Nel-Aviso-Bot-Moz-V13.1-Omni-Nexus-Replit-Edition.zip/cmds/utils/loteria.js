export default {
  command: ['loteria', 'lotto', 'sortenumero', 'numerosorte'],
  category: 'diversao',
  description: 'Gerar números da loteria/sorte 🎰',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    const types = {
      'mz': { name: 'Loteria de Moçambique', numbers: 5, max: 50, extra: 1, extraMax: 9, extraName: 'Chave' },
      'br': { name: 'Mega-Sena (Brasil)', numbers: 6, max: 60, extra: 0 },
      'eu': { name: 'EuroMilhões', numbers: 5, max: 50, extra: 2, extraMax: 12, extraName: 'Estrelas' },
      'us': { name: 'Powerball (EUA)', numbers: 5, max: 69, extra: 1, extraMax: 26, extraName: 'Powerball' },
    };

    const type = text && types[text.toLowerCase()] ? text.toLowerCase() : 'mz';
    const config = types[type];

    function generateNumbers(count, max) {
      const nums = new Set();
      while (nums.size < count) {
        nums.add(Math.floor(Math.random() * max) + 1);
      }
      return [...nums].sort((a, b) => a - b);
    }

    const mainNumbers = generateNumbers(config.numbers, config.max);
    let extraNumbers = [];
    if (config.extra) {
      extraNumbers = generateNumbers(config.extra, config.extraMax);
    }

    let result = `🎰 *${config.name}*\n\n`;
    result += `🔢 Números: *${mainNumbers.join(' - ')}*`;
    if (extraNumbers.length > 0) {
      result += `\n${config.extraName || 'Extra'}: *${extraNumbers.join(' - ')}*`;
    }
    result += `\n\n💰 Boa sorte! 🍀`;
    result += `\n\n✳️ Tipos: mz, br, eu, us\nUse: *${usedPrefix}${command} <tipo>*`;

    await sock.sendMessage(msg.key.remoteJid, { text: result }, { quoted: msg });
  }
};
