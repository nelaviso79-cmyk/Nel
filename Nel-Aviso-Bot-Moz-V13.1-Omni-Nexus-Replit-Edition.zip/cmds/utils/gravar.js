/**
 * 🎙️ GRAVAR — Gravar nota de voz (converte texto ou resposta em áudio PTT)
 */
import fetch from 'node-fetch';
import fs from 'fs';

export default {
  command: ['gravar', 'nota', 'notavoz', 'voznota'],
  category: 'utilidades',
  description: 'Gravar nota de voz a partir de texto 🎙️',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    let text = args.join(' ').trim();

    // Se citou uma mensagem, usa o texto da mensagem citada
    if (!text && msg.quoted) {
      text = msg.quoted.text || msg.quoted.body || msg.quoted.caption || '';
    }

    if (!text) {
      return msg.reply(`🎙️ *GRAVAR NOTA DE VOZ* 🎙️\n\n▸ Use: *${usedPrefix}${command} <texto>*\n▸ Ou responda a uma mensagem de texto com *${usedPrefix}${command}*.\n\n💡 Eu vou converter o texto numa nota de voz realista!`);
    }

    if (text.length > 600) text = text.substring(0, 600);
    await msg.react('🎙️');

    try {
      const tmpFile = `./tmp/gravar_${Date.now()}.mp3`;
      if (!fs.existsSync('./tmp')) fs.mkdirSync('./tmp', { recursive: true });

      let audioBuffer = null;

      // API 1: Vreden (Melhor para Português)
      try {
        const res = await fetch(`https://api.vreden.web.id/api/tts?text=${encodeURIComponent(text)}&lang=pt`);
        if (res.ok) {
          const buf = await res.buffer();
          if (buf.length > 1000) audioBuffer = buf;
        }
      } catch {}

      // API 2: Google TTS (PT)
      if (!audioBuffer) {
        try {
          const url = `https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=pt&q=${encodeURIComponent(text)}`;
          const res = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0' } });
          if (res.ok) {
            const buf = await res.buffer();
            if (buf.length > 1000) audioBuffer = buf;
          }
        } catch {}
      }

      if (audioBuffer) {
        fs.writeFileSync(tmpFile, audioBuffer);
        await sock.sendMessage(msg.chat, {
          audio: { url: tmpFile },
          mimetype: 'audio/ogg; codecs=opus',
          ptt: true // Nota de voz real
        }, { quoted: msg });
        await msg.react('✅');
        setTimeout(() => { try { if (fs.existsSync(tmpFile)) fs.unlinkSync(tmpFile); } catch {} }, 10000);
      } else {
        await msg.react('❌');
        msg.reply(`❌ Não foi possível gerar a nota de voz no momento.`);
      }
    } catch (e) {
      await msg.react('❌');
      msg.reply(`❌ Erro ao gravar nota: ${e.message}`);
    }
  }
};
