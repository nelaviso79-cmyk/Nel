export const command = {
  name: 'spotifysearch',
  aliases: ['spsearch', 'spotifybuscar', 'spinfo', 'spotifystalk', 'sptrack'],
  description: 'Busca músicas/artistas no Spotify com detalhes',
  category: 'downloads',
  usage: '.spotifysearch <música ou artista>',
  example: '.spotifysearch Drake'
};

export default async function ({ sock, msg, args, from, sender, config }) {
  const query = args.join(' ').trim();
  if (!query) {
    return sock.sendMessage(from, {
      text: '❌ Escreve o nome da música ou artista!\n\n💡 *Uso:* .spotifysearch <nome>\n📌 *Ex:* .spotifysearch Drake'
    }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '🎵', key: msg.key } });

  try {
    const res = await fetch(`https://api.delirius.store/search/spotify?query=${encodeURIComponent(query)}`);
    const data = await res.json();
    if (data?.status === 200 && data?.result && data.result.length > 0) {
      const tracks = data.result.slice(0, 5);
      let text = `🎵 *SPOTIFY SEARCH* — "${query}"\n\n━━━━━━━━━━━━━━━━━━━━\n\n`;

      for (let i = 0; i < tracks.length; i++) {
        const t = tracks[i];
        text += `${i === 0 ? '🎶' : '🎵'} *${t.title || t.name || 'N/A'}*\n`;
        if (t.artist || t.artists) text += `  🎤 ${t.artist || (Array.isArray(t.artists) ? t.artists.join(', ') : t.artists)}\n`;
        if (t.album) text += `  💿 Álbum: ${t.album}\n`;
        if (t.duration) text += `  ⏱️ ${t.duration}\n`;
        if (t.popularity) text += `  🔥 Popularidade: ${t.popularity}%\n`;
        if (t.url || t.link) text += `  🔗 ${t.url || t.link}\n`;
        text += '\n';
      }

      const coverUrl = tracks[0].cover || tracks[0].image || tracks[0].thumbnail || tracks[0].albumArt;
      if (coverUrl) {
        try {
          const imgRes = await fetch(coverUrl);
          if (imgRes.ok) {
            const buffer = Buffer.from(await imgRes.arrayBuffer());
            await sock.sendMessage(from, {
              image: buffer,
              caption: text.trim(),
              contextInfo: { externalAdReply: { title: tracks[0].title || 'Spotify', body: tracks[0].artist || '', thumbnailUrl: coverUrl, mediaType: 1 } }
            }, { quoted: msg });
            return;
          }
        } catch (e) { }
      }

      await sock.sendMessage(from, { text: text.trim() }, { quoted: msg });
      return;
    }
  } catch (e) {
    console.log('Spotify search failed:', e.message);
  }

  await sock.sendMessage(from, { text: `❌ Não encontrei "${query}" no Spotify.` }, { quoted: msg });
}
