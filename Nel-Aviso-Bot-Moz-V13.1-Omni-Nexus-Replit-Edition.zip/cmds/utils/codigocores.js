export default {
  command: ['codigocores', 'cores', 'colorcode', 'cor'],
  category: 'utilidades',
  description: 'Gerar um código de cor hexadecimal aleatório com visualização.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    // Generate random hex color
    const randomHex = () => Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0');
    
    if (args[0]?.startsWith('#')) {
      const hex = args[0].replace('#', '');
      if (!/^[0-9a-fA-F]{6}$/.test(hex)) {
        return msg.reply('❧ Código de cor inválido! Usa formato #RRGGBB.\n✎ Exemplo: *#FF5733*');
      }
      const r = parseInt(hex.substring(0, 2), 16);
      const g = parseInt(hex.substring(2, 4), 16);
      const b = parseInt(hex.substring(4, 6), 16);
      return msg.reply(
        `❧ *Código de Cor* 🎨\n\n` +
        `▸ HEX: *#${hex.toUpperCase()}*\n` +
        `▸ RGB: *rgb(${r}, ${g}, ${b})*\n` +
        `▸ HSL: *hsl(${Math.round(r * 1.41)}, ${Math.round(g * 1.41)}%, ${Math.round(b * 1.41)}%)*`
      );
    }

    const hex = args[0] || randomHex();
    const cleanHex = hex.replace('#', '');
    const r = parseInt(cleanHex.substring(0, 2), 16) || 0;
    const g = parseInt(cleanHex.substring(2, 4), 16) || 0;
    const b = parseInt(cleanHex.substring(4, 6), 16) || 0;

    const corNames = {
      'FF0000': 'Vermelho', '00FF00': 'Verde', '0000FF': 'Azul',
      'FFFF00': 'Amarelo', 'FF00FF': 'Magenta', '00FFFF': 'Ciano',
      '000000': 'Preto', 'FFFFFF': 'Branco', 'FFA500': 'Laranja',
      '800080': 'Roxo', 'FFC0CB': 'Rosa', 'A52A2A': 'Castanho',
    };

    const nearestName = corNames[cleanHex.toUpperCase()] || 'Cor Personalizada';

    return msg.reply(
      `❧ *Cor Aleatória* 🎨\n\n` +
      `▸ Nome: *${nearestName}*\n` +
      `▸ HEX: *#${cleanHex.toUpperCase()}*\n` +
      `▸ RGB: *rgb(${r}, ${g}, ${b})*\n\n` +
      `▸ Usa *${usedPrefix + command} #FF5733* para ver uma cor específica.\n` +
      `▸ Usa *${usedPrefix + command}* para outra cor aleatória!`
    );
  },
};
