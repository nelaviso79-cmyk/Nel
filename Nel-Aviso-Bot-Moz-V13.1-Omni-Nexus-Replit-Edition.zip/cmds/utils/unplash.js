export const command = {
  name: 'unplash',
  aliases: ['unsplash', 'imgpro', 'fotopro', 'fotobuscar', 'imgsearch'],
  description: 'Busca imagens profissionais no Unsplash (alta qualidade)',
  category: 'utilidades',
  usage: '.unplash <termo>',
  example: '.unplash sunset beach'
};

export default async function ({ sock, msg, args, from, sender, config }) {
  const query = args.join(' ').trim();
  if (!query) {
    return sock.sendMessage(from, {
      text: '❌ Escreve o que queres buscar!\n\n💡 *Uso:* .unplash <termo>\n📌 *Ex:* .unplash sunset beach'
    }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '📸', key: msg.key } });

  try {
    const res = await fetch(`https://api.delirius.store/search/unsplash?query=${encodeURIComponent(query)}`);
    const data = await res.json();
    if (data?.status === 200 && data?.result && data.result.length > 0) {
      const images = data.result.slice(0, 3);
      let sentCount = 0;

      for (const img of images) {
        const imgUrl = img.url || img.image || img.download || img.links?.download || img.urls?.regular || img.src;
        if (typeof imgUrl === 'string' && imgUrl.startsWith('http')) {
          try {
            const imgRes = await fetch(imgUrl);
            if (imgRes.ok) {
              const buffer = Buffer.from(await imgRes.arrayBuffer());
              const caption = sentCount === 0
                ? `📸 *Unsplash* — "${query}"\n\n✍️ ${img.author || img.user || 'Photographer'}\n📝 ${img.description || img.alt || ''}`.trim()
                : '';
              await sock.sendMessage(from, {
                image: buffer,
                caption: caption,
                contextInfo: sentCount === 0 ? {
                  externalAdReply: { title: 'Unsplash Search', body: query, thumbnailUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/5b/Unsplash_Logo.svg/1200px-Unsplash_Logo.svg.png', mediaType: 1 }
                } : undefined
              }, { quoted: msg });
              sentCount++;
            }
          } catch (e) { }
        }
      }

      if (sentCount > 0) return;
    }
  } catch (e) {
    console.log('Unsplash search failed:', e.message);
  }

  await sock.sendMessage(from, { text: `❌ Não encontrei imagens de "${query}" no Unsplash.` }, { quoted: msg });
}
