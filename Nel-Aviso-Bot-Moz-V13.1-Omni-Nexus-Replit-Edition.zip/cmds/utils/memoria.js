export default {
  command: ['memoria', 'memory', 'jogomemoria', 'memorizar'],
  category: 'diversao',
  description: 'Jogo de memória - teste sua memória! 🧠',
  run: async ({ msg, sock, usedPrefix, command, text }) => {
    const niveis = {
      facil: { emojis: 4, tentativas: 3 },
      medio: { emojis: 6, tentativas: 2 },
      dificil: { emojis: 8, tentativas: 1 }
    };

    const nivel = niveis[(text || 'facil').toLowerCase()] || niveis.facil;
    const todosEmojis = ['🍎','🍌','🍇','🍊','🥝','🍓','🫐','🍑','🍒','🥭','🍍','🥥','🌽','🥕','🍅','🧅','🥑','🌶️','🫒','🍋'];
    
    // Selecionar emojis únicos e duplicar (pares)
    const selecionados = todosEmojis.sort(() => Math.random() - 0.5).slice(0, nivel.emojis);
    const pares = [...selecionados, ...selecionados].sort(() => Math.random() - 0.5);

    // Mostrar por 5 segundos
    const gridCols = 4;
    let gridDisplay = '';
    for (let i = 0; i < pares.length; i++) {
      if (i % gridCols === 0 && i > 0) gridDisplay += '\n';
      gridDisplay += `│${pares[i]}│`;
    }

    // Guardar na memória global
    global._memoria = global._memoria || {};
    global._memoria[msg.sender] = {
      pares: pares,
      tentativas: nivel.tentativas,
      revelados: Array(pares.length).fill(false)
    };

    return msg.reply(
      `🧠 *JOGO DE MEMÓRIA* 🧠\n\n` +
      `▸ Nível: *${nivel.emojis === 4 ? 'Fácil' : nivel.emojis === 6 ? 'Médio' : 'Difícil'}*\n` +
      `▸ Pares: *${nivel.emojis}*\n` +
      `▸ Tentativas: *${nivel.tentativas}*\n\n` +
      `⏳ *MEMORIZE!*\n\n${gridDisplay}\n\n` +
      `▸ Para revelar, use: *${usedPrefix}revelar posição*\n` +
      `▸ Exemplo: *${usedPrefix}revelar 1 2* (duas posições)\n\n` +
      `_🧠 Nel-Aviso-Bot-Moz_`
    );
  }
};
