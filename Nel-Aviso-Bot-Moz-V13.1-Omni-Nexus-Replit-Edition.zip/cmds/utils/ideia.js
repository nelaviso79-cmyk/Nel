export default {
  command: ['ideia', 'ideias', 'idea', 'projectoideia'],
  category: 'diversao',
  description: 'Gerar ideias aleatórias para projectos 💡',
  run: async ({ msg, sock, usedPrefix, command }) => {
    const ideias = [
      '🏗️ Criar um app de receitas moçambicanas com passo-a-passo em vídeo',
      '📱 Fazer um bot de WhatsApp para alertas de chuva em Moçambique',
      '🎮 Desenvolver um jogo de trivia sobre cultura africana',
      '📊 Criar um dashboard de preços de mercado em Maputo',
      '🤖 Construir um chatbot de atendiz-mento para pequenos negócios',
      '🎵 Fazer um app de streaming de música local moçambicana',
      '🗺️ Criar um mapa interactivo dos pontos turísticos de Moçambique',
      '📚 Desenvolver uma plataforma de cursos online em português',
      '🚌 Fazer um app de horários de chapas/transporte em Maputo',
      '💰 Criar uma calculadora de impostos moçambicanos',
      '🌱 Desenvolver um app de agricultura com dicas para fazendeiros',
      '🏥 Fazer um sistema de marcação de consultas online',
      '🛒 Criar um marketplace para produtos artesanais moçambicanos',
      '📱 Fazer um app de tradução de línguas locais (Xichangana, Xirhonga, etc.)',
      '🎤 Desenvolver uma plataforma de karaoké com músicas africanas',
      '📸 Criar um app de filtros de foto com padrões africanos',
      '⚡ Fazer um app de monitoramento de energia eléctrica',
      '🎓 Desenvolver um simulador de exames nacionais',
      '🚌 Criar um sistema de carpooling para universitários',
      '📰 Fazer um agregador de notícias moçambicanas',
      '🎨 Criar um gerador de designs com estética africana',
      '🏋️ Desenvolver um app de treino personalizado sem academia',
      '🍳 Fazer um app de plano alimentar com ingredientes locais',
      '🐾 Criar um app de adoção de animais domésticos',
      '📝 Desenvolver um sistema de diário digital com prompts',
      '🎯 Fazer um app de metas e hábitos com gamificação',
      '🌈 Criar um gerador de paletas de cores inspiradas na natureza',
      '🔊 Desenvolver um app de sons da natureza para relaxamento',
      '🎬 Fazer um recomendador de filmes baseado no humor',
      '🧮 Criar um conversor de medidas universal (culinária, construção, etc.)',
    ];

    const ideia = ideias[Math.floor(Math.random() * ideias.length)];
    await sock.sendMessage(msg.key.remoteJid, { text: `💡 *IDEIA DE PROJECTO*\n\n${ideia}\n\n🔄 Use *${usedPrefix}${command}* para outra ideia!` }, { quoted: msg });
  }
};
