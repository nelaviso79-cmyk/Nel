export default {
  command: ['pedrapapeltesoura', 'rps', 'jokenpo', 'janken'],
  category: 'diversao',
  description: 'Pedra, Papel ou Tesoura contra o bot ✊✋✌️',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    const opcoes = ['pedra', 'papel', 'tesoura'];
    const emojis = { pedra: '✊', papel: '✋', tesoura: '✌️' };
    
    const jogador = (text || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    
    if (!opcoes.includes(jogador)) {
      return msg.reply(
        `✊✋✌️ *PEDRA PAPEL TESOURA*\n\n` +
        `◈ Escolha uma opção!\n\n` +
        `✎ Exemplo: *${usedPrefix + command} pedra*\n✎ Exemplo: *${usedPrefix + command} papel*\n✎ Exemplo: *${usedPrefix + command} tesoura*`
      );
    }
    
    const bot = opcoes[Math.floor(Math.random() * 3)];
    
    let resultado;
    if (jogador === bot) resultado = 'empate';
    else if (
      (jogador === 'pedra' && bot === 'tesoura') ||
      (jogador === 'papel' && bot === 'pedra') ||
      (jogador === 'tesoura' && bot === 'papel')
    ) resultado = 'vitoria';
    else resultado = 'derrota';
    
    const mensagens = {
      empate: '🤝 Empate! Ambos escolheram igual!',
      vitoria: '🎉 Parabéns! Você venceu!',
      derrota: '😅 Eu venci! Tente novamente!'
    };
    
    const statusEmoji = { empate: '🤝', vitoria: '🏆', derrota: '😔' };
    
    return msg.reply(
      `✊✋✌️ *PEDRA PAPEL TESOURA*\n\n` +
      `▸ Você: ${emojis[jogador]} ${jogador.toUpperCase()}\n` +
      `▸ Bot:  ${emojis[bot]} ${bot.toUpperCase()}\n\n` +
      `${statusEmoji[resultado]} ${mensagens[resultado]}\n\n` +
      `_🎮 Nel-Aviso-Bot_`
    );
  }
};
