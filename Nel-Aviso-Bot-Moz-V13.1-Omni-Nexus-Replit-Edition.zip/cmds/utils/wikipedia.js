/**
 * 📚 WIKIPEDIA — Buscar na Wikipedia em português
 */
import fetch from 'node-fetch';

export default {
  command: ['wikipedia', 'wiki', 'enciclopedia'],
  category: 'utilidades',
  description: 'Buscar informação na Wikipedia 📚',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const text = args.join(' ').trim();
    if (!text) return msg.reply(`❌ Use: *${usedPrefix}${command} <termo>*\nEx: *${usedPrefix}wiki Moçambique*`);

    try {
      // API Wikipedia PT
      const url = `https://pt.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(text)}`;
      const res = await fetch(url);
      const data = await res.json();

      if (data.type === 'https://mediawiki.org/wiki/HyperWiki/errors/not_found' || !data.extract) {
        // Fallback: buscar sugestões
        const searchUrl = `https://pt.wikipedia.org/w/api.php?action=opensearch&search=${encodeURIComponent(text)}&limit=5&format=json`;
        const searchRes = await fetch(searchUrl);
        const search = await searchRes.json();

        if (search[1]?.length) {
          const sugestoes = search[1].map((s, i) => `${i + 1}. ${s}`).join('\n');
          return msg.reply(`❌ Não encontrei "${text}" na Wiki.\n\n*Sugestões:*\n${sugestoes}\n\nTente: *${usedPrefix}wiki ${search[1][0]}*`);
        }
        return msg.reply(`❌ Nenhum resultado para "${text}" na Wikipedia.`);
      }

      let r = `📚 *WIKIPEDIA* 📚\n\n`;
      r += `📌 *${data.title}*\n\n`;
      r += `${data.extract}\n\n`;
      if (data.content_urls?.desktop?.page) {
        r += `🔗 ${data.content_urls.desktop.page}`;
      }
      if (data.thumbnail?.source) {
        await sock.sendMessage(msg.chat, {
          image: { url: data.thumbnail.source },
          caption: r
        }, { quoted: msg });
      } else {
        await msg.reply(r);
      }
    } catch (e) {
      // Fallback API alternativa
      try {
        const url2 = `https://api.delirius.store/search/wikipedia?query=${encodeURIComponent(text)}`;
        const res2 = await fetch(url2);
        const data2 = await res2.json();
        if (data2.status && data2.result?.content) {
          const d = data2.result;
          let r = `📚 *WIKIPEDIA* 📚\n\n📌 *${d.title || text}*\n\n`;
          r += d.content.substring(0, 1500);
          if (d.url) r += `\n\n🔗 ${d.url}`;
          return msg.reply(r);
        }
      } catch {}
      msg.reply(`❌ Erro ao buscar na Wikipedia. Tente novamente.`);
    }
  }
};
