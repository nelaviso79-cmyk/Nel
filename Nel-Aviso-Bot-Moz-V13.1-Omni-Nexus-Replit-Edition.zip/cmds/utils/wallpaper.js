// ╔══════════════════════════════════════════════════════════╗
//   NEL-AVISO-BOT-MOZ · cmds/utils/wallpaper.js
// ╚══════════════════════════════════════════════════════════╝

import fetch from 'node-fetch';

export default {
  command: ['wallpaper', 'wall', 'fundo', 'papeldeparede', 'wp'],
  category: 'utilidades',
  description: 'Buscar wallpapers HD/UHD de alta qualidade 🖼️',

  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const query = args.join(' ').trim();

    if (!query) {
      return msg.reply(
        `🖼️ *WALLPAPERS HD* 🖼️\n\n` +
        `Busque wallpapers de alta qualidade!\n\n` +
        `📋 Exemplos:\n` +
        `• *${usedPrefix}${command} natureza*\n` +
        `• *${usedPrefix}${command} anime girl*\n` +
        `• *${usedPrefix}${command} cyberpunk*\n\n` +
        `> Envia até 3 wallpapers HD!`
      );
    }

    await msg.reply(`⏳ A buscar wallpapers de *${query}*...`);

    try {
      // Primary: Wallhaven via Delirius
      const res = await fetch(
        `https://api.delirius.store/search/wallhaven?q=${encodeURIComponent(query)}`
      );
      const data = await res.json();

      if (data.status && data.result && data.result.length > 0) {
        const walls = data.result.slice(0, 3);
        let count = 0;

        for (const w of walls) {
          const imgUrl = w.path || w.url || w.image || w.thumbs?.large || w.thumbnail;
          if (!imgUrl) continue;

          count++;
          const caption =
            `🖼️ *Wallpaper #${count}*\n` +
            `📐 Resolução: ${w.resolution || w.dimension || 'HD'}\n` +
            `🎨 Categoria: ${w.category || 'N/A'}\n` +
            `${w.file_size ? `📦 Tamanho: ${w.file_size}\n` : ''}` +
            `${w.url || w.page ? `🔗 ${w.url || w.page}` : ''}`;

          try {
            await sock.sendMessage(msg.chat, {
              image: { url: imgUrl },
              caption
            }, { quoted: msg });
          } catch (imgErr) {
            // If image fails, try alternative URL
            const altUrl = w.thumbs?.original || w.thumbs?.small || w.image;
            if (altUrl && altUrl !== imgUrl) {
              try {
                await sock.sendMessage(msg.chat, {
                  image: { url: altUrl },
                  caption
                }, { quoted: msg });
              } catch (e2) {
                await msg.reply(caption);
              }
            }
          }
        }

        if (count > 0) {
          await msg.reply(`✅ *${count}* wallpaper(s) encontrado(s) para *${query}*`);
        }
        return;
      }

      // Fallback: UHDPaper via Delirius
      const res2 = await fetch(
        `https://api.delirius.store/search/uhdpaper?query=${encodeURIComponent(query)}`
      );
      const data2 = await res2.json();

      if (data2.status && data2.result && data2.result.length > 0) {
        const walls = data2.result.slice(0, 3);
        let count = 0;

        for (const w of walls) {
          const imgUrl = w.image || w.url || w.thumbnail;
          if (!imgUrl) continue;

          count++;
          await sock.sendMessage(msg.chat, {
            image: { url: imgUrl },
            caption: `🖼️ *Wallpaper #${count}*\n📐 ${w.resolution || w.size || 'UHD'}`
          }, { quoted: msg });
        }

        if (count > 0) {
          await msg.reply(`✅ *${count}* wallpaper(s) encontrado(s) para *${query}*`);
        }
        return;
      }

      // Fallback 3: Wallcraft
      const res3 = await fetch(
        `https://api.delirius.store/search/wallcraft?query=${encodeURIComponent(query)}`
      );
      const data3 = await res3.json();

      if (data3.status && data3.result && data3.result.length > 0) {
        const w = data3.result[0];
        const imgUrl = w.image || w.url || w.thumbnail;
        if (imgUrl) {
          await sock.sendMessage(msg.chat, {
            image: { url: imgUrl },
            caption: `🖼️ *Wallpaper*\n📐 HD`
          }, { quoted: msg });
        }
        return;
      }

      await msg.reply(
        `❌ Nenhum wallpaper encontrado para *${query}*.\n` +
        `> Tente outro termo de busca.`
      );
    } catch (e) {
      await msg.reply(`❌ Erro ao buscar wallpaper: *${e.message}*`);
    }
  }
};
