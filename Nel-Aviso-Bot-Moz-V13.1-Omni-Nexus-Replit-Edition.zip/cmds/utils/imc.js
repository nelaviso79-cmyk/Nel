export default {
  command: ['imc', 'peso', 'saude'],
  category: 'utilidades',
  description: 'Calculadora de Índice de Massa Corporal (IMC) ⚖️',
  run: async ({ msg, args, usedPrefix, command }) => {
    if (args.length < 2) {
      return msg.reply(
        `⚖️ *CALCULADORA IMC NEXUS* ⚖️\n\n` +
        `Descubra o seu Índice de Massa Corporal e dicas de saúde.\n\n` +
        `▸ *Uso:* ${usedPrefix + command} <peso_kg> <altura_metros>\n` +
        `▸ *Exemplo:* ${usedPrefix + command} 70 1.75\n\n` +
        `_Nota: Use ponto (.) em vez de vírgula._`
      );
    }

    const peso = parseFloat(args[0].replace(',', '.'));
    const altura = parseFloat(args[1].replace(',', '.'));

    if (isNaN(peso) || isNaN(altura) || altura <= 0) {
      return msg.reply(`❌ Por favor, insira valores válidos para peso e altura.`);
    }

    const imc = peso / (altura * altura);
    let categoria = '';
    let dicas = '';

    if (imc < 18.5) {
      categoria = 'Abaixo do peso';
      dicas = 'Considere consultar um nutricionista para uma dieta de fortalecimento.';
    } else if (imc < 25) {
      categoria = 'Peso normal (Ideal)';
      dicas = 'Excelente! Continue mantendo uma alimentação equilibrada e exercícios regulares.';
    } else if (imc < 30) {
      categoria = 'Sobrepeso';
      dicas = 'Atenção à alimentação. Pequenas caminhadas diárias podem ajudar muito.';
    } else {
      categoria = 'Obesidade';
      dicas = 'É importante procurar orientação médica para evitar problemas de saúde futuros.';
    }

    const result = `⚖️ *RESULTADO IMC NEXUS* ⚖️\n\n` +
      `▸ Seu IMC: *${imc.toFixed(2)}*\n` +
      `▸ Categoria: *${categoria}*\n\n` +
      `💡 *Dica:* ${dicas}\n\n` +
      `_Nexus Health Intelligence_ 🛡️`;
    
    return msg.reply(result);
  }
};
