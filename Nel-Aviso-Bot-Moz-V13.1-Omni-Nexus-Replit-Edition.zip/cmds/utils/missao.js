export default {
  command: ['missao', 'missão', 'desafio', 'mission'],
  category: 'diversao',
  description: 'Receber uma missão aleatória para completar no grupo! Diversão garantida.',
  run: async ({ msg, sock, usedPrefix, command }) => {
    const missoes = [
      '🎯 Missão: Manda um audio a cantar a tua música favorita!',
      '🎯 Missão: Complimenta a pessoa que enviou a última mensagem antes de ti!',
      '🎯 Missão: Conta uma piada em 30 segundos!',
      '🎯 Missão: Envia um sticker engraçado!',
      '🎯 Missão: Diz "Eu amo-vos" ao grupo!',
      '🎯 Missão: Partilha um facto interessante que ninguém sabe!',
      '🎯 Missão: Faz uma cara engraçada e envia como foto!',
      '🎯 Missão: Troca o teu nome no grupo por 5 minutos para algo engraçado!',
      '🎯 Missão: Manda uma mensagem só com emojis!',
      '🎯 Missão: Diz algo bom sobre Moçambique!',
      '🎯 Missão: Comenta sobre a última série/filme que viste!',
      '🎯 Missão: Finge que és o admin por 1 mensagem!',
      '🎯 Missão: Envia a letra da tua música favorita!',
      '🎯 Missão: Pergunta algo interessante ao grupo!',
      '🎯 Missão: Conta um sonho que já tiveste!',
      '🎯 Missão: Fala sobre o teu prato moçambicano favorito!',
      '🎯 Missão: Descreve o teu dia em 3 palavras!',
      '🎯 Missão: Qual é o teu maior talento? Conta ao grupo!',
      '🎯 Missão: Envia uma mensagem de motivação ao grupo!',
      '🎯 Missão: Conta algo que ninguém aqui sabe sobre ti!',
    ];

    const missao = missoes[Math.floor(Math.random() * missoes.length)];
    return msg.reply(`❧ *Missão Aleatória* 🎲\n\n${missao}\n\n▸ Completa a missão para ganhar respeito no grupo! 😎\n▸ Usa *${usedPrefix + command}* para outra missão!`);
  },
};
