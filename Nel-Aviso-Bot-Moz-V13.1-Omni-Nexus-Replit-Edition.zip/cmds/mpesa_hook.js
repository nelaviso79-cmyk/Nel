/**
 * ╔════════════════════════════════════════════════════════════════════╗
 * ║  🧾 DETECTOR AUTOMÁTICO DE COMPROVATIVOS M-PESA/E-MOLA           ║
 * ║  Detecta por TEXTO e por FOTO (OCR + IA)                        ║
 * ║  Verifica se pagamento é PARA as contas do DONO                 ║
 * ║  + Regista compra automaticamente se comprovativo válido         ║
 * ╚════════════════════════════════════════════════════════════════════╝
 */

import fetch from 'node-fetch';
import axios from 'axios';
import FormData from 'form-data';
import db from '#db';

// ═══ REGEX ═══
const P1 = /Confirmado\s+([A-Z0-9]{10,12})\.\s+Transferiste\s+([\d.,]+)\s*MT\s*(?:e\s*a\s*taxa\s*foi\s*de\s*([\d.,]+)\s*MT)?\s*para\s+([\d\s]+)\s*[-–]?\s*([A-ZÀ-Ú\s]+?)(?:\.|$|\s*$)/im;
const P2 = /ID\s+(?:da\s+)?transa[cç][aã]o\s+([A-Z0-9.]+)\.\s+Transferiste\s+([\d.,]+)\s*MT\s+para\s+(?:conta\s+)?(\d+)\s*,?\s*nome[:\s]+([A-ZÀ-Ú\s]+?)(?:\.|$|\s)/im;
const P3 = /(?:chave|key|c[oó]digo)[:\s]+([A-Z0-9]{6,12})[\s\S]*?(?:destino|nome|para)[:\s]+([A-ZÀ-Ú\s]+?)[\s\S]*?(?:valor|montante|quantia|transferiste)[:\s]+([\d.,]+)\s*MT/im;
const P4 = /(?:Transferiste|Recebeste|Enviaste|Pagaste)\s+([\d.,]+)\s*MT[\s\S]*?(?:para|de|a)\s+(?:conta\s+)?(\d+)?[\s,.-]*(?:nome[:\s]+)?([A-ZÀ-Ú\s]+?)(?:\.|$|,|\s(?:e|com|taxa|ref))/im;
const PT = /(?:hoje\s+[àa]s\s+|ontem\s+[àa]s\s+)?(\d{1,2}[:h]\d{2})(?:\s*(?:de\s+)?(\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4}))?/im;
const PG = /(?:comprovativo|confirmado|transferiste|recebeste|enviaste|pagaste|transa[cç][aã]o|m-pesa|mpesa|vodacom|e-mola|emola)/i;
const PV = /([\d.,]+)\s*MT/im;
const PPhone = /(8[2-7]\d{7})/g;

global.mpesaRegistry = global.mpesaRegistry || new Map();

// ═══ PACOTES ═══
const PACOTES = { 5:200,10:400,15:600,20:800,22:850,25:1024,30:1200,35:1400,40:1600,45:1850,50:2048,55:2150,65:2800,75:3072,80:3300,100:4096,130:5120,255:10240,185:6042,190:6144,220:7168,280:10752,450:17613,870:36454,1800:73216 };

function mbR(mb) { return mb >= 1024 ? (mb/1024).toFixed(2)+'GB' : mb+'MB'; }
function pA(s) { if(!s)return null; return parseFloat(s.replace(/\s/g,'').replace(/\./g,'').replace(',','.'))||null; }

function getMegas(v) {
  if (!v) return null;
  if (PACOTES[v]) return PACOTES[v];
  const k = Object.keys(PACOTES).map(Number).sort((a,b)=>a-b);
  for (const x of k) if (Math.abs(x-v)<=2) return PACOTES[x];
  return Math.round(v*1024/25);
}

function getToday() { return new Date().toLocaleDateString('pt-MZ',{timeZone:'Africa/Maputo',year:'numeric',month:'2-digit',day:'2-digit'}).split('/').reverse().join('-'); }
function getNow() { return new Date().toLocaleString('pt-MZ',{timeZone:'Africa/Maputo',hour:'2-digit',minute:'2-digit',day:'2-digit',month:'2-digit',year:'numeric'}); }

// ═══ EXTRAIR DADOS ═══
function extractData(text) {
  const d = { detected:false,type:null,key:null,transactionId:null,amount:null,fee:null,destNum:null,destName:null,time:null,date:null,raw:text,confidence:0,warnings:[] };
  let m = text.match(P1);
  if(m){d.detected=true;d.type='confirmado';d.key=m[1];d.amount=pA(m[2]);d.fee=pA(m[3]);d.destNum=m[4]?.replace(/\s/g,'');d.destName=m[5]?.trim();d.confidence=85;}
  if(!d.detected){m=text.match(P2);if(m){d.detected=true;d.type='id_transacao';d.transactionId=m[1];d.amount=pA(m[2]);d.destNum=m[3]?.replace(/\s/g,'');d.destName=m[4]?.trim();d.confidence=80;}}
  if(!d.detected){m=text.match(P3);if(m){d.detected=true;d.type='chave_key';d.key=m[1];d.destName=m[2]?.trim();d.amount=pA(m[3]);d.confidence=75;}}
  if(!d.detected){m=text.match(P4);if(m){d.detected=true;d.type='generico';d.amount=pA(m[1]);d.destNum=m[2]?.replace(/\s/g,'');d.destName=m[3]?.trim();d.confidence=60;}}
  const tm=text.match(PT);if(tm){d.time=tm[1];d.date=tm[2];}
  if(!d.destNum){const ph=text.match(PPhone);if(ph?.length)d.destNum=ph[0];}
  if(!d.detected&&PG.test(text)){d.detected=true;d.type='parcial';d.confidence=30;const vm=text.match(PV);if(vm)d.amount=pA(vm[1]);d.warnings.push('Formato não reconhecido completamente');}
  return d;
}

// ═══ VERIFICAR AUTENTICIDADE ═══
function verify(d) {
  const r = {isAuthentic:false,score:0,redFlags:[],greenFlags:[],verdict:'',destinoDono:false};
  // Chave/ID
  if(d.key){if(/^[A-Z0-9]{10,12}$/.test(d.key)){r.score+=20;r.greenFlags.push('✅ Chave válida');}else{r.score-=10;r.redFlags.push('⚠️ Chave suspeita');}}
  else if(d.transactionId){if(/^[A-Z]{2}\d{6}\.\d{4}\.[A-Z]\d{5}$/.test(d.transactionId)){r.score+=25;r.greenFlags.push('✅ ID transação válido');}else if(d.transactionId.length>5){r.score+=10;r.greenFlags.push('✅ Possui ID');}}
  else{r.score-=15;r.redFlags.push('❌ Sem chave/ID');}
  // Valor
  if(d.amount>0&&d.amount<100000){r.score+=15;r.greenFlags.push('✅ Valor normal');}
  else if(!d.amount){r.score-=10;r.redFlags.push('❌ Valor inválido');}
  // Destino = conta do DONO?
  const contas = global.contasDono || {};
  if(d.destNum){
    const mpesaNum = contas.mpesa?.numero || '';
    const emolaNum = contas.emola?.numero || '';
    const mpesaNome = (contas.mpesa?.nome || '').toLowerCase().trim();
    const emolaNome = (contas.emola?.nome || '').toLowerCase().trim();
    const destNumClean = d.destNum.replace(/\s/g,'');
    const destNameClean = (d.destName||'').toLowerCase().trim();

    if(destNumClean === mpesaNum || destNumClean === emolaNum){
      r.score += 25;
      r.destinoDono = true;
      r.greenFlags.push('✅ Pagamento PARA a conta do DONO ✓');
      // Verificar nome também
      if(destNameClean && (destNameClean === mpesaNome || destNameClean === emolaNome)){
        r.score += 10;
        r.greenFlags.push('✅ Nome do destinatário confere com o DONO');
      } else if(destNameClean){
        r.score -= 5;
        r.redFlags.push('⚠️ Nome NÃO confere com o dono da conta!');
      }
    } else {
      r.score -= 20;
      r.redFlags.push('🚨 Pagamento NÃO é para a conta do dono!');
      r.redFlags.push(`⚠️ Destino: ${d.destNum} — Dono: M-Pesa ${mpesaNum} / E-Mola ${emolaNum}`);
    }
  }
  // Nome destino
  if(d.destName&&d.destName.trim().length>=3){r.score+=10;r.greenFlags.push('✅ Nome presente');}
  // Taxa
  if(d.fee!==null){if(d.fee===0){r.score+=5;r.greenFlags.push('✅ Taxa zero');}else if(d.fee<(d.amount||1)*0.1){r.score+=5;}else{r.score-=5;r.redFlags.push('⚠️ Taxa alta');}}
  // Duplicado
  const rk=d.key||d.transactionId;
  if(rk&&global.mpesaRegistry.has(rk)){r.score-=30;r.redFlags.push('🚨 DUPLICADO!');}
  // Hora
  if(d.time){const hm=d.time.match(/(\d{1,2})[:h](\d{2})/);if(hm){const mm=parseInt(hm[1])*60+parseInt(hm[2]);const cm=new Date().getHours()*60+new Date().getMinutes();if(mm>cm+120){r.score-=15;r.redFlags.push('🚨 Hora no FUTURO');}else{r.score+=5;}}}
  // Suspeito
  if(/(editar|modificar|photoshop|fake|falso)/i.test(d.raw||'')){r.score-=20;r.redFlags.push('🚨 Palavra suspeita');}
  r.score=Math.max(0,Math.min(100,r.score));
  if(r.score>=70){r.isAuthentic=true;r.verdict='PROVAVELMENTE AUTÊNTICO';}
  else if(r.score>=40){r.isAuthentic=null;r.verdict='INCONCLUSIVO';}
  else{r.isAuthentic=false;r.verdict='PROVAVELMENTE FALSO';}
  return r;
}

function regComp(d){const k=d.key||d.transactionId;if(!k)return;global.mpesaRegistry.set(k,{amount:d.amount,destName:d.destName,destNum:d.destNum,date:new Date().toISOString(),chatId:d.chatId,sender:d.sender});if(global.mpesaRegistry.size>1000){const f=global.mpesaRegistry.keys().next().value;global.mpesaRegistry.delete(f);}}

// ═══ REGISTAR COMPRA NO DB ═══
function registarCompraAuto(chatId,sender,nome,valorMT,megas){
  const chat=db.getChat(chatId)||{};
  if(!chat.compras)chat.compras={totalGeral:0,compradores:{}};
  const c=chat.compras;
  const phone=sender.split('@')[0];
  const today=getToday();
  if(!c.compradores[phone]){c.compradores[phone]={nome:nome||phone,totalMT:0,totalMB:0,totalCompras:0,primeiraCompra:new Date().toISOString(),ultimaCompra:null,comprasHoje:0,ultimoDia:null,historico:[]};}
  const comp=c.compradores[phone];
  comp.nome=nome||comp.nome||phone;comp.totalMT+=valorMT;comp.totalMB+=megas;comp.totalCompras+=1;comp.ultimaCompra=new Date().toISOString();
  if(comp.ultimoDia!==today){comp.comprasHoje=0;comp.ultimoDia=today;}
  comp.comprasHoje+=1;
  comp.historico.push({data:getNow(),valor:valorMT,megas:megas,tipo:valorMT>=185?'mensal':'diário'});
  if(comp.historico.length>20)comp.historico=comp.historico.slice(-20);
  c.totalGeral=(c.totalGeral||0)+valorMT;
  db.updateChatSetting(chatId,'compras',c);
  return comp;
}

// ═══ OCR ═══
async function uploadTmp(buf){try{const b=new FormData();b.append('files[]',buf,'img.jpg');const r=await fetch('https://uguu.se/upload.php',{method:'POST',body:b,headers:b.getHeaders()});const j=await r.json();return j.files?.[0]?.url??null;}catch{return null;}}

async function ocr(buf){
  let t=null;
  try{const b=new FormData();b.append('image',buf,'c.jpg');const r=await axios.post(`${global.APIs.delirius.url}/tools/ocr`,b,{headers:b.getHeaders(),timeout:30000});if(r.data?.status&&r.data?.data)t=typeof r.data.data==='string'?r.data.data:r.data.data.text;}catch{}
  if(!t)try{const b=new FormData();b.append('image',buf,'c.jpg');const r=await axios.post('https://api.siputzx.my.id/api/s/ocr',b,{headers:b.getHeaders(),timeout:30000});if(r.data?.status&&r.data?.data)t=typeof r.data.data==='string'?r.data.data:r.data.data.text;}catch{}
  if(!t)try{const u=await uploadTmp(buf);if(u){const r=await axios.post('https://ai.siputzx.my.id',{content:'Lê todo o texto deste comprovativo M-Pesa moçambicano. Extrai tudo: chave, valor MT, nome, número, hora, ID. Responde SÓ com texto extraído.',imageBuffer:u,model:'gemini'},{timeout:30000});if(r.data?.result)t=r.data.result;}}catch{}
  if(!t)try{const b=new FormData();b.append('file',buf,'c.jpg');b.append('language','por');b.append('isOverlayRequired','false');const r=await axios.post('https://api.ocr.space/parse/image',b,{headers:{...b.getHeaders(),'apikey':process.env.OCRSPACE_APIKEY||'helloworld'},timeout:30000});if(r.data?.ParsedResults?.[0]?.ParsedText)t=r.data.ParsedResults[0].ParsedText;}catch{}
  return t;
}

// ═══ FORMATAR RESPOSTA ═══
function formatResp(d,v){
  const e=v.isAuthentic===true?'✅':v.isAuthentic===false?'🚨':'⚠️';
  const f=Math.floor(v.score/10);
  const bar='▓'.repeat(f)+'░'.repeat(10-f);
  let r=`┌──「 🧾 *COMPROVATIVO DETECTADO* 」\n│\n│ ${e} *${v.verdict}*\n│ 📊 Autenticidade: *${v.score}%* [${bar}]\n│\n`;
  if(d.key)r+=`│ 🔑 Chave: *${d.key}*\n`;
  if(d.transactionId)r+=`│ 📋 ID: *${d.transactionId}*\n`;
  if(d.amount!==null)r+=`│ 💵 Valor: *${d.amount.toFixed(2)} MT*\n`;
  if(d.fee!==null)r+=`│ 💲 Taxa: *${d.fee.toFixed(2)} MT*\n`;
  if(d.destName)r+=`│ 🏦 Destino: *${d.destName}*\n`;
  if(d.destNum)r+=`│ 📱 Número: *${d.destNum}*\n`;
  if(d.time)r+=`│ 🕒 Hora: *${d.time}*\n`;
  if(d.date)r+=`│ 📅 Data: *${d.date}*\n`;

  // Destino dono
  if(v.destinoDono) r+=`│\n│ 🏠 *Pagamento VERIFICADO para o DONO* ✓\n`;
  else if(d.destNum) r+=`│\n│ ⚠️ *Pagamento NÃO é para a conta do dono*\n`;

  r+=`│\n`;
  if(v.greenFlags.length){r+=`│ 🟢 *Positivos:*\n`;for(const f of v.greenFlags)r+=`│  ${f}\n`;r+=`│\n`;}
  if(v.redFlags.length){r+=`│ 🔴 *Alertas:*\n`;for(const f of v.redFlags)r+=`│  ${f}\n`;r+=`│\n`;}

  // Compra automática se autêntico E para o dono
  if(v.isAuthentic===true && v.destinoDono && d.amount){
    const megas=getMegas(d.amount);
    if(megas){
      const recibo=`NEL-${Date.now().toString(36).toUpperCase()}`;
      r+=`│ ╔════════════════════════╗\n`;
      r+=`│ ║    🧾 *RECIBO DE COMPRA*   ║\n`;
      r+=`│ ╚════════════════════════╝\n`;
      r+=`│ 📦 Pacote: *${mbR(megas)}*\n`;
      r+=`│ 💵 Valor: *${d.amount.toFixed(2)} MT*\n`;
      r+=`│ 🔖 ID: *#${recibo}*\n`;
      r+=`│ 🕒 Data: *${getNow()}*\n`;
      r+=`│ ✅ *PAGAMENTO VALIDADO* ✓\n`;
      r+=`│\n`;
      r+=`│ _Nel Net Express - Navega sem limites_\n`;
      r+=`│ _Nel Custódio · Aviso Bot_\n│\n`;
    }
  }

  r+=`└───────────────\n💡 *#mpesa* gerir | *#ranking* top compradores`;
  return r;
}

// ═══ HOOK AUTO-DETECÇÃO ═══
export async function all({msg,sock}){
  if(msg.isBot)return;
  if(!msg.chat)return;
  let dt=null;
  if(msg.text&&msg.text.length>15&&PG.test(msg.text))dt=msg.text;
  if(!dt&&(msg.message?.imageMessage||msg.quoted?.message?.imageMessage)){
    try{const im=msg.message?.imageMessage?msg:msg.quoted;if(im){const b=await sock.downloadMediaMessage(im).catch(()=>null);if(b){const o=await ocr(b);if(o&&PG.test(o))dt=o;}}}catch{}
  }
  if(!dt)return;
  try{
    const d=extractData(dt);if(!d.detected)return;
    d.chatId=msg.chat;d.sender=msg.sender;
    const v=verify(d);regComp(d);

    // Registar compra automaticamente se autêntico e para o dono
    if(v.isAuthentic===true&&v.destinoDono&&d.amount){
      const megas=getMegas(d.amount);
      if(megas){
        const phone=msg.sender.split('@')[0];
        const nome=msg.pushName||phone;
        const comp=registarCompraAuto(msg.chat,msg.sender,nome,d.amount,megas);
        // Adicionar dados da compra à resposta
        d._autoCompra={megas,totalMB:comp.totalMB,totalCompras:comp.totalCompras,comprasHoje:comp.comprasHoje,pos:getPos(msg.chat,msg.sender)};
      }
    }

    const r=formatResp(d,v);
    if(v.isAuthentic===false){
      await sock.sendMessage(msg.chat,{text:r+`\n\n🚨 *ALERTA ADMIN* — Comprovativo SUSPEITO!`},{quoted:msg});
    } else {
      // Se compra auto-registada, enviar mensagem de obrigado separada
      if(d._autoCompra){
        const ac=d._autoCompra;
        const obrigado=`🛒 *COMPRA REGISTADA AUTOMATICAMENTE!*\n\nObrigado @${msg.sender.split('@')[0]} por comprar *${mbR(ac.megas)}*!\n\n${ac.comprasHoje<=1?'🌟 Primeira compra do dia!':`🔄 ${ac.comprasHoje}ª compra do dia!`}\n\nVocê é o comprador nº *${ac.pos}* do grupo, com um total acumulado de *${mbR(ac.totalMB)}*.\n${ac.pos===1?'👑 Você é o MAIOR comprador! Parabéns!':'🏆 Rumo ao topo para desbloquear bônus!'}`;
        await sock.sendMessage(msg.chat,{text:r},{quoted:msg});
        await sock.sendMessage(msg.chat,{text:obrigado,mentions:[msg.sender]},{quoted:msg});
      } else {
        await sock.sendMessage(msg.chat,{text:r},{quoted:msg});
      }
    }
  }catch(e){console.error('[M-Pesa Hook] Erro:',e.message);}
}

function getPos(chatId,sender){
  const chat=db.getChat(chatId)||{};
  const c=chat.compras||{compradores:{}};
  const all=Object.entries(c.compradores).sort((a,b)=>b[1].totalMB-a[1].totalMB);
  return all.findIndex(([p])=>p===sender.split('@')[0])+1||all.length+1;
}
