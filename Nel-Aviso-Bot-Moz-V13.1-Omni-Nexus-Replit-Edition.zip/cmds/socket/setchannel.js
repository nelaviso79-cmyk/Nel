import db from '#db';
export default {
  command: ['setchannel', 'setbotchannel'],
  category: 'sockets',
  description: 'Alterar o canal do bot.',
  run: async ({ msg, sock, args }) => {
    const idBot = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    let config = db.getSettings(idBot) || {};
    const isOwner2 = [idBot, ...(config.owner ? [config.owner] : []), ...global.owner.map(num => num + '@s.whatsapp.net')].includes(msg.sender);
    if (!isOwner2) return msg.reply(global.mess.socket);
    const value = args.join(' ').trim();
    if (!value) {
      return msg.reply(`❀ Insira o link de um canal de WhatsApp.\n\nExemplo:\n*${msg.usedPrefix}setchannel* https://whatsapp.com/channel/XXXXXXXXXXXXXX`);
    }
    const channelUrl = value.match(/(?:https:\/\/)?(?:www\.)?(?:chat\.|wa\.)?whatsapp\.com\/channel\/([0-9A-Za-z]{22,24})/i)?.[1];
    if (!channelUrl) return msg.reply('ꕥ O link fornecido não é válido.');
    const info = await sock.newsletterMetadata("invite", channelUrl);
    if (!info) return msg.reply('ꕥ Não foi possível obter informação do canal.');
    config.nameid = info.thread_metadata?.name?.text || "Canal sem nome";
    db.setSettings(idBot, 'newsletter_id', info.id);
    db.setSettings(idBot, 'nameid', info.thread_metadata?.name?.text || "Canal sem nome");
    return msg.reply(`❀ Foi alterado o canal do Socket para *"${config.nameid}"* corretamente.`);
  },
};
