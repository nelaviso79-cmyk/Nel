import db from '#db';
export default {
  command: ['setbotowner', 'setowner'],
  category: 'sockets',
  description: 'Alterar o dono do bot.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const idBot = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    let config = db.getSettings(idBot) || {};
    const isOwner2 = [idBot, ...(config.owner ? [config.owner] : []), ...global.owner.map(num => num + '@s.whatsapp.net')].includes(msg.sender);
    if (!isOwner2) return msg.reply(global.mess.socket);
    const text = args.join(' ').trim();
    const actual = config.owner || '';
    if (text.toLowerCase() === 'clear') {
      if (!actual) return msg.reply('❀ Não há nenhum proprietário atribuído actualmente.');
      db.setSettings(idBot, 'owner', '');
      return msg.reply('❀ Foi eliminado o proprietário del Socket.');
    }
    const who = msg.mentionedJid?.[0] || msg.quoted?.sender || null;
    const limpio = text.replace(/[^0-9]/g, '');
    const nuevo = who || (limpio.length >= 10 ? (limpio.startsWith('52') && limpio.length === 12 ? `52${limpio[2] !== '1' ? '1' : ''}${limpio.slice(2)}@s.whatsapp.net` : `${limpio}@s.whatsapp.net`) : null);
    if (actual && ((!msg.quoted && msg.mentionedJid.length === 0 && !text) || (nuevo && actual === nuevo))) {
      return sock.sendMessage(msg.chat, { text: `ꕥ Já tem um dono atribuído @${actual.split('@')[0]}.\n\n✿ Se quiser alterá-lo usa:\n> *${usedPrefix + command}* @${idBot.split('@')[0]}\n\n✿ Se quiser remover o dono atribuído use:\n> *${usedPrefix + command} clear*`, mentions: [actual, idBot] }, { quoted: msg });
    }
    if (!nuevo) return sock.reply(msg.chat, `✐ Deve mencionar o novo dono do Socket.\n> Exemplo: *${usedPrefix + command}* @${idBot.split('@')[0]}`, msg, { mentions: [idBot] });
    const [ownerActual, ownerNuevo] = [actual ? actual.split('@')[0] : null, nuevo.split('@')[0]];
    db.setSettings(idBot, 'owner', nuevo);
    return sock.sendMessage(msg.chat, { text: actual && actual !== nuevo ? `✿ O dono do socket foi alterado de @${ownerActual} a @${ownerNuevo}!` : `❀ Foi atribuído a @${ownerNuevo} como novo proprietário de *${config.namebot || 'Bot'}*!`, mentions: [nuevo, ...(actual && actual !== nuevo ? [actual] : [])] }, { quoted: msg });
  },
};