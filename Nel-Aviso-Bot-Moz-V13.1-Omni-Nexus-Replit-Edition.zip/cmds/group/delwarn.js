import db from '#db';
export default {
  command: ['delwarn'],
  category: 'grupos',
  description: 'Eliminerar uma advertência de um membro do grupo.',
  isAdmin: true,
  run: async ({ msg, sock, args }) => {
    const chat = db.getChat(msg.chat);
    const targetId = msg.mentionedJid?.[0] || msg.quoted?.sender || null;
    if (!targetId) {
      return msg.reply('《✧》 Deve mencionar ou responder ao usuário cuja advertência deseja remover.');
    }
    db.setCreate('chat_users', [msg.chat, targetId], 'warnings', []);
    let user = db.getChatUser(msg.chat, targetId);
    if (!user) {
      return msg.reply('《✧》 Não foi encontrado ao usuário na base de dados.');
    }
    let warnings = user.warnings;
    if (typeof warnings === 'string') {
      try { warnings = JSON.parse(warnings); } catch { warnings = []; }
    }
    const total = warnings?.length || 0;
    if (total === 0) {
      return sock.reply(msg.chat, `《✧》 O usuário @${targetId.split('@')[0]} não tem advertências registadas.`, msg, { mentions: [targetId] });
    }
    const userGlobal = db.getUser(targetId);
    const name = userGlobal?.name || 'Usuário';
    const rawIndex = (msg.mentionedJid?.length > 0) ? args[1] : args[0];
    if (rawIndex?.toLowerCase() === 'all') {
      warnings = [];
      db.setChatUser(msg.chat, targetId, 'warnings', warnings);
      return sock.reply(msg.chat, `✐ Foram eliminadas todas as advertências do usuário @${targetId.split('@')[0]} (${name}).`, msg, { mentions: [targetId] });
    }
    const index = parseInt(rawIndex);
    if (isNaN(index)) {
      return msg.reply('《✧》 Deve especificar el índice de la advertência que deseja remover o usar all para borrar todas.');
    }
    if (index < 1 || index > total) {
      return msg.reply(`ꕥ O índice deve ser um número entre 1 e ${total}.`);
    }
    const realIndex = total - index;
    warnings.splice(realIndex, 1);
    db.setChatUser(msg.chat, targetId, 'warnings', warnings);
    await sock.reply(msg.chat, `ꕥ Foi eliminada a advertência #${index} do usuário @${targetId.split('@')[0]} (${name}).`, msg, { mentions: [targetId] });
  },
};