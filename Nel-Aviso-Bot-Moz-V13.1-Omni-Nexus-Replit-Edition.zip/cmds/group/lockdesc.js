import db from '#db';
export default {
  command: ['lockdesc', 'travardesc', 'bloqueardesc'],
  category: 'moderacao',
  description: 'Travar a descrição do grupo para que ninguém besides admins possa alterar.',
  isAdmin: true,
  botAdmin: true,
  run: async ({ msg, sock, args, usedPrefix, command, groupMetadata }) => {
    const setting = db.getChatSetting(msg.chat);
    const action = args[0]?.toLowerCase();

    if (!action || !['on', 'off', 'status'].includes(action)) {
      const status = setting?.lockdesc ? '🔒 Travada' : '🔓 Destravada';
      const currentDesc = groupMetadata?.desc || 'Sem descrição';
      return msg.reply(
        `❧ *Travar Descrição do Grupo*\n\n` +
        `▸ Estado: ${status}\n\n` +
        `✎ *Opções:*\n` +
        `> *${usedPrefix + command} on* - Travar descrição\n` +
        `> *${usedPrefix + command} off* - Destravar descrição\n` +
        `> *${usedPrefix + command} status* - Ver estado`
      );
    }

    if (action === 'status') {
      const status = setting?.lockdesc ? '🔒 Travada' : '🔓 Destravada';
      return msg.reply(`❧ Descrição do grupo: ${status}`);
    }

    if (action === 'on') {
      const currentDesc = groupMetadata?.desc || '';
      db.updateChatSetting(msg.chat, 'lockdesc', true);
      db.updateChatSetting(msg.chat, 'lockeddesc', currentDesc);
      return msg.reply('❧ Descrição do grupo *travada* com sucesso! 🔒');
    }

    if (action === 'off') {
      db.updateChatSetting(msg.chat, 'lockdesc', false);
      return msg.reply('❧ Descrição do grupo *destravada*. 🔓');
    }
  },
};
