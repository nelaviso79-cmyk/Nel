export default {
  command: ['setgpbanner', 'setgpimg', 'setgpbaner'],
  category: 'grupos',
  description: 'Mudar a imagem do grupo.',
  isAdmin: true,
  botAdmin: true,
  run: async ({ msg, sock, usedPrefix, command }) => {
    const q = msg.quoted || msg;
    const mime = (q.msg || q).mimetype || q.mediaType || '';
    if (!/image/.test(mime)) {
      return msg.reply('《✧》 Falta a imagem para mudar o perfil do grupo.');
    }
    const img = await q.download();
    if (!img) return msg.reply('《✧》 Não foi possível baixar a imagem.');
    try {
      await sock.updateProfilePicture(msg.chat, img);
      msg.reply('✿ A imagem do grupo foi atualizada com sucesso.');
    } catch (e) {
      return msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  },
};