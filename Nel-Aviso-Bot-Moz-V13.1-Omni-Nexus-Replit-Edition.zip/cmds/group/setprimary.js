import fs from 'fs';
import path from 'path';
import db from '#db';

const getBotsFromFolder = (folderName, __dirname) => {
  const basePath = path.join(__dirname, '../../Sessions', folderName)
  if (!fs.existsSync(basePath)) return []
  return fs.readdirSync(basePath).filter((dir) => fs.existsSync(path.join(basePath, dir, 'creds.json'))).map((id) => id.replace(/\D/g, '') + '@s.whatsapp.net')
}

const getAllowedBots = (mainBotJid, __dirname) => {
  const subs = getBotsFromFolder('Subs', __dirname)
  return [...new Set([...subs, mainBotJid])]
}

export default {
  command: ['setprimary'],
  category: 'grupos',
  description: 'Definir un bot como primario do grupo.',
  isAdmin: true,
  run: async ({ msg, sock, usedPrefix, command, groupMetadata, participants, __dirname }) => {
    try {
      let chat = db.getChat(msg.chat);
      const who = msg.mentionedJid?.[0] || msg.quoted?.sender || null;
      if (!who) {
        return sock.reply(msg.chat, `《✧》 Por favor mencione um bot para torná-lo primário.`, msg);
      }
      const groupParticipants = participants.map(p => p.id);
      const mainBotJid = ((global.sock?.user?.id?.split(':')[0] ?? null) && ((global.sock?.user?.id?.split(':')[0] ?? null) && (global.sock.user.id.split(':')[0] + '@s.whatsapp.net')));
      const allowedBots = getAllowedBots(mainBotJid, __dirname);
      if (!allowedBots.includes(who)) {
        return sock.reply(msg.chat, `《✧》 O usuário mencionado não é uma instância de Sub-Bot.`, msg);
      }
      if (!groupParticipants.includes(who)) {
        return sock.reply(msg.chat, `《✧》 O bot mencionado não está presente neste grupo.`, msg);
      }
      if (chat.primaryBot === who) {
        return sock.reply(msg.chat, `「✿」 @${who.split('@')[0]} ya es el Bot principal del Grupo.`, msg, { mentions: [who] });
      }
      chat.primaryBot = who;
      db.setChat(msg.chat, 'primaryBot', who);
      await sock.reply(msg.chat, `ꕥ Foi definido @${who.split('@')[0]} como bot primario deste grupo.\n> Agora todos os comandos deste grupo serão executados por @${who.split('@')[0]}.`, msg, { mentions: [who] });
    } catch (e) {
      console.error(e);
      await msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  },
};