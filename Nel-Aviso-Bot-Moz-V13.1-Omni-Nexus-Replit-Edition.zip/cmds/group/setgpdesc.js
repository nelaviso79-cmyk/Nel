export default {
  command: ['setgpdesc'],
  category: 'grupos',
  description: 'Mudar a descrição do grupo.',
  isAdmin: true,
  botAdmin: true,
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const newDesc = args.join(' ').trim();
    if (!newDesc) {
      return msg.reply('《✧》 Por favor, insira a nova descrição que deseja pôr no grupo.');
    }
    try {
      await sock.groupUpdateDescription(msg.chat, newDesc);
      msg.reply('✿ A descrição do grupo foi modificada corretamente.');
    } catch (e) {
      return msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  },
};