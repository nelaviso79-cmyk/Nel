import db from '#db';
export default {
  command: ['mutargrupo', 'mutetempo', 'silenciargrupo', 'mutetmp'],
  category: 'moderacao',
  description: 'Silenciar o grupo temporariamente por um tempo determinado. Auto-desativa após o tempo.',
  isAdmin: true,
  botAdmin: true,
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const setting = db.getChatSetting(msg.chat);
    const timeArg = args[0];

    if (!timeArg || ['status', 'info'].includes(timeArg?.toLowerCase())) {
      const muteUntil = setting?.muteUntil;
      if (muteUntil && muteUntil > Date.now()) {
        const remaining = muteUntil - Date.now();
        const h = Math.floor(remaining / 3600000);
        const m = Math.floor((remaining % 3600000) / 60000);
        const s = Math.floor((remaining % 60000) / 1000);
        return msg.reply(`🔇 O grupo está silenciado. Tempo restante: *${h}h ${m}m ${s}s*`);
      }
      return msg.reply(
        `🔇 *Mute Temporário*\n\n` +
        `Silencia o grupo por um tempo determinado. Apenas admins podem falar.\n\n` +
        `✎ *Formatos de tempo:*\n` +
        `> *${usedPrefix + command} 30m* - Silenciar por 30 minutos\n` +
        `> *${usedPrefix + command} 2h* - Silenciar por 2 horas\n` +
        `> *${usedPrefix + command} 1d* - Silenciar por 1 dia\n` +
        `> *${usedPrefix + command} off* - Desativar o mute\n` +
        `> *${usedPrefix + command} status* - Ver estado atual`
      );
    }

    if (timeArg.toLowerCase() === 'off' || timeArg.toLowerCase() === 'desativar') {
      db.updateChatSetting(msg.chat, 'muteUntil', 0);
      await sock.groupSettingUpdate(msg.chat, 'not_announcement');
      return msg.reply('🔇 Mute temporário desativado! O grupo está aberto novamente. 🔊');
    }

    // Parse time
    const match = timeArg.match(/^(\d+)(s|m|h|d)$/i);
    if (!match) {
      return msg.reply(`🔇 Formato inválido! Usa: *30m*, *2h*, *1d*\n✎ Exemplo: *${usedPrefix + command} 30m*`);
    }

    const num = parseInt(match[1]);
    const unit = match[2].toLowerCase();
    let ms;
    let textTime;
    switch (unit) {
      case 's': ms = num * 1000; textTime = `${num} segundo${num > 1 ? 's' : ''}`; break;
      case 'm': ms = num * 60000; textTime = `${num} minuto${num > 1 ? 's' : ''}`; break;
      case 'h': ms = num * 3600000; textTime = `${num} hora${num > 1 ? 's' : ''}`; break;
      case 'd': ms = num * 86400000; textTime = `${num} dia${num > 1 ? 's' : ''}`; break;
    }

    if (ms < 30000) return msg.reply('🔇 O tempo mínimo é de 30 segundos.');
    if (ms > 86400000 * 7) return msg.reply('🔇 O tempo máximo é de 7 dias.');

    const muteUntil = Date.now() + ms;
    db.updateChatSetting(msg.chat, 'muteUntil', muteUntil);

    // Set group to announcement mode (only admins can send)
    await sock.groupSettingUpdate(msg.chat, 'announcement');

    // Auto-unmute after time
    setTimeout(async () => {
      try {
        const currentSetting = db.getChatSetting(msg.chat);
        if (currentSetting?.muteUntil && currentSetting.muteUntil <= Date.now()) {
          db.updateChatSetting(msg.chat, 'muteUntil', 0);
          await sock.groupSettingUpdate(msg.chat, 'not_announcement');
          await sock.sendMessage(msg.chat, { text: '🔊 O mute temporário terminou! O grupo está aberto novamente.' });
        }
      } catch (e) {
        console.error('Auto-unmute error:', e);
      }
    }, ms);

    return msg.reply(`🔇 Grupo silenciado por *${textTime}*. Apenas admins podem falar.\n> Para desativar antes: *${usedPrefix + command} off*`);
  },
};
