export default {
  command: ['unmute', 'desmutar', 'dessilenciar'],
  category: 'moderacao',
  description: 'Remover silêncio de um membro do grupo.',
  isAdmin: true,
  botAdmin: true,
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    if (!msg.mentionedJid[0] && !msg.quoted) {
      return msg.reply(`❧ Por favor, marque ou responda à mensagem da pessoa que deseja remover do silêncio.\n\n✎ Exemplo: *${usedPrefix + command} @usuário*`);
    }
    const target = msg.mentionedJid[0] || msg.quoted.sender;

    try {
      await sock.groupParticipantsUpdate(msg.chat, [target], 'promote');
      await new Promise(r => setTimeout(r, 500));
      await sock.groupParticipantsUpdate(msg.chat, [target], 'demote');
      await sock.sendMessage(msg.chat, { text: `✎ @${target.split('@')[0]} já pode *enviar mensagens* novamente no grupo.`, mentions: [target] }, { quoted: msg });
    } catch (e) {
      return msg.reply(`❧ Ocorreu um erro ao tentar remover o silêncio deste membro.\n> Erro: *${e.message}*`);
    }
  },
};
