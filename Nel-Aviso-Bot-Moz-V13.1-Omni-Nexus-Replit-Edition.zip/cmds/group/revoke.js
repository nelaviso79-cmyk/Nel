export default {
  command: ['revoke', 'restablecer'],
  category: 'grupos',
  description: 'Restabelecer o link do grupo.',
  botAdmin: true,
  run: async ({ msg, sock, usedPrefix, command }) => {
    try {
      await sock.groupRevokeInvite(msg.chat);
      const code = await sock.groupInviteCode(msg.chat);
      const link = `https://chat.whatsapp.com/${code}`;
      const teks = `﹒⌗﹒🌿 .ৎ˚₊‧  O link do grupo foi restabelecido:\n\n𐚁 ֹ ִ \`NEW GROUP LINK\` ! ୧ ֹ ִ🔗\n☘️ \`Solicitado por :\` @${msg.sender.split('@')[0]}\n\n🌱 \`Link :\` ${link}`;
      await msg.react('🕒');
      await sock.reply(msg.chat, teks, msg, { mentions: [msg.sender] });
      await msg.react('✔️');
    } catch (e) {
      await msg.react('✖️');
      await msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  },
};