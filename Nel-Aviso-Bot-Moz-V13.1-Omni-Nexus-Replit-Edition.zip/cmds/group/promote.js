export default {
  command: ['promote', 'promover'],
  category: 'grupos',
  description: 'Promover um usuário a administrador.',
  isAdmin: true,
  botAdmin: true,
  run: async ({ msg, sock, usedPrefix, command, groupMetadata, participants }) => {
    const who = msg.mentionedJid?.[0] || msg.quoted?.sender;
    if (!who) return msg.reply('《✧》 Mencione o usuário que deseja promover a administrador.');
    try {
      const whoBase = who.split('@')[0];
      const participant = participants.find(p => p.id?.split('@')[0] === whoBase || p.lid?.split('@')[0] === whoBase);
      if (participant?.admin) {
        return sock.sendMessage(msg.chat, { text: `《✧》 *@${whoBase}* já é administrador do grupo!`, mentions: [who] }, { quoted: msg });
      }
      const targetJid = participant?.id || who;
      await sock.groupParticipantsUpdate(msg.chat, [targetJid], 'promote');
      await sock.sendMessage(msg.chat, { text: `✿ *@${whoBase}* foi promovido a administrador do grupo!`, mentions: [who] }, { quoted: msg });
    } catch (e) {
      await msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  },
};
