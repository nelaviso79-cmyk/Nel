import db from '#db';
export default {
  command: ['setgoodbye'],
  category: 'grupos',
  description: 'Definir uma mensagem de despedida personalizada.',
  isAdmin: true,
  run: async ({ msg, args, usedPrefix, command }) => {
    const chatId = msg.chat;
    let chat = db.getChat(chatId);
    if (!args.length) {
      return msg.reply(`ꕤ ꨩᰰ𑪐𑂺 ˳ ׄ Set Bye ࣭𑁯ᰍ   ̊ ܃܃

*❒ Variáveis disponíveis:*
𖣣ֶㅤ֯⌗ ✤ ⬭ @user    
> → Menção do usuário que sai

𖣣ֶㅤ֯⌗ ✤ ⬭ @group   
> → Nome do grupo

𖣣ֶㅤ֯⌗ ✤ ⬭ @desc    
> → Descrição do grupo

𖣣ֶㅤ֯⌗ ✤ ⬭ @members 
> → Número de miembros actuales

𖣣ֶㅤ֯⌗ ✤ ⬭ @time    
> → Data y hora

✿ Se já tens uma mensagem configurada e queres apagá-la usa: *${usedPrefix + command} clear*`);
    }
    if (args[0] === 'clear') {
      if (!chat.sGoodbye || chat.sGoodbye.trim() === '') {
        return msg.reply('✎ Não tem ningún mensagem de despedida definido.');
      }
      chat.sGoodbye = '';
      db.setChat(chatId, 'sGoodbye', '');
      return msg.reply('✐ Mensagem de despedida eliminado.');
    }
    const texto = args.join(' ');
    chat.sGoodbye = texto;
    db.setChat(chatId, 'sGoodbye', texto);
    msg.reply(`ꕥ Definiste a mensagem de despedida corretamente.`);
  }
};