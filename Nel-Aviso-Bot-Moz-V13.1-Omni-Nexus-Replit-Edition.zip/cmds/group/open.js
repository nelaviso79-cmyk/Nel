export default {
  command: ['open', 'abrir'],
  category: 'grupos',
  description: 'Abrir o grupo para que todos possam enviar mensagens.',
  isAdmin: true,
  botAdmin: true,
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    try {
      const timeout = args[0] ? msParser(args[0]) : 0;
      if (args[0] && !timeout) {
        return sock.reply(msg.chat, 'Formato inválido. Use por exemplo: 10s, 5m, 2h, 1d', msg);
      }
      const groupMetadata = await sock.groupMetadata(msg.chat);
      const groupAnnouncement = groupMetadata.announce;
      if (groupAnnouncement === false) {
        return sock.reply(msg.chat, `《✧》 O grupo já está aberto.`, msg);
      }
      const applyAction = async () => {
        await sock.groupSettingUpdate(msg.chat, 'not_announcement');
        return sock.reply(msg.chat, `✿ O grupo foi abierto corretamente.`, msg);
      };
      if (timeout > 0) {
        await sock.reply(msg.chat, `❀ O grupo vai abrir em ${clockString(timeout)}.`, msg);
        setTimeout(async () => {
          try {
            const md = await sock.groupMetadata(msg.chat);
            if (md.announce === false) return;
            await applyAction();
          } catch {}
        }, timeout);
      } else {
        await applyAction();
      }
    } catch (e) {
      return msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  },
};

function msParser(str) {
  const match = str.match(/^(\d+)([smhd])$/i);
  if (!match) return null;
  const num = parseInt(match[1]);
  const unit = match[2].toLowerCase();
  switch (unit) {
    case 's': return num * 1000;
    case 'm': return num * 60 * 1000;
    case 'h': return num * 60 * 60 * 1000;
    case 'd': return num * 24 * 60 * 60 * 1000;
    default: return null;
  }
}

function clockString(ms) {
  const d = Math.floor(ms / 86400000);
  const h = Math.floor(ms / 3600000) % 24;
  const m = Math.floor(ms / 60000) % 60;
  const s = Math.floor(ms / 1000) % 60;
  let parts = [];
  if (d > 0) parts.push(`${d} ${d === 1 ? 'dia' : 'dias'}`);
  if (h > 0) parts.push(`${h} ${h === 1 ? 'hora' : 'horas'}`);
  if (m > 0) parts.push(`${m} ${m === 1 ? 'minuto' : 'minutos'}`);
  if (s > 0) parts.push(`${s} ${s === 1 ? 'segundo' : 'segundos'}`);
  return parts.join(' ');
}