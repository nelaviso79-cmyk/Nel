export default {
  command: ['marcar', 'marcartodos', 'marcartodos', 'notificartodos'],
  category: 'grupos',
  description: 'Mencionar todos os membros do grupo 📢',
  run: async ({ msg, sock, usedPrefix, command, text, participants, isAdmins }) => {
    if (!msg.isGroup) return msg.reply('◈ Este comando só funciona em grupos!');
    
    const mentioned = participants
      .filter(p => p.id)
      .map(p => p.id);
    
    const header = text ? `📢 *${text}*` : `📢 *ATENÇÃO GERAL*`;
    
    let body = '';
    let i = 1;
    for (const p of participants) {
      if (!p.id) continue;
      const num = p.id.split('@')[0];
      const name = p.notify || num;
      body += `▸ ${i}. @${num}\n`;
      i++;
    }
    
    return msg.reply(
      `${header}\n\n` +
      `👥 *Membros: ${participants.length}*\n\n` +
      `${body}\n` +
      `_📢 Nel-Aviso-Bot-Moz_`,
      { mentions: mentioned }
    );
  }
};
