export default {
  command: ['poll', 'enquete', 'enquetar'],
  category: 'grupos',
  description: 'Criar uma enquete oficial no grupo usando o sistema nativo do WhatsApp.',
  isAdmin: true,
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    if (!args.length) {
      return msg.reply(
        `❧ *Enquete no Grupo* 📊\n\n` +
        `✎ Como usar:\n` +
        `> *${usedPrefix + command} pergunta | opção1 | opção2 | opção3*\n\n` +
        `▸ Exemplo: *${usedPrefix + command} Qual a melhor fruta? | Manga | Banana | Laranja*\n` +
        `▸ Máximo: 12 opções`
      );
    }

    const parts = args.join(' ').split('|').map(p => p.trim()).filter(Boolean);
    if (parts.length < 3) {
      return msg.reply(`❧ Precisas de pelo menos uma pergunta e 2 opções.\n✎ Exemplo: *${usedPrefix + command} Pergunta? | Opção1 | Opção2*`);
    }

    const question = parts[0];
    const options = parts.slice(1).slice(0, 12); // Max 12 options

    try {
      await sock.sendMessage(msg.chat, {
        poll: {
          name: question,
          values: options,
          selectableCount: 1
        }
      });
    } catch (e) {
      // Fallback to text-based poll if native poll fails
      let text = `❧ *ENQUETE* 📊\n\n▸ *${question}*\n\n`;
      const emojis = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟', '1️⃣1️⃣', '1️⃣2️⃣'];
      options.forEach((opt, i) => {
        text += `${emojis[i] || '•'} ${opt}\n`;
      });
      return msg.reply(text);
    }
  },
};
