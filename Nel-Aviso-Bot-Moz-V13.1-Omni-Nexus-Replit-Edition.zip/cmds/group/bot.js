import db from '#db';
export default {
  command: ['bot'],
  category: 'grupos',
  description: 'Activar ou desactivar o bot no grupo.',
  isAdmin: true,
  run: async ({ msg, sock, args }) => {
    const chat = db.getChat(msg.chat);
    const botId = sock.user.id.split(':')[0] + "@s.whatsapp.net";
    const botSettings = db.getSettings(botId) || {};
    const namebot = botSettings.namebot || 'Bot';
    const estado = chat.isBanned ? 1 : 0;
    if (args[0] === 'off') {
      if (estado) return msg.reply('《✧》 O *Bot* já estava *desativado* neste grupo.');
      chat.isBanned = 1;
      db.setChat(msg.chat, 'isBanned', 1);
      return msg.reply(`《✧》 Você *Desativou* a *${namebot}* neste grupo.`);
    }
    if (args[0] === 'on') {
      if (!estado) return msg.reply(`《✧》 *${namebot}* já estava *ativado* neste grupo.`);
      chat.isBanned = 0;
      db.setChat(msg.chat, 'isBanned', 0);
      return msg.reply(`《✧》 Você *Ativou* a *${namebot}* neste grupo.`);
    }
    return msg.reply(`*✿ Estado de ${namebot} (｡•́‿•̀｡)*\n✐ *Actual ›* ${estado ? '✗ Desativado' : '✓ Ativado'}\n\n✎ Podes mudar com:\n> ● _Activar ›_ *bot on*\n> ● _Desactivar ›_ *bot off*`);
  },
};