import ws from 'ws';
import fs from 'fs';
import db from '#db';

export default {
  command: ['gp', 'gpinfo', 'groupinfo'],
  category: 'grupos',
  description: 'Ver a informação do grupo.',
  run: async ({ msg, sock, usedPrefix, command, groupMetadata, participants }) => {
    const groupName = groupMetadata?.subject;
    const groupBanner = await sock.profilePictureUrl(msg.chat, 'image').catch(() => 'https://cdn.yuki-wabot.my.id/files/2PVh.jpeg');
    const groupCreator = groupMetadata?.owner ? '@' + groupMetadata.owner.split('@')[0] : 'Desconhecido';
    const groupAdmins = participants.filter(p => (p.admin === 'admin' || p.admin === 'superadmin')) || [];
    const totalParticipants = participants.length;
    const chat = db.getChat(msg.chat) || {};
    const allChatUsers = db.getChatUser(msg.chat);
    const usersMap = {};
    for (const user of allChatUsers) {
      usersMap[user.user_id] = user;
    }
    const botId = sock.user.id.split(':')[0] + "@s.whatsapp.net";
    const botSettings = db.getSettings(botId) || {};
    const botname = botSettings.botname;
    const moedas = botSettings.currency;
    let totalCoins = 0;
    let registeredUsersInGroup = 0;
    const resolvedParticipants = participants;
    for (const participant of resolvedParticipants) {
      const fullId = participant.id;
      const user = fullId ? usersMap[fullId] : null;
      if (user) {
        registeredUsersInGroup++;
        totalCoins += Number(user.coins || 0) + Number(user.bank || 0);
      }
    }
    const charactersFilePath = './core/characters.json';
    const data = await fs.promises.readFile(charactersFilePath, 'utf-8');
    const structure = JSON.parse(data);
    const allCharacters = Object.values(structure).flatMap(s => Array.isArray(s.characters) ? s.characters : []);
    const totalCharacters = allCharacters.length;
    let claimedCount = 0;
    for (const user of allChatUsers) {
      if (user.characters && typeof user.characters === 'string') {
        try { user.characters = JSON.parse(user.characters); } catch { user.characters = []; }
      }
      if (Array.isArray(user.characters)) claimedCount += user.characters.length;
    }
    const claimRate = totalCharacters > 0 ? ((claimedCount / totalCharacters) * 100).toFixed(2) : '0.00';
    const rawPrimary = typeof chat.primaryBot === 'string' ? chat.primaryBot : '';
    const botprimary = rawPrimary.endsWith('@s.whatsapp.net') ? `@${rawPrimary.split('@')[0]}` : 'Aleatorio';
    const settings = {
      bot: chat.isBanned ? '✘ Desativado' : '✓ Ativado',
      antilinks: chat.antilinks ? '✓ Ativado' : '✘ Desativado',
      antistatus: chat.antistatus ? '✓ Ativado' : '✘ Desativado',
      welcome: chat.welcome ? '✓ Ativado' : '✘ Desativado',
      goodbye: chat.goodbye ? '✓ Ativado' : '✘ Desativado',
      alerts: chat.alerts ? '✓ Ativado' : '✘ Desativado',
      gacha: chat.gacha ? '✓ Ativado' : '✘ Desativado',
      economy: chat.economy ? '✓ Ativado' : '✘ Desativado',
      nsfw: chat.nsfw ? '✓ Ativado' : '✘ Desativado',
      adminmode: chat.adminonly ? '✓ Ativado' : '✘ Desativado',
      botprimary: botprimary
    };
    try {
      let message = `*「✿」Grupo ◢ ${groupName} ◤*\n\n`;
      message += `➪ *Criador ›* ${groupCreator}\n`;
      message += `❖ Bot Principal › *${settings.botprimary}*\n`;
      message += `♤ Admins › *${groupAdmins.length}*\n`;
      message += `❒ Usuários › *${totalParticipants}*\n`;
      message += `ꕥ Registados › *${registeredUsersInGroup}*\n`;
      message += `✿ Claims › *${claimedCount} (${claimRate}%)*\n`;
      message += `♡ Personagens › *${totalCharacters}*\n`;
      message += `⛁ Dinheiro › *${totalCoins.toLocaleString()} ${moedas}*\n\n`;
      message += `➪ *Configurações:*\n`;
      message += `✐ ${botname} › *${settings.bot}*\n`;
      message += `✐ AntiLinks › *${settings.antilinks}*\n`;
      message += `✐ AntiStatus › *${settings.antistatus}*\n`
      message += `✐ Boas-Vindas › *${settings.welcome}*\n`;
      message += `✐ Despedida › *${settings.goodbye}*\n`;
      message += `✐ Alertas › *${settings.alerts}*\n`;
      message += `✐ Gacha › *${settings.gacha}*\n`;
      message += `✐ Economia › *${settings.economy}*\n`;
      message += `✐ Nsfw › *${settings.nsfw}*\n`;
      message += `✐ ModoAdmin › *${settings.adminmode}*`;
      const mentionOw = groupMetadata?.owner ? groupMetadata.owner : '';
      const mentions = [rawPrimary, mentionOw].filter(Boolean);
      await sock.sendMessage(msg.chat, { text: message.trim(), mentions });
    } catch (e) {
      await msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  }
};