export default {
  command: ['demote', 'degradar'],
  category: 'grupos',
  description: 'Rebaixar um usuário de administrador.',
  isAdmin: true,
  botAdmin: true,
  run: async ({ msg, sock, usedPrefix, command, groupMetadata, participants }) => {
    const who = msg.mentionedJid?.[0] || msg.quoted?.sender;
    if (!who) return msg.reply('《✧》 Mencione o usuário que deseja rebaixar de administrador.');
    try {
      const ownerGroup = groupMetadata?.owner || msg.chat.split('-')[0] + '@s.whatsapp.net';
      const ownerBot = global.owner + '@s.whatsapp.net';
      const whoBase = who.split('@')[0];
      const participant = participants.find(p => p.id?.split('@')[0] === whoBase || p.lid?.split('@')[0] === whoBase);
      if (!participant?.admin) {
        return sock.sendMessage(msg.chat, { text: `《✧》 *@${whoBase}* no es administrador do grupo!`, mentions: [who] }, { quoted: msg });
      }
      const targetJid = participant?.id || who;
      if (targetJid === ownerGroup) return msg.reply('《✧》 No podes degradar al creador do grupo de administrador.');
      if (targetJid === ownerBot) return msg.reply('《✧》 No podes degradar al creador do bot de administrador.');
      if (targetJid === sock.decodeJid(sock.user.id)) return msg.reply('《✧》 No podes degradar o bot de administrador.');
      await sock.groupParticipantsUpdate(msg.chat, [targetJid], 'demote');
      await sock.sendMessage(msg.chat, { text: `✿ *@${whoBase}* foi degradado de administrador do grupo!`, mentions: [who] }, { quoted: msg });
    } catch (e) {
      await msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  },
};