import fetch from 'node-fetch';
import fs from 'fs';
import db from '#db';

const captions = {      
  anal: (from, to) => from === to ? 'enfiou-lhe no cu.' : 'enfiou-lhe no cu a',
  cum: (from, to) => from === to ? 'gozou dentro de... omitiremos detalhes.' : 'gozou dentro de',
  undress: (from, to) => from === to ? 'está a despir-se' : 'está a despir-se a',
  fuck: (from, to) => from === to ? 'entrega-se ao desejo' : 'está a transar com',
  spank: (from, to) => from === to ? 'está a dar um spanking' : 'está a dar um spanking a',
  lickpussy: (from, to) => from === to ? 'está a lamber uma cona' : 'está a lamber a cona a',
  fap: (from, to) => from === to ? 'está a masturbar-se' : 'está a masturbar-se pensando en',
  grope: (from, to) => from === to ? 'está a apalpar-se' : 'está a apalpar-se a',
  sixnine: (from, to) => from === to ? 'está a fazer um 69' : 'está a fazer um 69 con',
  suckboobs: (from, to) => from === to ? 'está a chupar umas tetas gostosas' : 'está a chupar as tetas a',
  grabboobs: (from, to) => from === to ? 'está a agarrar umas tetas' : 'está a agarrar as tetas a',
  blowjob: (from, to) => from === to ? 'está a dar uma mamada' : 'deu uma mamada a',
  boobjob: (from, to) => from === to ? 'está a fazer uma russa' : 'está a fazer uma russa a',
  footjob: (from, to) => from === to ? 'está a fazer uma punheta com os pés' : 'está a fazer uma punheta com os pés a',
  yuri: (from, to) => from === to ? 'está a fazer tesouras!' : 'fez tesouras com',
  cummouth: (from, to) => from === to ? 'está a encher a boca de alguém com carinho' : 'está a encher a boca de',
  cumshot: (from, to) => from === to ? 'enfiou a alguém e agora vem o presente' : 'deu um presente surpresa a',
  handjob: (from, to) => from === to ? 'faz uma punheta a alguém com carinho' : 'está a fazer uma punheta a',
  lickass: (from, to) => from === to ? 'saboreia um cu sem parar' : 'está a lamber o cu a',
  lickdick: (from, to) => from === to ? 'chupa com vontade um pénis' : 'mete tudo na boca para',
  fingering: (from, to) => from === to ? 'está a meter os dedos' : 'está a meter os dedos a',
  creampie: (from, to) => from === to ? 'terminou dentro sem avisar...' : 'terminou dentro de',
  facesitting: (from, to) => from === to ? 'está a sentar-se numa cara' : 'sentou-se na cara de',
  deepthroat: (from, to) => from === to ? 'engole até ao fundo' : 'está a fazer uma garganta profunda a',
  thighjob: (from, to) => from === to ? 'está a esfregar entre as coxas' : 'está a fazer uma entre pernas a',
  bondage: (from, to) => from === to ? 'está amarrado e sem escape...' : 'amarrou bem a',
  pegging: (from, to) => from === to ? 'está a receber o que não esperava' : 'está a dar por trás a',
  futanari: (from, to) => from === to ? 'tem o melhor dos dois mundos' : 'demonstrou o que tem a',
  yaoi: (from, to) => from === to ? 'está a desfrutar de um momento muito intenso' : 'passou-se genial com',
  bukkake: (from, to) => from === to ? 'terminou só... de uma forma muito especial' : 'convidou os seus amigos a acabar em cima de',
  orgy: (from, to) => from === to ? 'está numa orgia' : 'organizou uma orgia com',
  squirting: (from, to) => from === to ? 'chegou ao limite e veio com tudo' : 'levou-a ao limite até que veio com tudo'
};

const symbols = ['(⁠◠⁠‿⁠◕⁠)', '˃͈◡˂͈', '૮(˶ᵔᵕᵔ˶)ა', '(づ｡◕‿‿◕｡)づ', '(✿◡‿◡)', '(꒪⌓꒪)', '(✿✪‿✪｡)', '(*≧ω≦)', '(✧ω◕)', '˃ 𖥦 ˂', '(⌒‿⌒)', '(¬‿¬)', '(✧ω✧)',  '✿(◕ ‿◕)✿',  'ʕ•́ᴥ•̀ʔっ', '(ㅇㅅㅇ❀)',  '(∩︵∩)',  '(✪ω✪)',  '(✯◕‿◕✯)', '(•̀ᴗ•́)و ̑̑'];

function getRandomSymbol() {
  return symbols[Math.floor(Math.random() * symbols.length)];
}

const alias = {
  anal: ['anal','violar'],
  cum: ['cum'],
  undress: ['undress','despir'],
  fuck: ['fuck','transar'],
  spank: ['spank','nalgada'],
  lickpussy: ['lickpussy'],
  fap: ['fap','punheta'],
  grope: ['grope'],
  sixnine: ['sixnine','69'],
  suckboobs: ['suckboobs'],
  grabboobs: ['grabboobs'],
  blowjob: ['blowjob','mamada','bj'],
  boobjob: ['boobjob'],
  yuri: ['yuri','tesouras'],
  footjob: ['footjob'],
  cummouth: ['cummouth'],
  cumshot: ['cumshot'],
  handjob: ['handjob'],
  lickass: ['lickass'],
  lickdick: ['lickdick'],
  fingering: ['fingering'],
  creampie: ['creampie'],
  facesitting: ['facesitting'],
  deepthroat: ['deepthroat'],
  thighjob: ['thighjob'],
  bondage: ['bondage'],
  pegging: ['pegging'],
  futanari: ['futanari', 'futa'],
  yaoi: ['yaoi'],
  bukkake: ['bukkake'],
  orgy: ['orgy','orgia'],
  squirting: ['squirt', 'squirting']
};

export default {
  command: ['anal','violar','cum','undress','despir','fuck','transar','spank','nalgada','lickpussy','fap','punheta','grope','sixnine','69','suckboobs','grabboobs','blowjob','mamada','bj','boobjob','yuri','tesouras','footjob','cummouth','cumshot','handjob','lickass','lickdick','fingering','creampie','facesitting','deepthroat','thighjob','bondage','pegging','futanari','futa','yaoi','bukkake','orgy','orgia','squirt','squirting'],
  category: 'nsfw',
  description: 'Comandos de reacções NSFW entre utilizadores.',
  run: async ({ msg, sock, usedPrefix, command }) => {
    const chat = db.getChat(msg.chat);
    if (!chat.nsfw) return msg.reply(`ꕥ O conteúdo *NSFW* está desativado neste grupo.\n\nUm *administrador* pode ativá-lo com o comando:\n» *${usedPrefix}nsfw on*`);
    const currentCommand = Object.keys(alias).find(key => alias[key].includes(command)) || command;
    if (!captions[currentCommand]) return;
    const who = msg.mentionedJid?.[0] || msg.quoted?.sender || msg.sender;
    const from = db.getUser(msg.sender);
    const fromName = from?.name || '@'+msg.sender.split('@')[0];    
    const to = db.getUser(who);
    const toName = to?.name || '@'+who.split('@')[0];
    const captionText = captions[currentCommand](fromName, toName);
    const caption = who !== msg.sender ? `\`${fromName}\` ${captionText} \`${toName}.\` ${getRandomSymbol()}.` : `\`${fromName}\` ${captionText} ${getRandomSymbol()}.`;
    try {
      const shares = './core/shares.json'
      const sharesData = JSON.parse(fs.readFileSync(shares))
      const videos = sharesData.nsfw[currentCommand]
      const randomVideo = videos[Math.floor(Math.random() * videos.length)];
      await sock.sendMessage(msg.chat, { video: { url: randomVideo }, gifPlayback: true, caption, mentions: [who, msg.sender] }, { quoted: msg });
    } catch (e) {
      await msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  }
};
