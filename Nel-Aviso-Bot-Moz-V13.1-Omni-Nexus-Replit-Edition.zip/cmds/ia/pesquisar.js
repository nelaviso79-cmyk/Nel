import fetch from 'node-fetch';
import cheerio from 'cheerio';

export default {
  command: ['pesquisar', 'google', 'search', 'web'],
  category: 'ia',
  description: 'Pesquisa na web em tempo real para obter informações atualizadas.',
  run: async ({ msg, sock, text, usedPrefix, command }) => {
    if (!text) return msg.reply(`🔍 *PESQUISA WEB EM TEMPO REAL* 🔍\n\n▸ O que queres saber?\n▸ Exemplo: *${usedPrefix + command} preço do ouro hoje em Moçambique*`);

    await msg.react('🌐');
    try {
      // Usando uma API de busca ou scraping do Google (via proxy/api estável)
      const res = await fetch(`https://api.vreden.web.id/api/search/google?query=${encodeURIComponent(text)}`);
      const json = await res.json();
      
      if (!json.status || !json.result || json.result.length === 0) {
        return msg.reply('❌ Não encontrei resultados recentes para essa pesquisa.');
      }

      let resposta = `🌐 *RESULTADOS DA PESQUISA* 🌐\n\n`;
      json.result.slice(0, 4).forEach((item, i) => {
        resposta += `*${i + 1}. ${item.title}*\n📖 ${item.description}\n🔗 ${item.link}\n\n`;
      });

      resposta += `> 💡 _Pesquisa realizada em tempo real via Nel-Aviso-Bot-Moz_`;

      await msg.reply(resposta);
      await msg.react('✅');
    } catch (e) {
      console.error(e);
      await msg.react('❌');
      await msg.reply(`❌ Erro ao pesquisar na web: ${e.message}`);
    }
  }
};
