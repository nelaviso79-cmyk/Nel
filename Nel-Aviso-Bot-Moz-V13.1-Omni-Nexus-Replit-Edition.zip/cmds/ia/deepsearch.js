import fetch from 'node-fetch';

export default {
  command: ['deepsearch', 'pesquisa-profunda', 'investigar'],
  category: 'ia',
  description: 'Realiza uma investigação profunda sobre qualquer tema global.',
  run: async ({ msg, sock, text, usedPrefix, command }) => {
    if (!text) return msg.reply(`🔍 *DEEPSEARCH INVESTIGAÇÃO* 🔍\n\n▸ Qual o tema da investigação?\n▸ Exemplo: *${usedPrefix + command} O impacto da IA na economia de África*`);

    await msg.react('🔎');
    try {
      // Usando uma API de busca avançada com resumo de IA
      const res = await fetch(`https://api.vreden.web.id/api/ai/blackbox?text=Faz+uma+investigação+profunda+e+detalhada+sobre:+${encodeURIComponent(text)}`);
      const json = await res.json();
      
      if (!json.status || !json.result) {
        throw new Error('Investigação falhou.');
      }

      const resposta = `🔎 *RELATÓRIO DE INVESTIGAÇÃO DEEPSEARCH* 🔎\n\n` +
                       `📌 *Tema:* ${text}\n\n` +
                       `${json.result}\n\n` +
                       `> 👑 _Nel-Aviso-Bot V11: Conhecimento sem limites._`;

      await msg.reply(resposta);
      await msg.react('✅');
    } catch (e) {
      console.error(e);
      await msg.react('❌');
      await msg.reply(`❌ Erro na investigação: ${e.message}`);
    }
  }
};
