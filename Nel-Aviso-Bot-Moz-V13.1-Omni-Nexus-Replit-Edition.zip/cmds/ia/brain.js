import fetch from 'node-fetch';

export default {
  command: ['brain', 'nel', 'inteligencia'],
  category: 'ia',
  description: 'Ativa o núcleo de inteligência autónoma Nexus V12.',
  run: async ({ msg, sock, text, usedPrefix, command }) => {
    if (!text) return msg.reply(`🧠 *NEXUS-BRAIN: INTELIGÊNCIA CENTRAL* 🧠\n\n▸ Olá! Eu sou o núcleo de inteligência Nexus V12.\n▸ Como posso ajudar o seu império hoje?\n\nExemplo: *${usedPrefix + command} Como otimizar o meu tempo?*`);
    
    await msg.react('🧠');
    try {
      const prompt = `Tu és o Nexus Intelligence V12, o assistente pessoal de alta performance criado por Nel Custódio em Moçambique. Tu és extremamente inteligente, profissional, eficiente e focado em produtividade. Responde sempre em português de forma elegante e útil.`;
      const res = await fetch(`https://api.vreden.web.id/api/ai/chatgpt?prompt=${encodeURIComponent(prompt)}&text=${encodeURIComponent(text)}`);
      const json = await res.json();
      
      if (!json.status || !json.result) throw new Error('Falha no núcleo Nexus.');
      
      await msg.reply(`${json.result}\n\n> 🧠 _Nexus Intelligence V12 Autonomous_`);
      await msg.react('✅');
    } catch (e) {
      console.error(e);
      await msg.react('❌');
      await msg.reply(`❌ O núcleo Nexus está em processamento intenso. Tente novamente em instantes.`);
    }
  }
};
