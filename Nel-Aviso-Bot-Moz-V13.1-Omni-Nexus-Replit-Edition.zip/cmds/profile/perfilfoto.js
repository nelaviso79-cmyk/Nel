export default {
  command: ['perfilfoto', 'setpfoto', 'minhafoto', 'verfoto'],
  category: 'perfil',
  description: 'Definir ou ver a foto de perfil de alguém',
  run: async ({ msg, sock, usedPrefix, command, args, sender, participants }) => {
    const isQuotedImage = msg.quoted?.message?.imageMessage;
    const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
    const target = mentioned || (msg.quoted ? msg.quoted.sender : null);
    
    if (command === 'verfoto' || command === 'perfilfoto') {
      // Ver foto de perfil
      let who = target || sender;
      try {
        const ppUrl = await sock.profilePictureUrl(who, 'image').catch(() => null);
        if (!ppUrl) return msg.reply('❥ Este usuário não tem foto de perfil visível.');
        return sock.sendMessage(msg.chat, { 
          image: { url: ppUrl }, 
          caption: `❥ Foto de perfil de @${who.split('@')[0]}`,
          mentions: [who]
        }, { quoted: msg });
      } catch {
        return msg.reply('❥ Não foi possível obter a foto de perfil.');
      }
    }
    
    // Definir foto de perfil do bot (apenas dono)
    if (!isQuotedImage) {
      return msg.reply(`❥ Responda a uma imagem para definir como foto de perfil do bot.\n\n✎ Exemplo: responda a uma imagem com *${usedPrefix + command}*`);
    }
    
    return msg.reply(`❥ Para alterar a foto de perfil do bot, use o comando *${usedPrefix}setpfp*.`);
  },
};
