import db from '#db';
export default {
  command: ['delgenre'],
  category: 'perfil',
  description: 'Eliminerar o seu género do perfil.',
  run: async ({ msg }) => {
    const user = db.getUser(msg.sender);
    if (!user.genre) {
      return msg.reply(`《✧》 Não tem um género atribuído.`);
    }    
    db.setUser(msg.sender, 'genre', '');
    return msg.reply(`✎ Tu género foi eliminado.`);
  },
};