import db from '#db';
export default {
  command: ['delbirth'],
  category: 'perfil',
  description: 'Apagar a sua data de aniversário.',
  run: async ({ msg }) => {
    const user = db.getUser(msg.sender);
    if (!user.birth) {
      return msg.reply(`《✧》 Não tem uma data de nascimento definida.`);
    }    
    db.setUser(msg.sender, 'birth', '');
    return msg.reply(`✎ Tu fecha de nascimento foi eliminada.`);
  },
};