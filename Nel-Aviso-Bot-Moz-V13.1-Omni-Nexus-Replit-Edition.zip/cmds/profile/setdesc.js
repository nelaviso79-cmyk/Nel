import db from '#db';
export default {
  command: ['setdescription', 'setdesc'],
  category: 'perfil',
  description: 'Definir sua descrição de perfil.',
  run: async ({ msg, args, usedPrefix, command }) => {
    const user = db.getUser(msg.sender);
    const input = args.join(' ');    
    if (!input) return msg.reply(`《✧》 Deve especificar uma descrição válida para seu perfil.\n\n> ✐ Exemplo » *${usedPrefix + command} Olá, uso WhatsApp!*`);    
    db.setUser(msg.sender, 'description', input);
    return msg.reply(`✎ Foi definida a tua descrição, podes revisarla con ${usedPrefix}profile ฅ^•ﻌ•^ฅ`);
  },
};