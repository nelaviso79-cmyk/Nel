import db from '#db';
export default {
  command: ['setgenre'],
  category: 'perfil',
  description: 'Definir seu género.',
  run: async ({ msg, args, usedPrefix, command }) => {
    const user = db.getUser(msg.sender);
    const input = args.join(' ').toLowerCase();
    if (!input) return msg.reply(`《✧》 Deve inserir um gênero válido.\n✎ Exemplos:\n> *${usedPrefix + command} homem*\n> *${usedPrefix + command} mulher*`);    
    const genresList = ['Homem', 'Mulher', 'Femboy', 'Transgénero', 'Gay', 'Lesbiana', 'No Binario', 'Pansexual', 'Bisexual', 'Asexual', 'Therian'];
    let genre = null;    
    if (!isNaN(input)) {
      const index = parseInt(input) - 1;
      if (index >= 0 && index < genresList.length) {
        genre = genresList[index];
      }
    } else {
      const found = genresList.find(g => g.toLowerCase() === input);
      if (found) genre = found;
    }    
    if (!genre) {
      const opciones = genresList.map((g, i) => `${i + 1}. ${g}`).join('\n');
      return msg.reply(`《✧》 Escolhe um gênero válido.\n\nOpciones:\n${opciones}`);
    }    
    db.setUser(msg.sender, 'genre', genre);
    return msg.reply(`✎ Foi definido seu género como: *${genre}*`);
  },
};
