import db from '#db';
export default {
  command: ['setpasatiempo', 'sethobby'],
  category: 'perfil',
  description: 'Definir seu passatempo.',
  run: async ({ msg, args, usedPrefix }) => {
    const user = db.getUser(msg.sender);
    const input = args.join(' ').trim();    
    const pasatiemposDisponibles = [
      '📚 Leer', '✍️ Escribir', '🎤 Cantar', '💃 Bailar', '🎮 Jugar', 
      '🎨 Dibujar', '🍳 Cocinar', '✈️ Viajar', '🏊 Nadar', '📸 Fotografía',
      '🎧 Escuchar música', '🏀 Deportes', '🎬 Ver películas', '🌿 Jardinería',
      '🧵 Manualidades', '🎲 Jogos de mesa', '🏋️‍♂️ Gimnasio', '🚴 Ciclismo',
      '🎯 Tiro con arco', '🍵 Cerimónia do chá', '🧘‍♂️ Meditação', '🎪 Malabares',
      '🛠️ Bricolaje', '🎹 Tocar instrumentos', '🐶 Cuidar mascotas', '🌌 Astronomía',
      '♟️ Ajedrez', '🍷 Prova de vinhos', '🛍️ Compras', '🏕️ Acampar',
      '🎣 Pescar', '📱 Tecnología', '🎭 Teatro', '🍽️ Gastronomía', '🏺 Coleccionar',
      '✂️ Costura', '🧁 Repostería', '📝 Blogging', '🚗 Automóviles', '🧩 Rompecabezas',
      '🎳 Bolos', '🏄 Surf', '⛷️ Esquí', '🎿 Snowboard', '🤿 Buceo', '🏹 Tiro al blanco',
      '🧭 Orientação', '🏇 Equitação', '🎨 Pintura', '📊 Investir', '🌡️ Meteorologia',
      '🔍 Investigar', '💄 Maquillaje', '💇‍♂️ Peluquería', '🛌 Dormir', '🍺 Cervecería',
      '🪓 Carpintaria', '🧪 Experimentos', '📻 Radioamadorismo', '🗺️ Geografia', '💎 Jeiría',
      'Otro 🌟'
    ];    
    if (!input) {
      let lista = '🎯 *Escolhe um passatempo:*\n\n';
      pasatiemposDisponibles.forEach((pasatiempo, index) => {
        lista += `${index + 1}) ${pasatiempo}\n`;
      });
      lista += `\n*Exemplos:*\n${usedPrefix}setpasatiempo 1\n${usedPrefix}setpasatiempo Leer\n${usedPrefix}setpasatiempo "Otro 🌟"`;
      return msg.reply(lista);
    }    
    let passatempoSeleccionado = '';
    if (/^\d+$/.test(input)) {
      const index = parseInt(input) - 1;
      if (index >= 0 && index < pasatiemposDisponibles.length) {
        passatempoSeleccionado = pasatiemposDisponibles[index];
      } else {
        return msg.reply(`《✧》 Número inválido. Seleciona um número entre 1 e ${pasatiemposDisponibles.length}`);
      }
    } else {
      const inputLimpio = input.replace(/[^\w\s]/g, '').toLowerCase().trim();
      const encontrado = pasatiemposDisponibles.find(p => p.replace(/[^\w\s]/g, '').toLowerCase().includes(inputLimpio));
      if (encontrado) {
        passatempoSeleccionado = encontrado;
      } else {
        return msg.reply('《✧》 Passatempo não encontrado. Usa o comando sem argumentos para ver a lista disponível.');
      }
    }    
    if (user.pasatiempo === passatempoSeleccionado) {
      return msg.reply(`《✧》 Ya tienes definido este pasatiempo: *${user.pasatiempo}*`);
    }    
    db.setUser(msg.sender, 'passatempo', passatempoSeleccionado);
    return msg.reply(`✐ Foi definido seu passatempo:\n> *${passatempoSeleccionado}*`);
  },
};