import db from '#db';

export async function before({ msg, sock, groupMetadata, isAdmins, isBotAdmins }) {
  if (!msg.isGroup) return;
  if (msg.isBot) return;
  if (isAdmins) return;
  if (!isBotAdmins) return;

  const chat = db.getChat(msg.chat) || {};
  if (!chat?.antimidia) return;

  const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
  const primaryBotId = chat?.primaryBot;
  const isPrimary = !primaryBotId || primaryBotId === botId;
  if (!isPrimary) return;

  const blockedTypes = chat.antimidiaTypes || ['image', 'video', 'sticker'];

  let msgType = null;
  if (msg.message?.imageMessage) msgType = 'image';
  else if (msg.message?.videoMessage) msgType = 'video';
  else if (msg.message?.stickerMessage) msgType = 'sticker';
  else if (msg.message?.audioMessage || msg.message?.pttMessage) msgType = 'audio';
  else if (msg.message?.documentMessage) msgType = 'document';
  else if (msg.message?.contactMessage || msg.message?.contactsArrayMessage) msgType = 'contact';
  else if (msg.message?.locationMessage) msgType = 'location';
  else if (msg.message?.pollCreationMessage) msgType = 'poll';

  if (!msgType) return;
  if (!blockedTypes.includes(msgType)) return;

  // Delete the media message
  try {
    await sock.sendMessage(msg.chat, { delete: { remoteJid: msg.chat, fromMe: false, id: msg.key.id, participant: msg.key.participant }});
  } catch {}

  const typeNames = { image: '📷 Foto', video: '🎬 Vídeo', sticker: '🌟 Sticker', audio: '🎵 Áudio', document: '📄 Documento', contact: '👤 Contacto', location: '📍 Localização', poll: '📊 Votação' };
  const user = db.getUser(msg.sender);
  const userName = user?.name || 'Usuário';

  await sock.reply(msg.chat, `🚫 *${userName}*, ${typeNames[msgType] || msgType} não é permitido neste grupo. Apenas admins podem enviar.`, msg);
}
