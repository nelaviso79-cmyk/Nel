# ⚡ Setup Rápido - Nel-Aviso-Bot V12 Nexus Intelligence

## 🚀 Opção 1: Railway (Recomendado - 5 minutos)

### Passo 1: Preparar o Repositório
```bash
# Clone ou faça download do bot
git clone https://github.com/nelioaviso-arch/Nel-Aviso-Bot-Moz.git
cd Nel-Aviso-Bot-Moz

# Cria ficheiro .env (copia de .env.example)
cp .env.example .env

# Edita .env com teus dados
nano .env
```

### Passo 2: Push para GitHub
```bash
git add .
git commit -m "Deploy v12 Nexus Intelligence"
git push origin main
```

### Passo 3: Deploy no Railway
1. Vai a https://railway.app
2. Clica em "New Project"
3. Seleciona "Deploy from GitHub"
4. Escolhe o repositório "Nel-Aviso-Bot-Moz"
5. Clica em "Deploy"
6. Adiciona variáveis de ambiente (Settings → Variables)
7. Pronto! Bot online 24/7 ✅

---

## 🖥️ Opção 2: VPS Próprio (DigitalOcean - $5/mês)

### Passo 1: Criar Droplet
1. Vai a https://digitalocean.com
2. Clica em "Create" → "Droplets"
3. Escolhe:
   - **Image:** Ubuntu 22.04 LTS
   - **Size:** $5/mês (1GB RAM, 1 vCPU)
   - **Region:** Escolhe o mais próximo
4. Clica em "Create Droplet"
5. Copia o IP do droplet

### Passo 2: Conectar via SSH
```bash
# No teu computador
ssh root@SEU_IP_AQUI

# Primeira vez vai pedir password (enviada por email)
```

### Passo 3: Setup do Servidor
```bash
# Atualizar sistema
apt update && apt upgrade -y

# Instalar Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
apt install -y nodejs

# Instalar PM2 (gerenciador de processos)
npm install -g pm2

# Clonar bot
git clone https://github.com/nelioaviso-arch/Nel-Aviso-Bot-Moz.git
cd Nel-Aviso-Bot-Moz

# Instalar dependências
npm install

# Criar .env
nano .env
# Cole as variáveis de ambiente aqui
```

### Passo 4: Iniciar Bot com PM2
```bash
# Iniciar
pm2 start index.js --name "nel-aviso-bot"

# Configurar auto-restart
pm2 startup
pm2 save

# Ver status
pm2 status

# Ver logs
pm2 logs nel-aviso-bot
```

**Pronto! Bot online 24/7** ✅

---

## 📱 Opção 3: Termux (Android - Sem Custo)

### Passo 1: Instalar Termux
- Baixa Termux da F-Droid (https://f-droid.org)
- Abre Termux

### Passo 2: Setup
```bash
# Atualizar
pkg update && pkg upgrade -y

# Instalar Node.js
pkg install nodejs

# Clonar bot
git clone https://github.com/nelioaviso-arch/Nel-Aviso-Bot-Moz.git
cd Nel-Aviso-Bot-Moz

# Instalar dependências
npm install

# Criar .env
nano .env
```

### Passo 3: Iniciar Bot
```bash
# Opção A: Simples (bot para quando Termux fecha)
npm start

# Opção B: Com auto-restart (melhor)
./scripts/restart.sh start
```

**⚠️ Nota:** Termux precisa estar aberto. Para manter 24/7, usa Railway ou VPS.

---

## 🔧 Ficheiros Importantes

| Ficheiro | Função |
|----------|--------|
| `.env` | Variáveis de ambiente (números, emails, etc) |
| `index.js` | Ponto de entrada do bot |
| `main.js` | Lógica principal |
| `settings.js` | Configurações globais |
| `package.json` | Dependências do projeto |
| `railway.json` | Configuração para Railway |
| `Procfile` | Configuração para Heroku-like |
| `scripts/restart.sh` | Script de auto-restart |

---

## 🔑 Variáveis de Ambiente (.env)

```bash
# Número do dono (sem + ou espaços)
OWNER_NUMBER=258878464656

# M-Pesa
MPESA_NUMERO=8XXXXXXXX
MPESA_NOME=Seu Nome Completo

# E-Mola
EMOLA_NUMERO=8XXXXXXXX
EMOLA_NOME=Seu Nome Completo

# Contactos
OWNER_GMAIL=seuemail@gmail.com

# Links
API_LINK=https://github.com/nelioaviso-arch
CHANNEL_LINK=https://whatsapp.com/channel/0029Vb8SJi3BFLgQL1wCTr3N
GITHUB_LINK=https://github.com/nelioaviso-arch/Nel-Aviso-Bot-Moz.git
```

---

## ✅ Checklist Final

- [ ] Repositório no GitHub
- [ ] Ficheiro .env configurado
- [ ] Dependências instaladas
- [ ] Bot testado localmente
- [ ] Plataforma de hosting escolhida
- [ ] Deploy realizado
- [ ] QR Code escaneado
- [ ] Bot online 24/7
- [ ] Monitoramento ativado

---

## 🆘 Troubleshooting Rápido

### Bot não inicia
```bash
# Verifica Node.js
node --version

# Verifica npm
npm --version

# Reinstala dependências
rm -rf node_modules package-lock.json
npm install
```

### Erro de conexão WhatsApp
```bash
# Deleta sessão antiga
rm -rf .wwebjs_cache

# Tenta novamente
npm start
```

### Bot desconecta
```bash
# Usa PM2 para auto-restart
pm2 start index.js --name "nel-aviso-bot"
pm2 save
```

---

## 📞 Suporte

- **GitHub:** https://github.com/nelioaviso-arch
- **Email:** seuemail@gmail.com
- **Canal WhatsApp:** https://whatsapp.com/channel/0029Vb8SJi3BFLgQL1wCTr3N

---

**Criado com ❤️ por Nel Custódio**
